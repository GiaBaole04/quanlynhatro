
<?php
$required_role = 'admin'; // hoặc 'admin', 'nguoithue'
include('lib/auth.php');
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hệ Thống Quản Lý Nhà Trọ - Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="./css/style.css">
    <link rel="stylesheet" href="./css/dashboard.css">
</head>
<body>

    <?php include('lib/menuapp.php'); ?>

    <div class="main-content container-fluid">
        <div class="row">
            <div class="col-md-9">
                <h1 class="dashboard-title">Quản Lý Nhà Trọ</h1>

                <?php include('lib/phongtroFunction.php'); ?>

                <?php 
                if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                    $_SESSION['filters'] = $_POST;
                }
                $filters = $_SESSION['filters'] ?? [];

                // Lấy trang hiện tại từ tham số URL
                $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
                if ($page < 1) $page = 1;

                // Gọi hàm getPhongTroList với phân trang
                $result = getPhongTroList($filters, $page, 4); // 4 phòng trọ mỗi trang
                $phongtro_list = $result['phongtro'];
                $total_pages = $result['total_pages'];
                ?>
                
                <div class="stats-row mb-4">
                    <div class="row g-3">
                        <!-- Thống kê Phòng trống -->
                        <div class="col-md-4">
                            <div class="stat-card h-100 p-3 text-center bg-white rounded shadow-sm border-start border-primary border-4">
                                <h5 class="text-secondary mb-3 fw-normal">PHÒNG TRỐNG</h5>
                                <div class="display-5 fw-bold text-dark mb-2">
                                    <?php echo getPhongTrongCount(); ?>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Thống kê Phòng đã thuê -->
                        <div class="col-md-4">
                            <div class="stat-card h-100 p-3 text-center bg-white rounded shadow-sm border-start border-success border-4">
                                <h5 class="text-secondary mb-3 fw-normal">PHÒNG ĐÃ THUÊ</h5>
                                <div class="display-5 fw-bold text-dark mb-2">
                                    <?php echo getPhongThueCount(); ?>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Thống kê Doanh thu tháng -->
                        <div class="col-md-4">
                            <div class="stat-card h-100 p-3 text-center bg-white rounded shadow-sm border-start border-danger border-4">
                                <h5 class="text-secondary mb-3 fw-normal">DOANH THU THÁNG</h5>
                                <div class="display-5 fw-bold text-dark">
                                    <?php echo number_format(getDoanhThuThang(), 0, ',', '.'); ?>
                                </div>
                                <div class="text-muted small">VND</div>
                            </div>
                        </div>
                    </div>
                </div>

                <h3 class="section-title">Danh sách phòng trọ</h3>
                <div class="filter-container mb-3">
                    <!-- Form lọc phía trên -->
                    <form method="POST" class="d-flex">
                        <select name="khu_vuc" class="form-select">
                            <option value="">Tất cả khu vực</option>
                            <?php 
                            $result = getAreas(); // Không cần truyền $limit, sẽ lấy tất cả khu vực
                            $areas = $result['areas'];
                            
                            foreach ($areas as $area) {
                                $selected = (isset($_POST['khu_vuc']) && $_POST['khu_vuc'] == $area['ID_khuvuc']) ? 'selected' : '';
                                echo "<option value='{$area['ID_khuvuc']}' $selected>{$area['Ten_khuvuc']}</option>";
                            } 
                            ?>
                        </select>
                        <select name="nha_tro" class="form-select">
                            <option value="">Tất cả nhà trọ</option>
                            <?php 
                            $nhatro_list = getNhaTroList();
                            foreach ($nhatro_list as $nha_tro) {
                                $selected = (isset($_POST['nha_tro']) && $_POST['nha_tro'] == $nha_tro['ID_nhatro']) ? 'selected' : '';
                                echo "<option value='{$nha_tro['ID_nhatro']}' $selected>{$nha_tro['Ten_nhatro']}</option>";
                            } 
                            ?>
                        </select>
                        <button type="submit" class="btn btn-primary ms-2">Lọc</button>
                    </form>
                </div>

                <!-- Danh sách phòng trọ - Hiển thị 2 cột mỗi hàng -->
                <div class="row g-3">
                    <?php
                    if (!empty($phongtro_list)) {
                        foreach ($phongtro_list as $phong) {
                            echo "
                            <div class='col-md-6'>
                                <div class='room-card card'>
                                    <img src='{$phong['Anh']}' class='card-img-top' alt='Phòng {$phong['Ten_phong']}'>
                                    <div class='card-body'>
                                        <h5 class='card-title'>{$phong['Ten_nhatro']} - {$phong['Ten_phong']}</h5>
                                        <p class='card-text'>
                                            Giá thuê: " . number_format($phong['Gia_thue'], 0, ',', '.') . " VND<br>
                                            Địa chỉ: {$phong['Dia_chi']}<br>
                                            Trạng thái: {$phong['Trang_thai']}
                                        </p>
                                        <a href='chitietphongtro.php?id={$phong['ID_phong']}' class='btn btn-primary'>Xem chi tiết</a>
                                    </div>
                                </div>
                            </div>";
                        }
                    } else {
                        echo "<div class='col-12'><p>Không tìm thấy phòng trọ nào.</p></div>";
                    }
                    ?>
                </div>

                <!-- Phân trang -->
                <?php if ($total_pages > 1): ?>
                    <nav aria-label="Page navigation" class="mt-4">
                        <ul class="pagination justify-content-center">
                            <!-- Nút Trước -->
                            <li class="page-item <?php echo $page <= 1 ? 'disabled' : ''; ?>">
                                <a class="page-link" href="index.php?page=<?php echo $page - 1; ?><?php echo !empty($filters) ? '&' . http_build_query($filters) : ''; ?>">Trước</a>
                            </li>

                            <!-- Các trang -->
                            <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                                <li class="page-item <?php echo $i == $page ? 'active' : ''; ?>">
                                    <a class="page-link" href="index.php?page=<?php echo $i; ?><?php echo !empty($filters) ? '&' . http_build_query($filters) : ''; ?>"><?php echo $i; ?></a>
                                </li>
                            <?php endfor; ?>

                            <!-- Nút Tiếp theo -->
                            <li class="page-item <?php echo $page >= $total_pages ? 'disabled' : ''; ?>">
                                <a class="page-link" href="index.php?page=<?php echo $page + 1; ?><?php echo !empty($filters) ? '&' . http_build_query($filters) : ''; ?>">Tiếp</a>
                            </li>
                        </ul>
                    </nav>
                <?php endif; ?>
            </div>

            <!-- Sidebar -->
            <div class="col-md-3">
                <div class="sidebar-filter">
                    <h3 class="section-title">Lọc phòng trọ</h3>
                    <form method="POST">
                        <div class="mb-3">
                            <label for="gia_tien" class="form-label">Giá tiền</label>
                            <select name="gia_tien" id="gia_tien" class="form-select">
                                <option value="">Tất cả</option>
                                <option value="0-2000000" <?php echo isset($_POST['gia_tien']) && $_POST['gia_tien'] == '0-2000000' ? 'selected' : ''; ?>>Dưới 2 triệu</option>
                                <option value="2000000-3000000" <?php echo isset($_POST['gia_tien']) && $_POST['gia_tien'] == '2000000-3000000' ? 'selected' : ''; ?>>2 - 3 triệu</option>
                                <option value="3000000-5000000" <?php echo isset($_POST['gia_tien']) && $_POST['gia_tien'] == '3000000-5000000' ? 'selected' : ''; ?>>3 - 5 triệu</option>
                                <option value="5000000" <?php echo isset($_POST['gia_tien']) && $_POST['gia_tien'] == '5000000' ? 'selected' : ''; ?>>Trên 5 triệu</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="dien_tich" class="form-label">Diện tích</label>
                            <select name="dien_tich" id="dien_tich" class="form-select">
                                <option value="">Tất cả</option>
                                <option value="0-20" <?php echo isset($_POST['gia_tien']) && $_POST['gia_tien'] == '0-20' ? 'selected' : ''; ?>>Dưới 20 m²</option>
                                <option value="20-30" <?php echo isset($_POST['gia_tien']) && $_POST['gia_tien'] == '20-30' ? 'selected' : ''; ?>>20 - 30 m²</option>
                                <option value="30-50" <?php echo isset($_POST['gia_tien']) && $_POST['gia_tien'] == '30-50' ? 'selected' : ''; ?>>30 - 50 m²</option>
                                <option value="50" <?php echo isset($_POST['gia_tien']) && $_POST['gia_tien'] == '50' ? 'selected' : ''; ?>>Trên 50 m²</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="khu_vuc_filter" class="form-label">Khu vực</label>
                            <select name="khu_vuc_filter" id="khu_vuc_filter" class="form-select">
                                <option value="">Tất cả khu vực</option>
                                <?php foreach ($areas as $area) {
                                    $selected = (isset($_POST['khu_vuc_filter']) && $_POST['khu_vuc_filter'] == $area['ID_khuvuc']) ? 'selected' : '';
                                    echo "<option value='{$area['ID_khuvuc']}' $selected>{$area['Ten_khuvuc']}</option>";
                                } ?>
                            </select>
                        </div>
                        <button type="submit" class="btn btn-primary w-100">Áp dụng</button>
                    </form>
                </div>
            </div>
        </div>

        <!-- Hợp đồng sắp hết hạn -->
        <h3 class="section-title mt-4">Hợp đồng sắp hết hạn</h3>
        <div class="mb-3">
            <form method="POST" class="d-flex align-items-center">
                <label for="days_filter" class="me-2">Hiển thị hợp đồng hết hạn trong:</label>
                <select name="days_filter" id="days_filter" class="form-select w-auto">
                    <option value="15" <?php echo isset($_POST['days_filter']) && $_POST['days_filter'] == '15' ? 'selected' : ''; ?>>15 ngày</option>
                    <option value="30" <?php echo isset($_POST['days_filter']) && $_POST['days_filter'] == '30' ? 'selected' : ''; ?>>30 ngày</option>
                    <option value="60" <?php echo isset($_POST['days_filter']) && $_POST['days_filter'] == '60' ? 'selected' : ''; ?>>60 ngày</option>
                </select>
                <button type="submit" class="btn btn-primary ms-2">Lọc</button>
            </form>
        </div>
        <table class="contracts-table table table-striped">
            <thead>
                <tr>
                    <th>ID Hợp đồng</th>
                    <th>Phòng</th>
                    <th>Người thuê</th>
                    <th>Ngày kết thúc</th>
                    <th>Số ngày còn lại</th>
                    <th>Hành động</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $days = isset($_POST['days_filter']) ? (int)$_POST['days_filter'] : 30;
                $hopdong_list = getHopDongSapHetHan($days);
                if (!empty($hopdong_list)) {
                    foreach ($hopdong_list as $hopdong) {
                        echo "
                        <tr>
                            <td>{$hopdong['ID_hopdong']}</td>
                            <td>{$hopdong['Ten_nhatro']} - {$hopdong['Ten_phong']}</td>
                            <td>{$hopdong['Ho_ten']}</td>
                            <td>{$hopdong['Ngay_ket_thuc']}</td>
                            <td>{$hopdong['So_ngay_con_lai']} ngày</td>
                            <td><a href='hopdong.php?id={$hopdong['ID_hopdong']}' class='btn btn-sm btn-primary'>Xem chi tiết</a></td>
                        </tr>";
                    }
                } else {
                    echo "
                    <tr>
                        <td colspan='6' class='text-center'>Không có hợp đồng nào sắp hết hạn trong $days ngày tới.</td>
                    </tr>";
                }
                ?>
            </tbody>
        </table>

        <footer class="footer mt-4">
            <p>Liên hệ: 0123 456 789 - Email: info@nhatro.com</p>
        </footer>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
</body>
</html>