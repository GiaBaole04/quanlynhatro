<?php
$required_role = 'admin'; // hoặc 'admin', 'nguoithue'
include('lib/auth.php');
include('lib/connect.php');
include('lib/phongtroFunction.php');

// Lấy ID_phong từ URL
$id_phong = isset($_GET['id']) ? mysqli_real_escape_string($conn, $_GET['id']) : '';

if (empty($id_phong)) {
    header("Location: index.php?error=ID phòng không hợp lệ");
    exit();
}

// Lấy thông tin phòng trọ
$phong = getPhongTroById($id_phong);

if (!$phong) {
    header("Location: index.php?error=Phòng trọ không tồn tại");
    exit();
}

// Lấy thông tin nhà trọ để lấy kinh độ và vĩ độ
$query_nhatro = "SELECT Kinh_do, Vi_do FROM nhatro WHERE ID_nhatro = '{$phong['ID_nhatro']}'";
$result_nhatro = mysqli_query($conn, $query_nhatro);
if (!$result_nhatro) {
    die("Lỗi truy vấn nhà trọ: " . mysqli_error($conn));
}
$nhatro = mysqli_fetch_assoc($result_nhatro);
if (!$nhatro) {
    die("Lỗi: Không tìm thấy nhà trọ với ID: " . htmlspecialchars($phong['ID_nhatro']));
}
$kinh_do = $nhatro['Kinh_do'];
$vi_do = $nhatro['Vi_do'];
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Chi Tiết Phòng Trọ - <?php echo htmlspecialchars($phong['Ten_phong']); ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="css/style.css">
    
    <style>
        .room-image {
            max-height: 400px;
            object-fit: cover;
            width: 100%;
        }
        .room-details {
            padding: 20px;
        }
        .map-container {
            margin-top: 20px;
            text-align: center;
        }
        .map-image {
            max-width: 100%;
            height: auto;
            border: 1px solid #ddd;
            border-radius: 5px;
        }
    </style>
</head>
<body>
    <?php include('lib/menuapp.php'); ?>

    <div class="main-content container mt-4">
        <h1 class="dashboard-title">Chi Tiết Phòng Trọ</h1>

        <div class="row">
            <!-- Bên trái: Ảnh phòng trọ -->
            <div class="col-md-6">
                <img src="<?php echo htmlspecialchars($phong['Anh'] ?: 'images/default-room.jpg'); ?>" 
                     class="room-image img-fluid rounded" 
                     alt="Phòng <?php echo htmlspecialchars($phong['Ten_phong']); ?>">
            </div>

            <!-- Bên phải: Thông tin phòng trọ -->
            <div class="col-md-6 room-details">
                <h3><?php echo htmlspecialchars($phong['Ten_nhatro'] . ' - ' . $phong['Ten_phong']); ?></h3>
                <p><strong>Giá thuê:</strong> <?php echo number_format($phong['Gia_thue'], 0, ',', '.'); ?> VNĐ/tháng</p>
                <p><strong>Diện tích:</strong> <?php echo htmlspecialchars($phong['Dien_tich']); ?> m²</p>
                <p><strong>Trạng thái:</strong> <?php echo htmlspecialchars($phong['Trang_thai']); ?></p>
                <p><strong>Nhà trọ:</strong> <?php echo htmlspecialchars($phong['Ten_nhatro']); ?></p>
                <p><strong>Địa chỉ:</strong> <?php echo htmlspecialchars($phong['Dia_chi']); ?></p>
                <a href="index.php" class="btn btn-primary mt-3"><i class="fas fa-arrow-left"></i> Quay lại</a>
            </div>
        </div>

        <!-- Liên kết đến Google Maps -->
        <div class="map-container">
            <h3>Vị trí nhà trọ</h3>
            <a href="https://www.google.com/maps?q=<?php echo $kinh_do; ?>,<?php echo $vi_do; ?>&z=15" target="_blank">
                <img src="images/map-placeholder.png" class="map-image" alt="Xem vị trí trên Google Maps">
            </a>
            <p class="mt-2"><small>Nhấn vào hình ảnh để xem vị trí trên Google Maps</small></p>
            
        </div>

        <footer class="footer mt-4">
            <p><i class="fas fa-phone"></i> Liên hệ: 0123 456 789 - <i class="fas fa-envelope"></i> Email: info@nhatro.com</p>
        </footer>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>