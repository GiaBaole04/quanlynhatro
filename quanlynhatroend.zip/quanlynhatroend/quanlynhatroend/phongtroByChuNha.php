<?php
$required_role = 'chunha'; // hoặc 'admin', 'nguoithue'
include('lib/auth.php');
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quản Lý Phòng Trọ</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <?php include('lib/menuchunha.php'); ?>
    <div class="main-content">
        <h1 class="dashboard-title">Quản Lý Phòng Trọ</h1>

        <?php
        include 'lib/connect.php';
        
        include 'lib/phongtroChuNhaFunction.php';
        
        include 'lib/nhatrocuatoiFunction.php';
        $anh = null;
        if (isset($_FILES['anh']) && $_FILES['anh']['error'] == UPLOAD_ERR_OK) {
            $target_dir = "uploads/phongtro/";
            if (!is_dir($target_dir)) mkdir($target_dir, 0777, true);
            $file_name = uniqid('phongtro_') . '_' . basename($_FILES['anh']['name']);
            $target_file = $target_dir . $file_name;
            if (move_uploaded_file($_FILES['anh']['tmp_name'], $target_file)) {
                $anh = $target_file;
            }
        }
        $nhatroList = getNhaTroByChuNha($conn, $_SESSION['user_id']);
        // Xử lý thêm/sửa/xóa phòng trọ
        if (isset($_POST['add_phong'])) {
            $ten_phong = $_POST['ten_phong'];
            $gia_thue = $_POST['gia_thue'];
            $dien_tich = $_POST['dien_tich'];
            $id_nhatro = $_POST['id_nhatro'];
            $trang_thai = $_POST['trang_thai'] ?? ''; // Thêm giá trị mặc định nếu không tồn tại
        
            // Debug giá trị trang_thai
            error_log("DEBUG: id_nhatro = " . $id_nhatro);
            
            if (!empty($ten_phong) && !empty($gia_thue) && !empty($dien_tich) && !empty($id_nhatro)) {
                
                
                $result = addPhongTroByChuNha($conn, $ten_phong, $gia_thue, $dien_tich, $id_nhatro, $_SESSION['user_id'], $trang_thai, $anh);
                if ($result['success']) {
                    // Debug: Kiểm tra giá trị Trang_thai trong cơ sở dữ liệu
                    $check_query = "SELECT Trang_thai FROM phong_tro WHERE ID_phong = (SELECT MAX(ID_phong) FROM phong_tro)";
                    $check_result = mysqli_query($conn, $check_query);
                    $row = mysqli_fetch_assoc($check_result);
                    error_log("Debug: Trang_thai sau khi thêm = " . $row['Trang_thai']);
                    
                    header("Location: phongtroByChuNha.php?msg=" . urlencode($result['message']));
                    exit();
                } else {
                    echo "<div class='alert alert-danger'>" . htmlspecialchars($result['message']) . "</div>";
                }
            } else {
                echo "<div class='alert alert-danger'>Vui lòng điền đầy đủ thông tin bắt buộc</div>";
            }
        }
        elseif (isset($_POST['update_phong'])) {
            
            $id_phong = $_POST['id_phong'];
            $ten_phong = $_POST['ten_phong'];
            $gia_thue = $_POST['gia_thue'];
            $dien_tich = $_POST['dien_tich'];
            $id_nhatro = $_POST['id_nhatro'];
            $trang_thai = $_POST['trang_thai'];
            
            if (!empty($ten_phong) && !empty($gia_thue) && !empty($dien_tich) && !empty($id_nhatro)) {
                $result = updatePhongTroByChuNha($conn, $id_phong, $ten_phong, $gia_thue, $dien_tich, $id_nhatro, $_SESSION['user_id'], $trang_thai);
                if ($result['success']) {
                    header("Location: phongtroByChuNha.php?msg=" . urlencode($result['message']));
                    exit();
                } else {
                    echo "<div class='alert alert-danger'>" . htmlspecialchars($result['message']) . "</div>";
                }
            } else {
                echo "<div class='alert alert-danger'>Vui lòng điền đầy đủ thông tin bắt buộc</div>";
            }
        }
        
        elseif (isset($_GET['delete'])) {
            $id_phong = $_GET['delete'];
            if (deletePhongTroByChuNha($conn, $id_phong, $_SESSION['user_id'])) {
                header("Location: phongtroByChuNha.php?msg=Xóa phòng trọ thành công");
                exit();
            } else {
                echo "<div class='alert alert-danger'>Bạn không có quyền xóa phòng trọ này hoặc đã có lỗi xảy ra.</div>";
            }
        }

        if (isset($_GET['msg'])) {
            echo "<div class='alert alert-success alert-dismissible fade show' role='alert'>
                    <strong>Thành công!</strong> " . htmlspecialchars($_GET['msg']) . "
                    <button type='button' class='btn-close' data-bs-dismiss='alert' aria-label='Close'></button>
                  </div>";
        }

        $edit_phong = null;
        if (isset($_GET['edit'])) {
            $id_phong = mysqli_real_escape_string($conn, $_GET['edit']);
            $query = "SELECT * FROM phong_tro WHERE ID_phong = ?";
            $stmt = mysqli_prepare($conn, $query);
            if ($stmt) {
                mysqli_stmt_bind_param($stmt, "s", $id_phong);
                mysqli_stmt_execute($stmt);
                $result = mysqli_stmt_get_result($stmt);
                if ($result && mysqli_num_rows($result) > 0) {
                    $edit_phong = mysqli_fetch_assoc($result);
                } else {
                    echo "<div class='alert alert-danger'>Không tìm thấy phòng trọ với ID: " . htmlspecialchars($id_phong) . "</div>";
                }
                mysqli_stmt_close($stmt);
            } else {
                echo "<div class='alert alert-danger'>Lỗi truy vấn: " . mysqli_error($conn) . "</div>";
            }
        }

        // Lấy trang hiện tại từ tham số URL
        $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
        if ($page < 1) $page = 1;

        // Lấy dữ liệu tìm kiếm
        $search = isset($_GET['search']) ? $_GET['search'] : '';

        // Gọi hàm getPhongTroList với phân trang
        
        $phongtroData = getPhongTroByChuNha($conn, $_SESSION['user_id'], $search, $page, 6);
        $phongtro_list = $phongtroData['phongtro'];
        $total_pages = $phongtroData['total_pages'];
        ?>

        <div class="row">
            <div class="col-md-4">
                <div class="stat-card">
                    <h3><?php echo !empty($edit_phong) ? 'Sửa Phòng Trọ' : 'Thêm Phòng Trọ'; ?></h3>
                    <form method="POST" enctype="multipart/form-data">
                        <?php if (!empty($edit_phong)) { ?>
                            <input type="hidden" name="id_phong" value="<?php echo htmlspecialchars($edit_phong['ID_phong']); ?>">
                        <?php } ?>
                        <div class="mb-3">
                            <label for="ten_phong" class="form-label">Tên phòng <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" id="ten_phong" name="ten_phong" 
                                   value="<?php echo !empty($edit_phong) ? htmlspecialchars($edit_phong['Ten_phong']) : ''; ?>" required>
                        </div>
                        <div class="mb-3">
                            <label for="gia_thue" class="form-label">Giá thuê (VNĐ) <span class="text-danger">*</span></label>
                            <input type="number" class="form-control" id="gia_thue" name="gia_thue" 
                                   value="<?php echo !empty($edit_phong) ? htmlspecialchars($edit_phong['Gia_thue']) : ''; ?>" required>
                        </div>
                        <div class="mb-3">
                            <label for="dien_tich" class="form-label">Diện tích (m²) <span class="text-danger">*</span></label>
                            <input type="number" step="0.1" class="form-control" id="dien_tich" name="dien_tich" 
                                   value="<?php echo !empty($edit_phong) ? htmlspecialchars($edit_phong['Dien_tich']) : ''; ?>" required>
                        </div>
                        <div class="mb-3">
                            <label for="id_nhatro" class="form-label">Nhà trọ <span class="text-danger">*</span></label>
                            <select class="form-select" id="id_nhatro" name="id_nhatro" required>
                                <option value="">Chọn nhà trọ</option>
                                <?php
                                foreach ($nhatroList as $nt) {
                                    $selected = (!empty($edit_phong) && $edit_phong['ID_nhatro'] == $nt['ID_nhatro']) ? 'selected' : '';
                                    echo "<option value='{$nt['ID_nhatro']}' $selected>" . htmlspecialchars($nt['Ten_nhatro']) . "</option>";
                                }
                                ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="trang_thai" class="form-label">Trạng thái <span class="text-danger">*</span></label>
                            <select class="form-select" id="trang_thai" name="trang_thai" required>
                                <option value="Trống" <?php echo (!empty($edit_phong) && $edit_phong['Trang_thai'] == 'Trống') ? 'selected' : ''; ?>>Trống</option>
                                <option value="Đã thuê" <?php echo (!empty($edit_phong) && $edit_phong['Trang_thai'] == 'Đã thuê') ? 'selected' : ''; ?>>Đã thuê</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="anh_phong" class="form-label">Ảnh phòng</label>
                            <input type="file" name="anh" class="form-control" accept="image/*">
                            <?php if (!empty($edit_phong) && !empty($edit_phong['Anh'])) { ?>
                                <div class="mt-2">
                                    <img src="<?php echo htmlspecialchars($edit_phong['Anh']); ?>" width="100" class="img-thumbnail">
                                </div>
                            <?php } ?>
                        </div>
                        <button type="submit" name="<?php echo !empty($edit_phong) ? 'update_phong' : 'add_phong'; ?>" class="btn btn-primary w-100">
                            <i class="fas fa-save"></i> <?php echo !empty($edit_phong) ? 'Cập nhật' : 'Thêm mới'; ?>
                        </button>
                    </form>
                </div>
            </div>

            <div class="col-md-8">
                <div class="contracts-table">
                    <h3 class="section-title">Danh Sách Phòng Trọ</h3>
                    <form method="GET" class="mb-3">
                        <div class="input-group">
                            <input type="text" class="form-control" id = "search" name="search" placeholder="Tìm kiếm theo tên phòng..." 
                                   value="<?php echo isset($_GET['search']) ? htmlspecialchars($_GET['search']) : ''; ?>">
                            <button type="submit" class="btn btn-primary"><i class="fas fa-search"></i> Tìm kiếm</button>
                        </div>
                    </form>
                    
                <div id="phongtro-list">
                    <?php
                    if ($phongtro_list && !empty($phongtro_list)) {
                        $chunked_phongtro = array_chunk($phongtro_list, 3); // Chia danh sách thành các hàng, mỗi hàng 3 cột
                        $rows_to_display = array_slice($chunked_phongtro, 0, 2); // Chỉ lấy tối đa 2 hàng

                        foreach ($rows_to_display as $row) {
                            echo '<div class="row row-cols-1 row-cols-md-3 g-4 mb-4">';
                            foreach ($row as $phong) {
                                echo "<!-- Debug: Trang_thai = " . htmlspecialchars($phong['Trang_thai']) . " -->";
                                ?>
                                <div class="col">
                                    <div class="card h-100 shadow-sm room-card">
                                        <img src="<?php echo !empty($phong['Anh']) ? htmlspecialchars($phong['Anh']) : 'images/default-room.jpg'; ?>" 
                                             class="card-img-top" alt="Ảnh phòng" onerror="this.src='images/default-room.jpg'">
                                        <div class="card-body">
                                            <h5 class="card-title"><?php echo htmlspecialchars($phong['Ten_phong']); ?></h5>
                                            <p class="card-text">
                                                <strong>Nhà trọ:</strong> <?php echo htmlspecialchars($phong['Ten_nhatro']); ?><br>
                                                <strong>Giá thuê:</strong> <?php echo number_format($phong['Gia_thue']); ?> VNĐ<br>
                                                <strong>Diện tích:</strong> <?php echo htmlspecialchars($phong['Dien_tich']); ?> m²
                                            </p>
                                        </div>
                                        <div class="card-footer bg-white d-flex justify-content-between align-items-center">
                                            <?php if ($phong['Trang_thai'] == 'Trống'): ?>
                                                <span class="badge rounded-pill badge-trong p-2" style="background-color: #2ecc71; color: white; font-size: 1rem; padding: 8px 12px; border-radius: 20px; font-weight: 500;">TRỐNG</span>
                                            <?php else: ?>
                                                <span class="badge rounded-pill badge-thue p-2" style="background-color: #e74c3c; color: white; font-size: 1rem; padding: 8px 12px; border-radius: 20px; font-weight: 500;">ĐÃ THUÊ</span>
                                            <?php endif; ?>
                                            <div class="action-buttons d-flex gap-2">
                                                <a href="phongtroByChuNha.php?edit=<?php echo htmlspecialchars($phong['ID_phong']); ?>" class="btn btn-warning" style="background-color: #ffca28; border-color: #ffca28; color: #fff;">
                                                    <i class="fas fa-edit"></i> Sửa
                                                </a>
                                                <a href="phongtroByChuNha.php?delete=<?php echo htmlspecialchars($phong['ID_phong']); ?>" class="btn btn-danger" style="background-color: #ff4d4f; border-color: #ff4d4f; color: #fff;" onclick="return confirm('Bạn có chắc muốn xóa phòng trọ này?');">
                                                    <i class="fas fa-trash"></i> Xóa
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <?php
                            }
                            echo '</div>';
                        }
                    } else {
                        echo '<div class="col-12">
                                <div class="empty-state">
                                    <i class="fas fa-door-open" style="font-size: 3rem;"></i>
                                    <h4 class="mt-3">Không tìm thấy phòng trọ nào</h4>
                                    <p>Vui lòng thử lại với từ khóa khác hoặc thêm phòng mới</p>
                                </div>
                              </div>';
                    }
                    ?>
                </div>
                    <!-- Phân trang -->
                    <?php if ($total_pages > 1): ?>
                        <nav aria-label="Page navigation" class="mt-4">
                            <ul class="pagination justify-content-center">
                                <!-- Nút Trước -->
                                <li class="page-item <?php echo $page <= 1 ? 'disabled' : ''; ?>">
                                    <a class="page-link" href="phongtroByChuNha.php?page=<?php echo $page - 1; ?><?php echo !empty($search) ? '&search=' . urlencode($search) : ''; ?>">Trước</a>
                                </li>

                                <!-- Các trang -->
                                <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                                    <li class="page-item <?php echo $i == $page ? 'active' : ''; ?>">
                                        <a class="page-link" href="phongtroByChuNha.php?page=<?php echo $i; ?><?php echo !empty($search) ? '&search=' . urlencode($search) : ''; ?>"><?php echo $i; ?></a>
                                    </li>
                                <?php endfor; ?>

                                <!-- Nút Tiếp theo -->
                                <li class="page-item <?php echo $page >= $total_pages ? 'disabled' : ''; ?>">
                                    <a class="page-link" href="phongtroByChuNha.php?page=<?php echo $page + 1; ?><?php echo !empty($search) ? '&search=' . urlencode($search) : ''; ?>">Tiếp</a>
                                </li>
                            </ul>
                        </nav>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <footer class="footer">
            <p><i class="fas fa-phone"></i> Liên hệ: 0123 456 789 - <i class="fas fa-envelope"></i> Email: info@nhatro.com</p>
        </footer>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
const searchInput = document.getElementById('search');
const phongtroList = document.getElementById('phongtro-list');

searchInput.addEventListener('keyup', function() {
    const searchText = this.value.trim();
    fetch('lib/search_phongtro.php?search=' + encodeURIComponent(searchText))
        .then(response => response.json())
        .then(data => {
            let html = '';
            if (data.length > 0) {
                let chunked = [];
                for (let i = 0; i < data.length; i += 3) {
                    chunked.push(data.slice(i, i + 3));
                }
                chunked.forEach(row => {
                    html += `<div class="row row-cols-1 row-cols-md-3 g-4 mb-4">`;
                    row.forEach(phong => {
                        html += `
                        <div class="col">
                            <div class="card h-100 shadow-sm room-card">
                                <img src="${phong.Anh ? phong.Anh : 'images/default-room.jpg'}" class="card-img-top" alt="Ảnh phòng" onerror="this.src='images/default-room.jpg'">
                                <div class="card-body">
                                    <h5 class="card-title">${phong.Ten_phong}</h5>
                                    <p class="card-text">
                                        <strong>Nhà trọ:</strong> ${phong.Ten_nhatro}<br>
                                        <strong>Giá thuê:</strong> ${Number(phong.Gia_thue).toLocaleString()} VNĐ<br>
                                        <strong>Diện tích:</strong> ${phong.Dien_tich} m²
                                    </p>
                                </div>
                                <div class="card-footer bg-white d-flex justify-content-between align-items-center">
                                    ${phong.Trang_thai === 'Trống'
                                        ? `<span class="badge rounded-pill badge-trong p-2" style="background-color: #2ecc71; color: white; font-size: 1rem; padding: 8px 12px; border-radius: 20px; font-weight: 500;">TRỐNG</span>`
                                        : `<span class="badge rounded-pill badge-thue p-2" style="background-color: #e74c3c; color: white; font-size: 1rem; padding: 8px 12px; border-radius: 20px; font-weight: 500;">ĐÃ THUÊ</span>`
                                    }
                                    <div class="action-buttons d-flex gap-2">
                                        <a href="phongtroByChuNha.php?edit=${phong.ID_phong}" class="btn btn-warning" style="background-color: #ffca28; border-color: #ffca28; color: #fff;">
                                            <i class="fas fa-edit"></i> Sửa
                                        </a>
                                        <a href="phongtroByChuNha.php?delete=${phong.ID_phong}" class="btn btn-danger" style="background-color: #ff4d4f; border-color: #ff4d4f; color: #fff;" onclick="return confirm('Bạn có chắc muốn xóa phòng trọ này?');">
                                            <i class="fas fa-trash"></i> Xóa
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        `;
                    });
                    html += `</div>`;
                });
            } else {
                html = `<div class="col-12">
                            <div class="empty-state">
                                <i class="fas fa-door-open" style="font-size: 3rem;"></i>
                                <h4 class="mt-3">Không tìm thấy phòng trọ nào</h4>
                                <p>Vui lòng thử lại với từ khóa khác hoặc thêm phòng mới</p>
                            </div>
                        </div>`;
            }
            phongtroList.innerHTML = html;
        });
});
</script>
</body>
</html>