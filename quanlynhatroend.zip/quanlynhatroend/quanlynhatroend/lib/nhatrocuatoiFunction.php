<?php
// filepath: d:\XAMPP\htdocs\quanlynhatroend\lib\nhatrocuatoiFunction.php
include_once 'nhatroFunction.php';
// Lấy danh sách nhà trọ của chủ nhà
// Lấy danh sách nhà trọ của chủ nhà có phân trang

// filepath: d:\XAMPP\htdocs\quanlynhatroend\lib\nhatrocuatoiFunction.php

function getNhaTroByChuNha($conn, $id_chunha, $limit = null, $offset = null) {
    $sql = "SELECT * FROM nhatro WHERE ID_user = ?";
    if ($limit !== null && $offset !== null) {
        $sql .= " LIMIT ? OFFSET ?";
        $stmt = mysqli_prepare($conn, $sql);
        mysqli_stmt_bind_param($stmt, "iii", $id_chunha, $limit, $offset);
    } else {
        $stmt = mysqli_prepare($conn, $sql);
        mysqli_stmt_bind_param($stmt, "i", $id_chunha);
    }
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $list = [];
    while ($row = mysqli_fetch_assoc($result)) $list[] = $row;
    return $list;
}

// Đếm tổng số nhà trọ của chủ nhà
function getNhaTroCountByChuNha($conn, $id_chunha) {
    $sql = "SELECT COUNT(*) as total FROM nhatro WHERE ID_user = ?";
    $stmt = mysqli_prepare($conn, $sql);
    if (!$stmt) die("Lỗi prepare: " . mysqli_error($conn));
    mysqli_stmt_bind_param($stmt, "i", $id_chunha);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $row = mysqli_fetch_assoc($result);
    return $row['total'];
}

// Lấy thông tin chi tiết 1 nhà trọ
function getNhaTroById($conn, $id_nhatro, $id_chunha) {
    $sql = "SELECT * FROM nhatro WHERE ID_nhatro = ? AND ID_user = ?";
    $stmt = mysqli_prepare($conn, $sql);
    if (!$stmt) {
        die("Lỗi prepare: " . mysqli_error($conn));
    }
    // Sửa "ii" thành "si"
    mysqli_stmt_bind_param($stmt, "si", $id_nhatro, $id_chunha);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    return mysqli_fetch_assoc($result);
}

// Xóa nhà trọ
function deleteNhaTroByChuNha($conn, $id_nhatro, $id_chunha) {
    $sql = "DELETE FROM nhatro WHERE ID_nhatro = ? AND ID_user = ?";
    $stmt = mysqli_prepare($conn, $sql);
    if (!$stmt) {
        die("Lỗi prepare: " . mysqli_error($conn));
    }
    // Sửa "ii" thành "si" vì ID_nhatro là string, ID_user là int
    mysqli_stmt_bind_param($stmt, "si", $id_nhatro, $id_chunha);
    return mysqli_stmt_execute($stmt);
}

// Thêm nhà trọ mới
function addNhaTroByChuNha ($conn, $id_chunha, $ten, $diachi, $id_xa, $kinh_do = 0.000000, $vi_do = 0.000000) {
    // Sinh ID_nhatro tự động
    $id_nhatro = getNextAvailableId('nhatro', 'ID_nhatro');
    $sql = "INSERT INTO nhatro (ID_nhatro, Ten_nhatro, Dia_chi, Kinh_do, Vi_do, ID_xa, ID_user, Trang_thai)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)"; // Sửa ở đây
    $stmt = mysqli_prepare($conn, $sql);
    if (!$stmt) {
        return "Lỗi prepare: " . mysqli_error($conn);
    }
    $trang_thai = 'Chờ duyệt'; // Thêm dòng này
    mysqli_stmt_bind_param($stmt, "ssssdsss", $id_nhatro, $ten, $diachi, $kinh_do, $vi_do, $id_xa, $id_chunha, $trang_thai); // Sửa ở đây
    if (!mysqli_stmt_execute($stmt)) {
        return "Lỗi execute: " . mysqli_stmt_error($stmt);
    }
    return true;
}

// Sửa nhà trọ
function updateNhaTroByChuNha($conn, $id_nhatro, $id_chunha, $ten, $diachi, $id_xa) {
    $sql = "UPDATE nhatro SET Ten_nhatro = ?, Dia_chi = ?, ID_xa = ?, Trang_thai = 'Chờ duyệt' WHERE ID_nhatro = ? AND ID_user = ?";
    $stmt = mysqli_prepare($conn, $sql);
    if (!$stmt) {
        die("Lỗi prepare: " . mysqli_error($conn));
    }
    // Sửa "sssii" thành "sss si" vì ID_nhatro là string, ID_user là int
    mysqli_stmt_bind_param($stmt, "ssssi", $ten, $diachi, $id_xa, $id_nhatro, $id_chunha);
    return mysqli_stmt_execute($stmt);
}