<?php
include 'connect.php';
include 'nguoithueFunction.php';

$search = isset($_GET['search']) ? $_GET['search'] : '';
$result = getNguoiThueList($search, 1, 6); // lấy tối đa 6 người thuê
$data = $result['nguoithue'] ?? [];

header('Content-Type: application/json');
echo json_encode($data);
?>