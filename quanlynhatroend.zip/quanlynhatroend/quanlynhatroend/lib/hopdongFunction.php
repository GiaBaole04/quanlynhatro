<?php
if (!isset($conn)) {
    include 'connect.php';
}
include_once 'commonFunctions.php';

// Hàm tạo ID_hopdong tự động (HD01, HD02,...)
function generateHopDongId() {
    global $conn;
    
    $query = "SELECT ID_hopdong FROM hopdong ORDER BY ID_hopdong DESC LIMIT 1";
    $result = mysqli_query($conn, $query);
    
    if ($result && mysqli_num_rows($result) > 0) {
        $last_id = mysqli_fetch_assoc($result)['ID_hopdong'];
        $number = (int)substr($last_id, 2);
        $new_number = $number + 1;
        return "HD" . sprintf("%02d", $new_number);
    } else {
        return "HD01";
    }
}

// Hàm lấy danh sách nhà trọ
function getNhaTroList() {
    global $conn;

    $query = "SELECT ID_nhatro, Ten_nhatro FROM nhatro";
    $result = mysqli_query($conn, $query);
    if (!$result) {
        error_log("Lỗi truy vấn trong getNhaTroList: " . mysqli_error($conn), 3, "debug.log");
        return [];
    }

    $nhatro_list = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $nhatro_list[] = $row;
    }
    return $nhatro_list;
}

// Hàm lấy danh sách phòng trọ
function getPhongTroList($id_nhatro = '') {
    global $conn;

    $query = "SELECT ID_phong, Ten_phong, Trang_thai, ID_nhatro FROM phong_tro";
    if ($id_nhatro) {
        $id_nhatro = mysqli_real_escape_string($conn, $id_nhatro);
        $query .= " WHERE ID_nhatro = '$id_nhatro'";
    }

    $result = mysqli_query($conn, $query);
    if (!$result) {
        error_log("Lỗi truy vấn trong getPhongTroList: " . mysqli_error($conn), 3, "debug.log");
        return [];
    }

    $phongtro_list = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $phongtro_list[] = $row;
    }
    return $phongtro_list;
}

// Hàm lấy danh sách hợp đồng (hỗ trợ phân trang)
function getHopDongList($search = '', $page = 1, $limit = 6) {
    global $conn;

    // Đảm bảo page không nhỏ hơn 1
    $page = max(1, (int)$page);
    
    // Truy vấn để đếm tổng số hợp đồng
    $count_sql = "SELECT COUNT(*) as total 
                  FROM hopdong hd
                  JOIN nguoithue nt ON hd.ID_nguoithue = nt.ID_nguoithue
                  JOIN phong_tro pt ON hd.ID_phong = pt.ID_phong
                  JOIN nhatro nt2 ON pt.ID_nhatro = nt2.ID_nhatro";
    
    if (!empty($search)) {
        
        $search = mysqli_real_escape_string($conn, $search);
        $count_sql .= " WHERE nt.Ho_ten LIKE '%$search%' OR hd.ID_hopdong LIKE '%$search%'";
    }
    
    

    $result = mysqli_query($conn, $count_sql);
    if (!$result) {
        error_log("Lỗi truy vấn count trong getHopDongList: " . mysqli_error($conn), 3, "debug.log");
        return ['hopdong' => [], 'total_pages' => 1];
    }

    $row = mysqli_fetch_assoc($result);
    $total_hopdong = (int)$row['total'];
    $total_pages = max(1, ceil($total_hopdong / $limit));

    // Debug: Ghi log tổng số hợp đồng và số trang
    error_log("Debug: getHopDongList - Total Hop Dong: $total_hopdong, Total Pages: $total_pages", 3, "debug.log");
    //die();

    // Tính offset
    $offset = ($page - 1) * $limit;
    if ($offset < 0) $offset = 0;

    // Truy vấn lấy danh sách hợp đồng
    $query = "SELECT hd.ID_hopdong, hd.Ngay_bat_dau, hd.Ngay_ket_thuc, hd.Tien_coc, hd.Hinh_thuc_thanh_toan,
                     nt.Ho_ten, pt.Ten_phong, pt.Gia_thue, nt2.Ten_nhatro
              FROM hopdong hd
              JOIN nguoithue nt ON hd.ID_nguoithue = nt.ID_nguoithue
              JOIN phong_tro pt ON hd.ID_phong = pt.ID_phong
              JOIN nhatro nt2 ON pt.ID_nhatro = nt2.ID_nhatro";
    
    if (!empty($search)) {
        $query .= " WHERE nt.Ho_ten LIKE '%$search%' OR hd.ID_hopdong LIKE '%$search%'";
    }

    $query .= " ORDER BY hd.Ngay_bat_dau DESC LIMIT $limit OFFSET $offset";

    $result = mysqli_query($conn, $query);
    if (!$result) {
        error_log("Lỗi truy vấn danh sách hợp đồng trong getHopDongList: " . mysqli_error($conn), 3, "debug.log");
        return ['hopdong' => [], 'total_pages' => $total_pages];
    }

    $hopdong_list = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $hopdong_list[] = $row;
    }

    // Debug: Ghi log danh sách hợp đồng trả về
    error_log("Debug: getHopDongList - Page: $page, Limit: $limit, Offset: $offset, Total: $total_hopdong, Hợp đồng: " . print_r($hopdong_list, true), 3, "debug.log");

    return [
        'hopdong' => $hopdong_list,
        'total_pages' => $total_pages
    ];
}



// Hàm lấy thông tin hợp đồng theo ID

function getHopDongById($id_hopdong) {
    global $conn;
    
    $id_hopdong = mysqli_real_escape_string($conn, $id_hopdong);
    // THÊM pt.Gia_thue VÀO CÂU TRUY VẤN SELECT NÀY
    $query = "SELECT hd.ID_hopdong, hd.Ngay_bat_dau, hd.Ngay_ket_thuc, hd.Tien_coc, hd.ID_phong, hd.ID_nguoithue, hd.Hinh_thuc_thanh_toan,
    pt.ID_nhatro, pt.Ten_phong, pt.Gia_thue, nt2.Ten_nhatro, nt.Ho_ten  /*<--- ĐÃ THÊM pt.Gia_thue */
    FROM hopdong hd
    LEFT JOIN phong_tro pt ON hd.ID_phong = pt.ID_phong
    LEFT JOIN nhatro nt2 ON pt.ID_nhatro = nt2.ID_nhatro
    LEFT JOIN nguoithue nt ON hd.ID_nguoithue = nt.ID_nguoithue
    WHERE hd.ID_hopdong = ?";
    
        // ... phần còn lại của hàm getHopDongById (prepared statement, execute, fetch, close) ...
        $stmt = mysqli_prepare($conn, $query);
        if (!$stmt) {
            error_log("Lỗi chuẩn bị truy vấn trong getHopDongById (ID_hopdong: $id_hopdong): " . mysqli_error($conn), 3, "debug.log");
            return null;
        }
    
        mysqli_stmt_bind_param($stmt, "s", $id_hopdong);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);
    
        if (!$result) {
            error_log("Lỗi thực thi truy vấn trong getHopDongById (ID_hopdong: $id_hopdong): " . mysqli_error($conn), 3, "debug.log");
            mysqli_stmt_close($stmt);
            return null;
        }
    
        $hopdong = mysqli_fetch_assoc($result);
    
        mysqli_stmt_close($stmt);
    
        if (!$hopdong) {
            error_log("Không tìm thấy hợp đồng với ID_hopdong: $id_hopdong", 3, "debug.log");
            return null;
        }
    
        return $hopdong;
    }
// Hàm thêm hợp đồng mới
function addHopDong($ngay_bat_dau, $ngay_ket_thuc, $tien_coc, $id_phong, $id_nguoithue, $hinh_thuc_thanh_toan) {
    global $conn;

    $id_hopdong = generateHopDongId();
    $ngay_bat_dau = mysqli_real_escape_string($conn, $ngay_bat_dau);
    $ngay_ket_thuc = mysqli_real_escape_string($conn, $ngay_ket_thuc);
    $tien_coc = floatval($tien_coc);
    $id_phong = mysqli_real_escape_string($conn, $id_phong);
    $id_nguoithue = mysqli_real_escape_string($conn, $id_nguoithue);
    $hinh_thuc_thanh_toan = mysqli_real_escape_string($conn, $hinh_thuc_thanh_toan);

    // Bắt đầu giao dịch
    mysqli_begin_transaction($conn);

    try {
        // Kiểm tra xem phòng trọ có tồn tại và đang trống không
        $check_phong_sql = "SELECT Trang_thai FROM phong_tro WHERE ID_phong = '$id_phong'";
        $result = mysqli_query($conn, $check_phong_sql);
        if (!$result || mysqli_num_rows($result) == 0) {
            throw new Exception("Phòng trọ không tồn tại!");
        }
        $phong = mysqli_fetch_assoc($result);
        if ($phong['Trang_thai'] == 'Đã thuê') {
            throw new Exception("Phòng trọ đã được thuê!");
        }

        // Kiểm tra người thuê có tồn tại không
        $check_nguoithue_sql = "SELECT ID_nguoithue FROM nguoithue WHERE ID_nguoithue = '$id_nguoithue'";
        $result = mysqli_query($conn, $check_nguoithue_sql);
        if (!$result || mysqli_num_rows($result) == 0) {
            throw new Exception("Người thuê không tồn tại!");
        }

        // Thêm hợp đồng
        $query = "INSERT INTO hopdong (ID_hopdong, Ngay_bat_dau, Ngay_ket_thuc, Tien_coc, ID_phong, ID_nguoithue, Hinh_thuc_thanh_toan)
                  VALUES ('$id_hopdong', '$ngay_bat_dau', '$ngay_ket_thuc', $tien_coc, '$id_phong', '$id_nguoithue', '$hinh_thuc_thanh_toan')";
        $result = mysqli_query($conn, $query);
        if (!$result) {
            throw new Exception("Lỗi khi thêm hợp đồng: " . mysqli_error($conn));
        }

        // Commit giao dịch
        mysqli_commit($conn);
        return true;
    } catch (Exception $e) {
        // Rollback giao dịch nếu có lỗi
        mysqli_rollback($conn);
        error_log("Lỗi trong addHopDong: " . $e->getMessage(), 3, "debug.log");
        return false;
    }
}

// Hàm sửa hợp đồng
function updateHopDong($id_hopdong, $ngay_bat_dau, $ngay_ket_thuc, $tien_coc, $id_phong, $id_nguoithue, $hinh_thuc_thanh_toan) {
    global $conn;

    $id_hopdong = mysqli_real_escape_string($conn, $id_hopdong);
    $ngay_bat_dau = mysqli_real_escape_string($conn, $ngay_bat_dau);
    $ngay_ket_thuc = mysqli_real_escape_string($conn, $ngay_ket_thuc);
    $tien_coc = floatval($tien_coc);
    $id_phong = mysqli_real_escape_string($conn, $id_phong);
    $id_nguoithue = mysqli_real_escape_string($conn, $id_nguoithue);
    $hinh_thuc_thanh_toan = mysqli_real_escape_string($conn, $hinh_thuc_thanh_toan);

    // Bắt đầu giao dịch
    mysqli_begin_transaction($conn);

    try {
        // Kiểm tra xem hợp đồng có tồn tại không
        $check_hopdong_sql = "SELECT ID_hopdong FROM hopdong WHERE ID_hopdong = '$id_hopdong'";
        $result = mysqli_query($conn, $check_hopdong_sql);
        if (!$result || mysqli_num_rows($result) == 0) {
            throw new Exception("Hợp đồng không tồn tại!");
        }

        // Kiểm tra xem phòng trọ có tồn tại không
        $check_phong_sql = "SELECT Trang_thai FROM phong_tro WHERE ID_phong = '$id_phong'";
        $result = mysqli_query($conn, $check_phong_sql);
        if (!$result || mysqli_num_rows($result) == 0) {
            throw new Exception("Phòng trọ không tồn tại!");
        }

        // Kiểm tra người thuê có tồn tại không
        $check_nguoithue_sql = "SELECT ID_nguoithue FROM nguoithue WHERE ID_nguoithue = '$id_nguoithue'";
        $result = mysqli_query($conn, $check_nguoithue_sql);
        if (!$result || mysqli_num_rows($result) == 0) {
            throw new Exception("Người thuê không tồn tại!");
        }

        // Cập nhật hợp đồng
        $query = "UPDATE hopdong 
                  SET Ngay_bat_dau = '$ngay_bat_dau', Ngay_ket_thuc = '$ngay_ket_thuc', Tien_coc = $tien_coc, 
                      ID_phong = '$id_phong', ID_nguoithue = '$id_nguoithue', Hinh_thuc_thanh_toan = '$hinh_thuc_thanh_toan'
                  WHERE ID_hopdong = '$id_hopdong'";
        $result = mysqli_query($conn, $query);
        if (!$result) {
            throw new Exception("Lỗi khi cập nhật hợp đồng: " . mysqli_error($conn));
        }

        // Commit giao dịch
        mysqli_commit($conn);
        return true;
    } catch (Exception $e) {
        // Rollback giao dịch nếu có lỗi
        mysqli_rollback($conn);
        error_log("Lỗi trong updateHopDong: " . $e->getMessage(), 3, "debug.log");
        return false;
    }
}

// Hàm xóa hợp đồng
function deleteHopDong($id_hopdong) {
    global $conn;

    $id_hopdong = mysqli_real_escape_string($conn, $id_hopdong);
    
    // Bắt đầu giao dịch
    mysqli_begin_transaction($conn);

    try {
        // Kiểm tra xem hợp đồng có giao dịch thanh toán không
        $query = "SELECT COUNT(*) as count FROM thanhtoan WHERE ID_hopdong = '$id_hopdong'";
        $result = mysqli_query($conn, $query);
        if (!$result) {
            throw new Exception("Lỗi kiểm tra giao dịch thanh toán: " . mysqli_error($conn));
        }
        $row = mysqli_fetch_assoc($result);
        if ($row['count'] > 0) {
            throw new Exception("Không thể xóa hợp đồng vì đã có giao dịch thanh toán liên quan!");
        }

        // Xóa hợp đồng
        $query = "DELETE FROM hopdong WHERE ID_hopdong = '$id_hopdong'";
        $result = mysqli_query($conn, $query);
        if (!$result) {
            throw new Exception("Lỗi khi xóa hợp đồng: " . mysqli_error($conn));
        }

        // Commit giao dịch
        mysqli_commit($conn);
        return true;
    } catch (Exception $e) {
        // Rollback giao dịch nếu có lỗi
        mysqli_rollback($conn);
        error_log("Lỗi trong deleteHopDong: " . $e->getMessage(), 3, "debug.log");
        return false;
    }
}

