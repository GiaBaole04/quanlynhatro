<?php
include 'connect.php';
include 'khuvucFunction.php';

// Kiểm tra kết nối trước khi dùng
if (!$conn) {
    die("Kết nối cơ sở dữ liệu thất bại: " . mysqli_connect_error());
}

// Đếm số phòng có trạng thái trống
function getPhongTrongCount() {
    global $conn;
    $result = mysqli_query($conn, "SELECT COUNT(*) as total FROM phong_tro WHERE Trang_thai = 'Trống'");
    if ($result === false) {
        echo "Lỗi truy vấn: " . mysqli_error($conn);
        return 0;
    }
    $row = mysqli_fetch_assoc($result);
    return $row['total'] ?? 0;
}

// Đếm số phòng có trạng thái đã thuê
function getPhongThueCount() {
    global $conn;
    $result = mysqli_query($conn, "SELECT COUNT(*) as total FROM phong_tro WHERE Trang_thai = 'Đã thuê'");
    if ($result === false) {
        echo "Lỗi truy vấn: " . mysqli_error($conn);
        return 0;
    }
    $row = mysqli_fetch_assoc($result);
    return $row['total'] ?? 0;
}

// Tính tổng doanh thu từ các hợp đồng còn hiệu lực trong tháng hiện tại
function getDoanhThuThang() {
    global $conn;
    $month = date('m');
    $year = date('Y');

    $query = "
        SELECT SUM(p.Gia_thue) as total 
        FROM hopdong hd
        JOIN phong_tro p ON hd.ID_phong = p.ID_phong
        WHERE p.Trang_thai = 'Đã thuê'
        AND MONTH(hd.Ngay_bat_dau) <= ?
        AND YEAR(hd.Ngay_bat_dau) <= ?
        AND (hd.Ngay_ket_thuc IS NULL OR (MONTH(hd.Ngay_ket_thuc) >= ? AND YEAR(hd.Ngay_ket_thuc) >= ?))
    ";

    $stmt = mysqli_prepare($conn, $query);
    if ($stmt === false) {
        echo "Lỗi chuẩn bị truy vấn: " . mysqli_error($conn);
        return 0;
    }

    mysqli_stmt_bind_param($stmt, "iiii", $month, $year, $month, $year);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

    if ($result === false) {
        echo "Lỗi truy vấn: " . mysqli_error($conn);
        return 0;
    }

    $row = mysqli_fetch_assoc($result);
    mysqli_stmt_close($stmt);
    return $row['total'] ?? 0;
}

// Lấy danh sách tất cả nhà trọ từ bảng nhatro
function getNhaTroList() {
    global $conn;
    $result = mysqli_query($conn, "SELECT ID_nhatro, Ten_nhatro FROM nhatro");
    if ($result === false) {
        echo "Lỗi truy vấn: " . mysqli_error($conn);
        return [];
    }
    $nhatro = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $nhatro[] = $row;
    }
    return $nhatro;
}

// Lấy danh sách phòng trọ với phân trang
function getPhongTroList($filters = [], $page = 1, $limit = 4) {
    global $conn;

    // Truy vấn để đếm tổng số phòng trọ (dùng để tính tổng số trang)
    $count_query = "
        SELECT COUNT(*) as total 
        FROM phong_tro p 
        JOIN nhatro n ON p.ID_nhatro = n.ID_nhatro 
        JOIN xa_phuong x ON n.ID_xa = x.ID_xa 
        JOIN khuvuc k ON x.ID_khuvuc = k.ID_khuvuc
    ";

    $conditions = [];
    $params = [];
    $types = "";

    if (!empty($filters['khu_vuc'])) {
        $conditions[] = "x.ID_khuvuc = ?";
        $params[] = $filters['khu_vuc'];
        $types .= "s";
    }
    if (!empty($filters['nha_tro'])) {
        $conditions[] = "p.ID_nhatro = ?";
        $params[] = $filters['nha_tro'];
        $types .= "s";
    }
    if (!empty($filters['gia_tien'])) {
        if ($filters['gia_tien'] == '5000000') {
            $conditions[] = "p.Gia_thue >= ?";
            $params[] = 5000000;
            $types .= "d";
        } else {
            list($min, $max) = explode('-', $filters['gia_tien']);
            $conditions[] = "p.Gia_thue BETWEEN ? AND ?";
            $params[] = $min ? $min : 0;
            $params[] = $max ? $max : 999999999;
            $types .= "dd";
        }
    }
    if (!empty($filters['dien_tich'])) {
        if ($filters['dien_tich'] == '50') {
            $conditions[] = "p.Dien_tich >= ?";
            $params[] = 50;
            $types .= "d";
        } else {
            list($min, $max) = explode('-', $filters['dien_tich']);
            $conditions[] = "p.Dien_tich BETWEEN ? AND ?";
            $params[] = $min ? $min : 0;
            $params[] = $max ? $max : 999999;
            $types .= "dd";
        }
    }
    if (!empty($filters['khu_vuc_filter'])) {
        $conditions[] = "x.ID_khuvuc = ?";
        $params[] = $filters['khu_vuc_filter'];
        $types .= "s";
    }

    if (!empty($conditions)) {
        $count_query .= " WHERE " . implode(" AND ", $conditions);
    }

    // Đếm tổng số phòng trọ
    $stmt = mysqli_prepare($conn, $count_query);
    if ($stmt === false) {
        echo "Lỗi chuẩn bị truy vấn (đếm): " . mysqli_error($conn);
        return ['phongtro' => [], 'total_pages' => 0];
    }

    if (!empty($params)) {
        mysqli_stmt_bind_param($stmt, $types, ...$params);
    }

    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $row = mysqli_fetch_assoc($result);
    $total_phongtro = $row['total'] ?? 0;
    mysqli_stmt_close($stmt);

    // Tính tổng số trang
    $total_pages = ceil($total_phongtro / $limit);

    // Tính offset (vị trí bắt đầu của trang hiện tại)
    $offset = ($page - 1) * $limit;

    // Truy vấn lấy danh sách phòng trọ cho trang hiện tại
    $query = "
        SELECT p.*, n.Ten_nhatro, n.Dia_chi, k.Ten_khuvuc 
        FROM phong_tro p 
        JOIN nhatro n ON p.ID_nhatro = n.ID_nhatro 
        JOIN xa_phuong x ON n.ID_xa = x.ID_xa 
        JOIN khuvuc k ON x.ID_khuvuc = k.ID_khuvuc
    ";

    if (!empty($conditions)) {
        $query .= " WHERE " . implode(" AND ", $conditions);
    }
    $query .= " ORDER BY p.ID_phong ASC LIMIT ? OFFSET ?";

    $stmt = mysqli_prepare($conn, $query);
    if ($stmt === false) {
        echo "Lỗi chuẩn bị truy vấn: " . mysqli_error($conn);
        return ['phongtro' => [], 'total_pages' => 0];
    }

    // Thêm tham số LIMIT và OFFSET vào params
    $params[] = $limit;
    $params[] = $offset;
    $types .= "ii";

    mysqli_stmt_bind_param($stmt, $types, ...$params);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

    if ($result === false) {
        echo "Lỗi truy vấn: " . mysqli_error($conn);
        return ['phongtro' => [], 'total_pages' => 0];
    }

    $phongtro = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $phongtro[] = $row;
    }

    mysqli_stmt_close($stmt);
    return [
        'phongtro' => $phongtro,
        'total_pages' => $total_pages
    ];
}

// Lấy danh sách hợp đồng sắp hết hạn
function getHopDongSapHetHan($days = 30) {
    global $conn;

    $currentDate = date('Y-m-d');
    $limitDate = date('Y-m-d', strtotime("+$days days"));

    $query = "
        SELECT 
            hd.ID_hopdong,
            p.Ten_phong,
            nt.Ten_nhatro,
            ngt.Ho_ten,
            hd.Ngay_ket_thuc,
            DATEDIFF(hd.Ngay_ket_thuc, CURDATE()) AS So_ngay_con_lai
        FROM 
            hopdong hd
        JOIN 
            phong_tro p ON hd.ID_phong = p.ID_phong
        JOIN 
            nhatro nt ON p.ID_nhatro = nt.ID_nhatro
        JOIN 
            nguoithue ngt ON hd.ID_nguoithue = ngt.ID_nguoithue
        WHERE 
            hd.Ngay_ket_thuc BETWEEN ? AND ?
        ORDER BY 
            hd.Ngay_ket_thuc ASC
    ";

    $stmt = mysqli_prepare($conn, $query);
    if ($stmt === false) {
        echo "Lỗi chuẩn bị truy vấn: " . mysqli_error($conn);
        return [];
    }

    mysqli_stmt_bind_param($stmt, "ss", $currentDate, $limitDate);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

    if ($result === false) {
        echo "Lỗi truy vấn: " . mysqli_error($conn);
        return [];
    }

    $hopdong_list = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $hopdong_list[] = $row;
    }

    mysqli_stmt_close($stmt);
    return $hopdong_list;
}
function getPhongTroById($id_phong) {
    global $conn;
    $id_phong = mysqli_real_escape_string($conn, $id_phong);
    $query = "SELECT pt.*, nt.Ten_nhatro, nt.Dia_chi 
              FROM phong_tro pt 
              JOIN nhatro nt ON pt.ID_nhatro = nt.ID_nhatro 
              WHERE pt.ID_phong = '$id_phong'";
    $result = mysqli_query($conn, $query);
    if (!$result) {
        die("Lỗi truy vấn phòng trọ: " . mysqli_error($conn));
    }
    return mysqli_fetch_assoc($result);
}
?>