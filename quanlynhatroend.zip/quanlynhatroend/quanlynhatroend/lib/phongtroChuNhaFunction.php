<?php


function getNextPhongTroId($conn) {
    $sql = "SELECT ID_phong FROM phong_tro WHERE ID_phong LIKE 'P%' ORDER BY LENGTH(ID_phong) DESC, ID_phong DESC LIMIT 1";
    $result = mysqli_query($conn, $sql);
    if ($row = mysqli_fetch_assoc($result)) {
        $last_id = $row['ID_phong'];
        $number = (int)preg_replace('/\D/', '', $last_id);
        $next_number = $number + 1;
    } else {
        $next_number = 1;
    }
    return 'P' . str_pad($next_number, 2, '0', STR_PAD_LEFT);
}

// Lấy danh sách phòng trọ của chủ nhà, phòng "Chờ duyệt" lên đầu
function getPhongTroByChuNha($conn, $id_chunha, $search = '', $page = 1, $limit = 6) {
    $offset = ($page - 1) * $limit;
    $sql = "SELECT p.*, n.Ten_nhatro FROM phong_tro p 
            JOIN nhatro n ON p.ID_nhatro = n.ID_nhatro
            WHERE n.ID_user = ?";
    $params = [$id_chunha];
    $types = "i";
    if ($search !== '') {
        $sql .= " AND (p.Ten_phong LIKE ? OR n.Ten_nhatro LIKE ?)";
        $search_param = '%' . $search . '%';
        $params[] = $search_param;
        $params[] = $search_param;
        $types .= "ss";
    }
    $sql .= " ORDER BY FIELD(p.Trang_thai_duyet, 'Chờ duyệt', 'Đã duyệt', 'Từ chối'), p.ID_phong DESC LIMIT ? OFFSET ?";
    $params[] = $limit;
    $params[] = $offset;
    $types .= "ii";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, $types, ...$params);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    $list = [];
    while ($row = mysqli_fetch_assoc($result)) $list[] = $row;

    // Đếm tổng số trang
    $count_sql = "SELECT COUNT(*) as total FROM phong_tro p JOIN nhatro n ON p.ID_nhatro = n.ID_nhatro WHERE n.ID_user = ?";
    $count_params = [$id_chunha];
    $count_types = "i";
    if ($search !== '') {
        $count_sql .= " AND (p.Ten_phong LIKE ? OR n.Ten_nhatro LIKE ?)";
        $count_params[] = $search_param;
        $count_params[] = $search_param;
        $count_types .= "ss";
    }
    $count_stmt = mysqli_prepare($conn, $count_sql);
    mysqli_stmt_bind_param($count_stmt, $count_types, ...$count_params);
    mysqli_stmt_execute($count_stmt);
    $count_result = mysqli_stmt_get_result($count_stmt);
    $total = mysqli_fetch_assoc($count_result)['total'];
    $total_pages = ceil($total / $limit);

    return ['phongtro'=>$list, 'total_pages'=>$total_pages];
}

// Thêm phòng trọ mới (chủ nhà)
function addPhongTroByChuNha($conn, $ten_phong, $gia_thue, $dien_tich, $id_nhatro, $id_chunha, $trang_thai = 'Trống', $anh = null) {
    // Kiểm tra nhà trọ có thuộc chủ nhà không
    $check = mysqli_prepare($conn, "SELECT 1 FROM nhatro WHERE ID_nhatro=? AND ID_user=?");
    mysqli_stmt_bind_param($check, "si", $id_nhatro, $id_chunha);
    mysqli_stmt_execute($check);
    mysqli_stmt_store_result($check);
    if (mysqli_stmt_num_rows($check) == 0) {
        return ['success'=>false, 'message'=>'Bạn không có quyền thêm phòng vào nhà trọ này!'];
    }
    mysqli_stmt_close($check);

    // Sử dụng hàm sinh ID tự động
    $id_phong = getNextPhongTroId($conn);
    $trang_thai_duyet = 'Chờ duyệt';

    // Đúng thứ tự cột: ID_phong, Ten_phong, Gia_thue, Dien_tich, Anh, ID_nhatro, Trang_thai, Trang_thai_duyet
    $sql = "INSERT INTO phong_tro (ID_phong, Ten_phong, Gia_thue, Dien_tich, Anh, ID_nhatro, Trang_thai, Trang_thai_duyet)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
    $stmt = mysqli_prepare($conn, $sql);
    if (!$stmt) return ['success'=>false, 'message'=>mysqli_error($conn)];
    mysqli_stmt_bind_param($stmt, "ssdsssss", $id_phong, $ten_phong, $gia_thue, $dien_tich, $anh, $id_nhatro, $trang_thai, $trang_thai_duyet);
    if (mysqli_stmt_execute($stmt)) {
        return ['success'=>true, 'message'=>'Thêm phòng trọ thành công! Vui lòng chờ admin duyệt.'];
    }
    return ['success'=>false, 'message'=>mysqli_stmt_error($stmt)];
}

// Sửa phòng trọ (chủ nhà)header("Location: login.php");
function updatePhongTroByChuNha($conn, $id_phong, $ten_phong, $gia_thue, $dien_tich, $id_nhatro, $id_chunha, $trang_thai = 'Trống') {
    // Kiểm tra phòng trọ có thuộc nhà trọ của chủ nhà không
    $check = mysqli_prepare($conn, "SELECT 1 FROM phong_tro p JOIN nhatro n ON p.ID_nhatro=n.ID_nhatro WHERE p.ID_phong=? AND n.ID_user=?");
    mysqli_stmt_bind_param($check, "si", $id_phong, $id_chunha);
    mysqli_stmt_execute($check);
    mysqli_stmt_store_result($check);
    if (mysqli_stmt_num_rows($check) == 0) {
        return ['success'=>false, 'message'=>'Bạn không có quyền sửa phòng trọ này!'];
    }
    mysqli_stmt_close($check);

    $trang_thai_duyet = 'Chờ duyệt';
    $sql = "UPDATE phong_tro SET Ten_phong=?, Gia_thue=?, Dien_tich=?, ID_nhatro=?, Trang_thai=?, Trang_thai_duyet=?
            WHERE ID_phong=?";
    $stmt = mysqli_prepare($conn, $sql);
    if (!$stmt) return ['success'=>false, 'message'=>mysqli_error($conn)];
    mysqli_stmt_bind_param($stmt, "sdsssss", $ten_phong, $gia_thue, $dien_tich, $id_nhatro, $trang_thai, $trang_thai_duyet, $id_phong);
    if (mysqli_stmt_execute($stmt)) {
        return ['success'=>true, 'message'=>'Cập nhật phòng trọ thành công! Vui lòng chờ admin duyệt lại.'];
    }
    return ['success'=>false, 'message'=>mysqli_stmt_error($stmt)];
}

// Xóa phòng trọ (chủ nhà)
function deletePhongTroByChuNha($conn, $id_phong, $id_chunha) {
    // Kiểm tra phòng trọ có thuộc nhà trọ của chủ nhà không
    $check = mysqli_prepare($conn, "SELECT 1 FROM phong_tro p JOIN nhatro n ON p.ID_nhatro=n.ID_nhatro WHERE p.ID_phong=? AND n.ID_user=?");
    mysqli_stmt_bind_param($check, "si", $id_phong, $id_chunha);
    mysqli_stmt_execute($check);
    mysqli_stmt_store_result($check);
    if (mysqli_stmt_num_rows($check) == 0) {
        return false;
    }
    mysqli_stmt_close($check);

    $sql = "DELETE FROM phong_tro WHERE ID_phong=?";
    $stmt = mysqli_prepare($conn, $sql);
    if (!$stmt) return false;
    mysqli_stmt_bind_param($stmt, "s", $id_phong);
    return mysqli_stmt_execute($stmt);
}

// Lấy 1 phòng trọ theo ID (chỉ nếu thuộc chủ nhà)
function getPhongTroByIdChuNha($conn, $id_phong, $id_chunha) {
    $sql = "SELECT p.* FROM phong_tro p JOIN nhatro n ON p.ID_nhatro = n.ID_nhatro WHERE p.ID_phong=? AND n.ID_user=?";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "si", $id_phong, $id_chunha);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    return mysqli_fetch_assoc($result);
}