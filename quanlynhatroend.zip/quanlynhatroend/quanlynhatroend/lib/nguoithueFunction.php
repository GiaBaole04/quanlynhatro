<?php
if (!isset($conn)) {
    include 'connect.php';
}

// Hàm tạo ID_nguoithue tự động (KH01, KH02,...)
function generateNguoiThueId() {
    global $conn;
    
    $query = "SELECT ID_nguoithue FROM nguoithue ORDER BY ID_nguoithue DESC LIMIT 1";
    $result = mysqli_query($conn, $query);
    
    if ($result && mysqli_num_rows($result) > 0) {
        $last_id = mysqli_fetch_assoc($result)['ID_nguoithue'];
        $number = (int)substr($last_id, 2);
        $new_number = $number + 1;
        return "KH" . sprintf("%02d", $new_number);
    } else {
        return "KH01";
    }
}

// Hàm lấy danh sách người thuê (hỗ trợ tìm kiếm và phân trang)
function getNguoiThueList($search = '', $page = 1, $limit = 6) {
    global $conn;

    // Truy vấn để đếm tổng số người thuê (dùng để tính tổng số trang)
    $count_sql = "SELECT COUNT(*) as total 
                  FROM nguoithue nt 
                  LEFT JOIN hopdong hd ON nt.ID_nguoithue = hd.ID_nguoithue 
                  LEFT JOIN phong_tro pt ON hd.ID_phong = pt.ID_phong";
    if (!empty($search)) {
        $search = mysqli_real_escape_string($conn, $search);
        $count_sql .= " WHERE nt.Ho_ten LIKE '%$search%' 
                        OR nt.So_dien_thoai LIKE '%$search%' 
                        OR nt.CCCD LIKE '%$search%'";
    }

    $result = mysqli_query($conn, $count_sql);
    if (!$result) {
        die("Lỗi truy vấn: " . mysqli_error($conn));
    }
    $row = mysqli_fetch_assoc($result);
    $total_nguoithue = $row['total'] ?? 0;

    // Tính tổng số trang
    $total_pages = ceil($total_nguoithue / $limit);

    // Tính offset (vị trí bắt đầu của trang hiện tại)
    $offset = ($page - 1) * $limit;

    // Truy vấn lấy danh sách người thuê cho trang hiện tại
    $query = "SELECT nt.*, hd.Ngay_bat_dau, pt.Ten_phong, ntro.Ten_nhatro
    FROM nguoithue nt 
    LEFT JOIN hopdong hd ON nt.ID_nguoithue = hd.ID_nguoithue 
    LEFT JOIN phong_tro pt ON hd.ID_phong = pt.ID_phong
    LEFT JOIN nhatro ntro ON pt.ID_nhatro = ntro.ID_nhatro";
    if (!empty($search)) {
        $query .= " WHERE nt.Ho_ten LIKE '%$search%' 
                    OR nt.So_dien_thoai LIKE '%$search%' 
                    OR nt.CCCD LIKE '%$search%'";
    }
    $query .= " LIMIT $limit OFFSET $offset";

    $result = mysqli_query($conn, $query);
    if (!$result) {
        echo "Lỗi truy vấn: " . mysqli_error($conn);
        return [];
    }

    $nguoithue_list = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $nguoithue_list[] = $row;
    }

    return [
        'nguoithue' => $nguoithue_list,
        'total_pages' => $total_pages
    ];
}


// Hàm thêm người thuê mới
function addNguoiThue($ho_ten, $so_dien_thoai, $cccd, $gioi_tinh) {
    global $conn;

    $id_nguoithue = generateNguoiThueId();
    $ho_ten = mysqli_real_escape_string($conn, $ho_ten);
    $so_dien_thoai = mysqli_real_escape_string($conn, $so_dien_thoai);
    $cccd = mysqli_real_escape_string($conn, $cccd);
    $gioi_tinh = mysqli_real_escape_string($conn, $gioi_tinh);

    $query = "INSERT INTO nguoithue (ID_nguoithue, Ho_ten, So_dien_thoai, CCCD, gioitinh) 
              VALUES ('$id_nguoithue', '$ho_ten', '$so_dien_thoai', '$cccd', '$gioi_tinh')";
    
    return mysqli_query($conn, $query);
}

// Hàm cập nhật thông tin người thuê
function updateNguoiThue($id_nguoithue, $ho_ten, $so_dien_thoai, $cccd, $gioi_tinh) {
    global $conn;

    if (checkDuplicateCCCD($cccd, $id_nguoithue)) {
        return false;
    }

    $id_nguoithue = mysqli_real_escape_string($conn, $id_nguoithue);
    $ho_ten = mysqli_real_escape_string($conn, $ho_ten);
    $so_dien_thoai = mysqli_real_escape_string($conn, $so_dien_thoai);
    $cccd = mysqli_real_escape_string($conn, $cccd);
    $gioi_tinh = mysqli_real_escape_string($conn, $gioi_tinh);

    $query = "UPDATE nguoithue 
              SET Ho_ten = '$ho_ten', So_dien_thoai = '$so_dien_thoai', CCCD = '$cccd', gioitinh = '$gioi_tinh'
              WHERE ID_nguoithue = '$id_nguoithue'";
    
    return mysqli_query($conn, $query);
}

// Hàm xóa người thuê
function deleteNguoiThue($id_nguoithue) {
    global $conn;

    $id_nguoithue = mysqli_real_escape_string($conn, $id_nguoithue);

    // Kiểm tra xem người thuê có hợp đồng hay không
    $check_query = "SELECT COUNT(*) as count FROM hopdong WHERE ID_nguoithue = '$id_nguoithue'";
    $check_result = mysqli_query($conn, $check_query);
    $row = mysqli_fetch_assoc($check_result);
    
    if ($row['count'] > 0) {
        return false; // Không thể xóa nếu người thuê đang có hợp đồng
    }

    $query = "DELETE FROM nguoithue WHERE ID_nguoithue = '$id_nguoithue'";
    return mysqli_query($conn, $query);
}

// Hàm kiểm tra trùng lặp CCCD (ngoại trừ bản ghi hiện tại)
function checkDuplicateCCCD($cccd, $id_nguoithue = null) {
    global $conn;

    $cccd = mysqli_real_escape_string($conn, $cccd);
    $query = "SELECT COUNT(*) as count FROM nguoithue WHERE CCCD = '$cccd'";
    
    // Nếu đang cập nhật, bỏ qua bản ghi của người thuê hiện tại
    if ($id_nguoithue !== null) {
        $id_nguoithue = mysqli_real_escape_string($conn, $id_nguoithue);
        $query .= " AND ID_nguoithue != '$id_nguoithue'";
    }

    $result = mysqli_query($conn, $query);
    if (!$result) {
        die("Lỗi truy vấn: " . mysqli_error($conn));
    }
    $row = mysqli_fetch_assoc($result);
    return $row['count'] > 0;
}
?>