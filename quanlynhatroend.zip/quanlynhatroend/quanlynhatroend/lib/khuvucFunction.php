<?php

include 'connect.php';

// Hàm tìm ID_khuvuc tiếp theo theo định dạng KVxx
function getNextAvailableId($table, $id_column) {
    global $conn;
    $result = mysqli_query($conn, "SELECT $id_column FROM $table ORDER BY $id_column");
    $used_ids = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $used_ids[] = $row[$id_column];
    }

    // Tìm ID tiếp theo theo định dạng KVxx
    $next_id = 1;
    $prefix = 'KV';
    while (true) {
        $candidate_id = $prefix . str_pad($next_id, 2, '0', STR_PAD_LEFT);
        if (!in_array($candidate_id, $used_ids)) {
            return $candidate_id;
        }
        $next_id++;
    }
}

// Lấy danh sách khu vực (hỗ trợ tìm kiếm và phân trang)
function getAreas($search = '', $page = 1, $limit = 5) {
    global $conn;
    $search = mysqli_real_escape_string($conn, $search); // Bảo mật

    // Truy vấn để đếm tổng số khu vực (dùng để tính tổng số trang)
    $count_sql = "SELECT COUNT(*) as total FROM khuvuc WHERE 1=1";
    if (!empty($search)) {
        $count_sql .= " AND Ten_khuvuc LIKE '%$search%'";
    }

    $result = mysqli_query($conn, $count_sql);
    $row = mysqli_fetch_assoc($result);
    $total_areas = $row['total'] ?? 0;

    // Tính tổng số trang
    $total_pages = ceil($total_areas / $limit);

    // Tính offset (vị trí bắt đầu của trang hiện tại)
    $offset = ($page - 1) * $limit;

    // Truy vấn lấy danh sách khu vực cho trang hiện tại
    $sql = "SELECT * FROM khuvuc WHERE 1=1";
    if (!empty($search)) {
        $sql .= " AND Ten_khuvuc LIKE '%$search%'";
    }
    $sql .= " ORDER BY ID_khuvuc ASC LIMIT $limit OFFSET $offset";

    $result = mysqli_query($conn, $sql);
    $areas = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $areas[] = $row;
    }

    return [
        'areas' => $areas,
        'total_pages' => $total_pages,
        'search' => $search // Thêm từ khóa tìm kiếm vào kết quả trả về
    ];
}

// Thêm khu vực mới
function addArea($ten_khuvuc) {
    global $conn;
    $ten_khuvuc = mysqli_real_escape_string($conn, $ten_khuvuc);

    // Kiểm tra xem Ten_khuvuc đã tồn tại chưa
    $check_sql = "SELECT COUNT(*) FROM khuvuc WHERE Ten_khuvuc = '$ten_khuvuc'";
    $check_result = mysqli_query($conn, $check_sql);
    $count = mysqli_fetch_row($check_result)[0];

    if ($count > 0) {
        return ['success' => false, 'message' => 'Tên khu vực đã tồn tại.'];
    }

    // Nếu không trùng, thêm mới
    $id_khuvuc = getNextAvailableId('khuvuc', 'ID_khuvuc');
    $insert_sql = "INSERT INTO khuvuc (ID_khuvuc, Ten_khuvuc) VALUES ('$id_khuvuc', '$ten_khuvuc')";
    if (mysqli_query($conn, $insert_sql)) {
        return ['success' => true, 'message' => 'Thêm khu vực thành công.'];
    } else {
        return ['success' => false, 'message' => 'Lỗi khi thêm khu vực: ' . mysqli_error($conn)];
    }
}

// Cập nhật khu vực
function updateArea($id_khuvuc, $ten_khuvuc) {
    global $conn;
    $id_khuvuc = mysqli_real_escape_string($conn, $id_khuvuc);
    $ten_khuvuc = mysqli_real_escape_string($conn, $ten_khuvuc);

    $sql = "UPDATE khuvuc SET Ten_khuvuc = '$ten_khuvuc' WHERE ID_khuvuc = '$id_khuvuc'";
    if (mysqli_query($conn, $sql)) {
        return true;
    } else {
        return false;
    }
}

// Xóa khu vực
function deleteArea($id_khuvuc) {
    global $conn;
    $id_khuvuc = mysqli_real_escape_string($conn, $id_khuvuc);

    $sql = "DELETE FROM khuvuc WHERE ID_khuvuc = '$id_khuvuc'";
    if (mysqli_query($conn, $sql)) {
        return true;
    } else {
        return false;
    }
}
?>