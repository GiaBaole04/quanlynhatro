<?php
// filepath: d:\XAMPP\htdocs\quanlynhatroend\lib\menuapp.php
//session_start(); // Khởi động session
include 'connect.php';
?>
<nav class="navbar navbar-expand-lg navbar-dark bg-primary">
    <div class="container">
        <a class="navbar-brand" href="#">Hệ Thống Quản Lý Nhà Trọ</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                <?php
                $lenhlaymenu = "SELECT * FROM menu";
                $chaylenh_lenhlaymenu = mysqli_query($conn, $lenhlaymenu);

                if ($chaylenh_lenhlaymenu === false) {
                    echo '<li class="nav-item"><a class="nav-link text-danger">Lỗi truy vấn menu: ' . mysqli_error($conn) . '</a></li>';
                } else {
                    $sodonglayduoc = mysqli_num_rows($chaylenh_lenhlaymenu);

                    if ($sodonglayduoc > 0) {
                        while ($docdulieu = mysqli_fetch_array($chaylenh_lenhlaymenu)) {
                            $tenmenu = $docdulieu["menu"];
                            $linkmenu = $docdulieu["url"];
                            echo '
                            <li class="nav-item">
                                <a class="nav-link" href="' . $linkmenu . '">' . $tenmenu . '</a>
                            </li>';
                        }
                    } else {
                        echo '<li class="nav-item"><a class="nav-link">Không có dữ liệu menu!</a></li>';
                    }
                }
                ?>
            </ul>
            <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
                <?php if (isset($_SESSION['user_id'])) { ?>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            <i class="fas fa-user-circle"></i>
                            <?php echo htmlspecialchars($_SESSION['username'] ?? 'Người dùng'); ?>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="userDropdown">
                            <li><a class="dropdown-item" href="logout.php">Đăng Xuất</a></li>
                        </ul>
                    </li>
                <?php } else { ?>
                    <li class="nav-item">
                        <a class="nav-link" href="login.php">
                            <i class="fas fa-sign-in-alt"></i> Đăng Nhập
                        </a>
                    </li>
                <?php } ?>
            </ul>
        </div>
    </div>
</nav>