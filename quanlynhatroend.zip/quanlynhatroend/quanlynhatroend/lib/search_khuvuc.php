<?php

error_reporting(E_ALL);
ini_set('display_errors', 1);

include 'connect.php';
include 'khuvucFunction.php';

$search = isset($_GET['search']) ? $_GET['search'] : '';

// Gọi hàm getAreas để lấy kết quả tìm kiếm
$result = getAreas($search, 1, 5); // Lấy tối đa 5 kết quả

$data = array();
if ($result && isset($result['areas'])) {
    $data = $result['areas'];
} else {
    $data = [];
}

header('Content-Type: application/json');
echo json_encode($data);
?>