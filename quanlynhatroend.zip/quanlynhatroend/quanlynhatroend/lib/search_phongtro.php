<?php
include 'connect.php';
include 'ptroFunction.php';

$search = isset($_GET['search']) ? $_GET['search'] : '';
$result = getPhongTroList($search, 1, 6); // lấy tối đa 6 phòng
$data = $result['phongtro'] ?? [];

header('Content-Type: application/json');
echo json_encode($data);
?>