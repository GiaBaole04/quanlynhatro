<?php
if (!isset($conn)) {
    include 'connect.php';
}
include_once 'commonFunctions.php';

// Hàm tạo ID_thanhtoan tự động (TT01, TT02,...)
function generateThanhToanId() {
    global $conn;
    
    $query = "SELECT ID_thanhtoan FROM thanhtoan ORDER BY ID_thanhtoan DESC LIMIT 1";
    $result = mysqli_query($conn, $query);
    
    if ($result && mysqli_num_rows($result) > 0) {
        $last_id = mysqli_fetch_assoc($result)['ID_thanhtoan'];
        $number = (int)substr($last_id, 2);
        $new_number = $number + 1;
        return "TT" . sprintf("%02d", $new_number);
    } else {
        return "TT01";
    }
}

// Hàm kiểm tra trùng lặp giao dịch
function checkDuplicateThanhToan($id_hopdong, $ngay_thanh_toan, $so_tien, $phuong_thuc) {
    global $conn;

    $id_hopdong = mysqli_real_escape_string($conn, $id_hopdong);
    $ngay_thanh_toan = mysqli_real_escape_string($conn, $ngay_thanh_toan);
    $so_tien = floatval($so_tien);
    $phuong_thuc = mysqli_real_escape_string($conn, $phuong_thuc);

    $query = "SELECT COUNT(*) as count FROM thanhtoan 
              WHERE ID_hopdong = '$id_hopdong' 
              AND Ngay_thanhtoan = '$ngay_thanh_toan' 
              AND So_tien = $so_tien 
              AND Phuong_thuc = '$phuong_thuc'";
    
    $result = mysqli_query($conn, $query);
    $row = mysqli_fetch_assoc($result);
    return $row['count'] > 0;
}

// Hàm kiểm tra ngày thanh toán có nằm trong khoảng thời gian hợp đồng không
function checkValidThanhToanDate($id_hopdong, $ngay_thanh_toan) {
    global $conn;

    $id_hopdong = mysqli_real_escape_string($conn, $id_hopdong);
    $ngay_thanh_toan = mysqli_real_escape_string($conn, $ngay_thanh_toan);

    $query = "SELECT Ngay_bat_dau, Ngay_ket_thuc FROM hopdong WHERE ID_hopdong = '$id_hopdong'";
    $result = mysqli_query($conn, $query);

    if ($result && mysqli_num_rows($result) > 0) {
        $hopdong = mysqli_fetch_assoc($result);
        $ngay_bat_dau = $hopdong['Ngay_bat_dau'];
        $ngay_ket_thuc = $hopdong['Ngay_ket_thuc'];

        return ($ngay_thanh_toan >= $ngay_bat_dau && $ngay_thanh_toan <= $ngay_ket_thuc);
    }

    return false;
}

// Hàm kiểm tra xem tháng đã được thanh toán chưa (dành cho hình thức trả hàng tháng)
function checkThangDaThanhToan($id_hopdong, $ngay_thanh_toan) {
    global $conn;

    $id_hopdong = mysqli_real_escape_string($conn, $id_hopdong);
    $ngay_thanh_toan = new DateTime($ngay_thanh_toan);
    $thang = $ngay_thanh_toan->format('m');
    $nam = $ngay_thanh_toan->format('Y');

    $query = "SELECT COUNT(*) as count FROM thanhtoan 
              WHERE ID_hopdong = '$id_hopdong' 
              AND MONTH(Ngay_thanhtoan) = '$thang' 
              AND YEAR(Ngay_thanhtoan) = '$nam'";
    
    $result = mysqli_query($conn, $query);
    $row = mysqli_fetch_assoc($result);
    return $row['count'] > 0;
}

// Hàm lấy danh sách giao dịch thanh toán (hỗ trợ phân trang)
function getThanhToanList($id_hopdong = '', $page = 1, $limit = 6) {
    global $conn;
    $id_hopdong = mysqli_real_escape_string($conn, $id_hopdong);

    // Truy vấn để đếm tổng số giao dịch (dùng để tính tổng số trang)
    $count_sql = "SELECT COUNT(*) as total 
                  FROM thanhtoan t
                  JOIN hopdong hd ON t.ID_hopdong = hd.ID_hopdong
                  JOIN nguoithue nt ON hd.ID_nguoithue = nt.ID_nguoithue
                  JOIN phong_tro pt ON hd.ID_phong = pt.ID_phong";
    if (!empty($id_hopdong)) {
        $count_sql .= " WHERE t.ID_hopdong = '$id_hopdong'";
    }

    $result = mysqli_query($conn, $count_sql);
    if (!$result) {
        error_log("Lỗi truy vấn đếm: " . mysqli_error($conn));
        return [
            'thanhtoan' => [],
            'total_pages' => 0
        ];
    }
    $row = mysqli_fetch_assoc($result);
    $total_thanhtoan = $row['total'] ?? 0;

    // Tính tổng số trang
    $total_pages = ceil($total_thanhtoan / $limit);

    // Tính offset (vị trí bắt đầu của trang hiện tại)
    $offset = ($page - 1) * $limit;

    // Truy vấn lấy danh sách giao dịch cho trang hiện tại
    $query = "SELECT t.ID_thanhtoan, t.ID_hopdong, t.Ngay_thanhtoan, t.So_tien, t.Phuong_thuc,
                     nt.Ho_ten, pt.Ten_phong, pt.Gia_thue, hd.Hinh_thuc_thanh_toan
              FROM thanhtoan t
              JOIN hopdong hd ON t.ID_hopdong = hd.ID_hopdong
              JOIN nguoithue nt ON hd.ID_nguoithue = nt.ID_nguoithue
              JOIN phong_tro pt ON hd.ID_phong = pt.ID_phong";
    
    if (!empty($id_hopdong)) {
        $query .= " WHERE t.ID_hopdong = '$id_hopdong'";
    }

    $query .= " LIMIT $limit OFFSET $offset";

    $result = mysqli_query($conn, $query);
    if (!$result) {
        error_log("Lỗi truy vấn danh sách: " . mysqli_error($conn));
        return [
            'thanhtoan' => [],
            'total_pages' => $total_pages
        ];
    }

    $thanhtoan_list = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $thanhtoan_list[] = $row;
    }

    return [
        'thanhtoan' => $thanhtoan_list,
        'total_pages' => $total_pages
    ];
}

// Hàm thêm giao dịch thanh toán mới
function addThanhToan($id_hopdong, $ngay_thanh_toan, $so_tien, $phuong_thuc) {
    global $conn;

    if (checkDuplicateThanhToan($id_hopdong, $ngay_thanh_toan, $so_tien, $phuong_thuc)) {
        return false;
    }

    if (!checkValidThanhToanDate($id_hopdong, $ngay_thanh_toan)) {
        return false;
    }

    $id_thanhtoan = generateThanhToanId();
    $id_hopdong = mysqli_real_escape_string($conn, $id_hopdong);
    $ngay_thanh_toan = mysqli_real_escape_string($conn, $ngay_thanh_toan);
    $so_tien = floatval($so_tien);
    $phuong_thuc = mysqli_real_escape_string($conn, $phuong_thuc);

    $query = "INSERT INTO thanhtoan (ID_thanhtoan, ID_hopdong, Ngay_thanhtoan, So_tien, Phuong_thuc)
              VALUES ('$id_thanhtoan', '$id_hopdong', '$ngay_thanh_toan', $so_tien, '$phuong_thuc')";
    
    return mysqli_query($conn, $query);
}
?>