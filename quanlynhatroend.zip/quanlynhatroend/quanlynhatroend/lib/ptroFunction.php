<?php
include 'connect.php';

// Hàm tạo ID_phong mới (P09, P10, ...)
function getNextPhongId() {
    global $conn;
    $result = mysqli_query($conn, "SELECT ID_phong FROM phong_tro ORDER BY ID_phong");
    if (!$result) {
        die("Lỗi truy vấn: " . mysqli_error($conn));
    }
    $used_ids = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $used_ids[] = $row['ID_phong'];
    }

    $next_id = 1;
    $prefix = 'P';
    while (true) {
        $formatted_id = $prefix . str_pad($next_id, 2, '0', STR_PAD_LEFT);
        if (!in_array($formatted_id, $used_ids)) {
            return $formatted_id;
        }
        $next_id++;
    }
}

// Lấy danh sách phòng trọ (hỗ trợ tìm kiếm và phân trang)
function getPhongTroList($search = '', $page = 1, $limit = 6) {
    global $conn;

    // Truy vấn để đếm tổng số phòng trọ (dùng để tính tổng số trang)
    $count_sql = "SELECT COUNT(*) as total 
                  FROM phong_tro p
                  JOIN nhatro n ON p.ID_nhatro = n.ID_nhatro
                  JOIN xa_phuong x ON n.ID_xa = x.ID_xa
                  JOIN khuvuc k ON x.ID_khuvuc = k.ID_khuvuc";
    if (!empty($search)) {
        $search = mysqli_real_escape_string($conn, $search);
        $count_sql .= " WHERE p.Ten_phong LIKE '%$search%' OR n.Ten_nhatro LIKE '%$search%'";
    }

    $result = mysqli_query($conn, $count_sql);
    if (!$result) {
        die("Lỗi truy vấn: " . mysqli_error($conn));
    }
    $row = mysqli_fetch_assoc($result);
    $total_phongtro = $row['total'] ?? 0;

    // Tính tổng số trang
    $total_pages = ceil($total_phongtro / $limit);

    // Tính offset (vị trí bắt đầu của trang hiện tại)
    $offset = ($page - 1) * $limit;

    // Truy vấn lấy danh sách phòng trọ cho trang hiện tại
    $query = "SELECT p.*, n.Ten_nhatro, x.Ten_xa, k.Ten_khuvuc 
              FROM phong_tro p
              JOIN nhatro n ON p.ID_nhatro = n.ID_nhatro
              JOIN xa_phuong x ON n.ID_xa = x.ID_xa
              JOIN khuvuc k ON x.ID_khuvuc = k.ID_khuvuc";
    
    if (!empty($search)) {
        $search = mysqli_real_escape_string($conn, $search);
        $query .= " WHERE p.Ten_phong LIKE '%$search%' OR n.Ten_nhatro LIKE '%$search%'";
    }
    
    $query .= " ORDER BY p.ID_phong DESC LIMIT $limit OFFSET $offset";
    
    $result = mysqli_query($conn, $query);
    if (!$result) {
        die("Lỗi truy vấn: " . mysqli_error($conn));
    }
    
    $phongtro = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $phongtro[] = $row;
    }
    
    return [
        'phongtro' => $phongtro,
        'total_pages' => $total_pages
    ];
}

function addPhongTro($ten_phong, $gia_thue, $dien_tich, $id_nhatro, $trang_thai) {
    global $conn;
    
    

    $ten_phong = mysqli_real_escape_string($conn, $ten_phong);
    $gia_thue = floatval($gia_thue);
    $dien_tich = floatval($dien_tich);
    $id_nhatro = mysqli_real_escape_string($conn, $id_nhatro);
    $trang_thai = mysqli_real_escape_string($conn, $trang_thai);
    
    // Kiểm tra ID_nhatro có tồn tại trong nhatro không
    $check_nhatro_sql = "SELECT COUNT(*) FROM nhatro WHERE ID_nhatro = '$id_nhatro'";
    $check_nhatro_result = mysqli_query($conn, $check_nhatro_sql);
    if (!$check_nhatro_result || mysqli_fetch_row($check_nhatro_result)[0] == 0) {
        return ['success' => false, 'message' => 'Nhà trọ không tồn tại! ID_nhatro = ' . $id_nhatro];
    }

    // Kiểm tra giá trị trang_thai hợp lệ
    if (!in_array($trang_thai, ['Trống', 'Đã thuê'])) {
        return ['success' => false, 'message' => 'Trạng thái không hợp lệ: ' . $trang_thai];
    }

    // Tạo ID_phong mới
    $id_phong = getNextPhongId();
    
    // Kiểm tra trạng thái "Đã thuê"
    if ($trang_thai == 'Đã thuê') {
        $check_query = "SELECT COUNT(*) as count FROM hopdong WHERE ID_phong = '$id_phong' AND Trang_thai = 'Đang thuê'";
        $check_result = mysqli_query($conn, $check_query);
        $row = mysqli_fetch_assoc($check_result);
        if ($row['count'] == 0) {
            return ['success' => false, 'message' => 'Không thể đặt trạng thái "Đã thuê" vì phòng chưa có hợp đồng.'];
        }
    }

    // Xử lý upload ảnh
    $anh_phong = '';
    if (!empty($_FILES['anh_phong']['name'])) {
        $target_dir = "uploads/";
        if (!is_dir($target_dir)) {
            mkdir($target_dir, 0777, true);
        }
        $target_file = $target_dir . basename($_FILES['anh_phong']['name']);
        if (move_uploaded_file($_FILES['anh_phong']['tmp_name'], $target_file)) {
            $anh_phong = $target_file;
        }
    }

    $query = "INSERT INTO phong_tro (ID_phong, Ten_phong, Gia_thue, Dien_tich, Anh, Trang_thai, ID_nhatro)
              VALUES (?, ?, ?, ?, ?, ?, ?)";
    $stmt = mysqli_prepare($conn, $query);
    if (!$stmt) {
        return ['success' => false, 'message' => 'Lỗi chuẩn bị truy vấn: ' . mysqli_error($conn)];
    }

    // Debug giá trị trước khi bind
    

    mysqli_stmt_bind_param($stmt, "ssdssss", $id_phong, $ten_phong, $gia_thue, $dien_tich, $anh_phong, $trang_thai, $id_nhatro);
    $result = mysqli_stmt_execute($stmt);
    
    if ($result) {
        return ['success' => true, 'message' => 'Thêm phòng trọ thành công!'];
    } else {
        return ['success' => false, 'message' => 'Lỗi khi thêm phòng trọ: ' . mysqli_stmt_error($stmt)];
    }
}

function updatePhongTro($id_phong, $ten_phong, $gia_thue, $dien_tich, $id_nhatro, $trang_thai) {
    global $conn;
    
    $id_phong = mysqli_real_escape_string($conn, $id_phong);
    $ten_phong = mysqli_real_escape_string($conn, $ten_phong);
    $gia_thue = floatval($gia_thue);
    $dien_tich = floatval($dien_tich);
    $id_nhatro = mysqli_real_escape_string($conn, $id_nhatro);
    $trang_thai = mysqli_real_escape_string($conn, $trang_thai);
    
    // Kiểm tra ID_nhatro có tồn tại trong nhatro không
    $check_nhatro_sql = "SELECT COUNT(*) FROM nhatro WHERE ID_nhatro = '$id_nhatro'";
    $check_nhatro_result = mysqli_query($conn, $check_nhatro_sql);
    if (!$check_nhatro_result || mysqli_fetch_row($check_nhatro_result)[0] == 0) {
        return ['success' => false, 'message' => 'Nhà trọ không tồn tại! ID_nhatro = ' . $id_nhatro];
    }

    // Kiểm tra trạng thái "Đã thuê"
    if ($trang_thai == 'Đã thuê') {
        $check_query = "SELECT COUNT(*) as count FROM hopdong WHERE ID_phong = '$id_phong' AND Trang_thai = 'Đang thuê'";
        $check_result = mysqli_query($conn, $check_query);
        $row = mysqli_fetch_assoc($check_result);
        if ($row['count'] == 0) {
            return ['success' => false, 'message' => 'Không thể đặt trạng thái "Đã thuê" vì phòng chưa có hợp đồng.'];
        }
    }

    // Xử lý upload ảnh nếu có
    $anh_update = '';
    if (!empty($_FILES['anh_phong']['name'])) {
        $target_dir = "uploads/";
        $target_file = $target_dir . basename($_FILES['anh_phong']['name']);
        if (move_uploaded_file($_FILES['anh_phong']['tmp_name'], $target_file)) {
            $anh_update = ", Anh = '$target_file'";
        }
    }
    
    $query = "UPDATE phong_tro SET 
              Ten_phong = ?, 
              Gia_thue = ?, 
              Dien_tich = ?, 
              Trang_thai = ?, 
              ID_nhatro = ?
              $anh_update
              WHERE ID_phong = ?";
    $stmt = mysqli_prepare($conn, $query);
    if (!$stmt) {
        return ['success' => false, 'message' => 'Lỗi chuẩn bị truy vấn: ' . mysqli_error($conn)];
    }
    mysqli_stmt_bind_param($stmt, "sdddss", $ten_phong, $gia_thue, $dien_tich, $trang_thai, $id_nhatro, $id_phong);
    $result = mysqli_stmt_execute($stmt);

    if ($result) {
        return ['success' => true, 'message' => 'Cập nhật phòng trọ thành công!'];
    } else {
        return ['success' => false, 'message' => 'Lỗi khi cập nhật phòng trọ: ' . mysqli_stmt_error($stmt)];
    }
}

function deletePhongTro($id_phong) {
    global $conn;
    $id_phong = mysqli_real_escape_string($conn, $id_phong);
    $query = "DELETE FROM phong_tro WHERE ID_phong = ?";
    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_bind_param($stmt, "s", $id_phong);
    return mysqli_stmt_execute($stmt);
}

function getPhongTrongCount() {
    global $conn;
    $result = mysqli_query($conn, "SELECT COUNT(*) as total FROM phong_tro WHERE Trang_thai = 'Trống'");
    $row = mysqli_fetch_assoc($result);
    return $row['total'] ?? 0;
}

function getPhongThueCount() {
    global $conn;
    $result = mysqli_query($conn, "SELECT COUNT(*) as total FROM phong_tro WHERE Trang_thai = 'Đã thuê'");
    $row = mysqli_fetch_assoc($result);
    return $row['total'] ?? 0;
}
?>