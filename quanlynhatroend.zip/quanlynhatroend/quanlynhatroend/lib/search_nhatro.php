<?php
include 'connect.php';
include 'nhatroFunction.php';

$search = isset($_GET['search']) ? $_GET['search'] : '';
$result = getNhaTro($search, 1, 10); // lấy tối đa 10 kết quả
$data = $result['nhatro'] ?? [];

header('Content-Type: application/json');
echo json_encode($data);

?>