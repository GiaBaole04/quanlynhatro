<?php
// Kiểm tra xem file đã được include chưa
if (!defined('COMMON_FUNCTIONS_INCLUDED')) {
    define('COMMON_FUNCTIONS_INCLUDED', true);

    if (!isset($conn)) {
        include 'connect.php';
    }

    // Hàm tính số tháng của hợp đồng
    function getSoThangHopDong($ngay_bat_dau, $ngay_ket_thuc) {
        $start = new DateTime($ngay_bat_dau);
        $end = new DateTime($ngay_ket_thuc);
        $interval = $start->diff($end);
        return $interval->m + ($interval->y * 12) + ($interval->d > 0 ? 1 : 0); // Cộng thêm 1 nếu có ngày lẻ
    }
}
?>