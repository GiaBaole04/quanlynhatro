<?php
// filepath: d:\XAMPP\htdocs\quanlynhatroend\lib\search_hopdong.php
include 'connect.php';
include 'hopdongFunction.php';

$search = isset($_GET['search']) ? $_GET['search'] : '';
$result = getHopDongList($search, 1, 6); // lấy tối đa 6 hợp đồng
$data = $result['hopdong'] ?? [];

header('Content-Type: application/json');
echo json_encode($data);
?>