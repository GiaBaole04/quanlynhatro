<?php
include 'connect.php';



function getNextAvailableId($table, $id_column) {
    global $conn;
    $result = mysqli_query($conn, "SELECT $id_column FROM $table ORDER BY $id_column");
    $used_ids = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $used_ids[] = $row[$id_column];
    }

    $next_id = 1;
    $prefix = 'NT';
    while (true) {
        $formatted_id = $prefix . str_pad($next_id, 2, '0', STR_PAD_LEFT);
        if (!in_array($formatted_id, $used_ids)) {
            return $formatted_id;
        }
        $next_id++;
    }
}

// Lấy danh sách nhà trọ (hỗ trợ tìm kiếm và phân trang)
function getNhaTro($search = '', $page = 1, $limit = 5) {
    global $conn;
    $offset = ($page - 1) * $limit;
    $search = mysqli_real_escape_string($conn, $search);

    $where = '';
    if (!empty($search)) {
        $where = "WHERE n.Ten_nhatro LIKE '%$search%' OR n.Dia_chi LIKE '%$search%'";
    }

    // Sắp xếp trạng thái: Chờ duyệt lên đầu
    $sql = "SELECT n.*, x.Ten_xa, u.Tai_khoan AS Ten_user 
            FROM nhatro n
            LEFT JOIN xa_phuong x ON n.ID_xa = x.ID_xa
            LEFT JOIN nguoidung u ON n.ID_user = u.ID_user
            $where
            ORDER BY FIELD(n.Trang_thai, 'Chờ duyệt', 'Đã duyệt', 'Từ chối'), n.ID_nhatro ASC
            LIMIT $limit OFFSET $offset";
    $result = mysqli_query($conn, $sql);

    $nhatro = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $nhatro[] = $row;
    }

    // Đếm tổng số trang
    $count_sql = "SELECT COUNT(*) as total FROM nhatro n $where";
    $count_result = mysqli_query($conn, $count_sql);
    $total = mysqli_fetch_assoc($count_result)['total'];
    $total_pages = ceil($total / $limit);

    return [
        'nhatro' => $nhatro,
        'total_pages' => $total_pages
    ];
}

function addNhaTro($ten_nhatro, $dia_chi, $id_xa, $kinh_do = 0.000000, $vi_do = 0.000000, $trang_thai = 'Đã duyệt', $id_user = null) {
    global $conn;
    $ten_nhatro = mysqli_real_escape_string($conn, $ten_nhatro);
    $dia_chi = mysqli_real_escape_string($conn, $dia_chi);
    $id_xa = mysqli_real_escape_string($conn, $id_xa);
    $kinh_do = floatval($kinh_do);
    $vi_do = floatval($vi_do);

    // Gán ID_nhatro
    $id_nhatro = getNextAvailableId('nhatro', 'ID_nhatro');

    // Chuẩn bị truy vấn, thêm cả ID_user nếu cần
    $query = "INSERT INTO nhatro (ID_nhatro, Ten_nhatro, Dia_chi, Kinh_do, Vi_do, ID_xa, Trang_thai, ID_user) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
    $stmt = mysqli_prepare($conn, $query);
    if (!$stmt) {
        return ['success' => false, 'message' => 'Lỗi chuẩn bị truy vấn: ' . mysqli_error($conn)];
    }
    mysqli_stmt_bind_param($stmt, "sssddsss", $id_nhatro, $ten_nhatro, $dia_chi, $kinh_do, $vi_do, $id_xa, $trang_thai, $id_user);
    $result = mysqli_stmt_execute($stmt);
    if (!$result) {
        return ['success' => false, 'message' => 'Lỗi khi thêm nhà trọ: ' . mysqli_stmt_error($stmt)];
    }
    return ['success' => true, 'message' => 'Thêm nhà trọ thành công!'];
}

function updateNhaTro($id_nhatro, $ten_nhatro, $dia_chi, $id_xa, $kinh_do = 0.000000, $vi_do = 0.000000) {
    global $conn;

    // Mã hóa dữ liệu đầu vào
    $id_nhatro = mysqli_real_escape_string($conn, $id_nhatro);
    $ten_nhatro = mysqli_real_escape_string($conn, $ten_nhatro);
    $dia_chi = mysqli_real_escape_string($conn, $dia_chi);
    $id_xa = mysqli_real_escape_string($conn, $id_xa);
    $kinh_do = floatval($kinh_do);
    $vi_do = floatval($vi_do);

    // Debug giá trị đầu vào
    error_log("DEBUG: Đầu vào updateNhaTro - ID_nhatro: $id_nhatro, Ten_nhatro: $ten_nhatro, Dia_chi: $dia_chi, ID_xa: $id_xa, Kinh_do: $kinh_do, Vi_do: $vi_do");

    // Kiểm tra ID_xa hợp lệ
    if (empty($id_xa) || !preg_match('/^X\d{2}$/', $id_xa)) {
        return ['success' => false, 'message' => 'ID_xa không hợp lệ! Giá trị: ' . $id_xa];
    }

    // Bắt đầu giao dịch
    mysqli_begin_transaction($conn);

    try {
        // Kiểm tra ID_nhatro có tồn tại không
        $check_nhatro_sql = "SELECT COUNT(*) FROM nhatro WHERE ID_nhatro = ? FOR UPDATE";
        $stmt = mysqli_prepare($conn, $check_nhatro_sql);
        if (!$stmt) {
            throw new Exception('Lỗi chuẩn bị truy vấn kiểm tra ID_nhatro: ' . mysqli_error($conn));
        }
        mysqli_stmt_bind_param($stmt, "s", $id_nhatro);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);
        $nhatro_count = mysqli_fetch_row($result)[0];
        mysqli_stmt_close($stmt);

        if ($nhatro_count == 0) {
            throw new Exception('Nhà trọ không tồn tại! ID_nhatro = ' . $id_nhatro);
        }

        // Kiểm tra ID_xa trong xa_phuong
        $check_xa_sql = "SELECT COUNT(*) FROM xa_phuong WHERE ID_xa = ? FOR UPDATE";
        $stmt = mysqli_prepare($conn, $check_xa_sql);
        if (!$stmt) {
            throw new Exception('Lỗi chuẩn bị truy vấn kiểm tra ID_xa: ' . mysqli_error($conn));
        }
        mysqli_stmt_bind_param($stmt, "s", $id_xa);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);
        $xa_count = mysqli_fetch_row($result)[0];
        mysqli_stmt_close($stmt);

        if ($xa_count == 0) {
            $all_xa = mysqli_query($conn, "SELECT ID_xa FROM xa_phuong");
            $xa_list = [];
            while ($row = mysqli_fetch_assoc($all_xa)) {
                $xa_list[] = $row['ID_xa'];
            }
            error_log("DEBUG: Danh sách ID_xa trong xa_phuong = " . implode(", ", $xa_list));
            throw new Exception('Xã/Phường không tồn tại! ID_xa = ' . $id_xa . ' (Danh sách: ' . implode(', ', $xa_list) . ')');
        }

        // Truy vấn UPDATE
        $query = "UPDATE nhatro SET Ten_nhatro = ?, Dia_chi = ?, ID_xa = ?, Kinh_do = ?, Vi_do = ? WHERE ID_nhatro = ?";
        $stmt = mysqli_prepare($conn, $query);
        if (!$stmt) {
            throw new Exception('Lỗi chuẩn bị truy vấn UPDATE: ' . mysqli_error($conn));
        }
        mysqli_stmt_bind_param($stmt, "sssdds", $ten_nhatro, $dia_chi, $id_xa, $kinh_do, $vi_do, $id_nhatro);
        $result = mysqli_stmt_execute($stmt);
        if (!$result) {
            throw new Exception('Lỗi khi cập nhật nhà trọ: ' . mysqli_stmt_error($stmt));
        }

        // Kiểm tra số hàng bị ảnh hưởng
        $affected_rows = mysqli_stmt_affected_rows($stmt);
        mysqli_stmt_close($stmt);

        if ($affected_rows !== 1) {
            throw new Exception('Cập nhật không thành công! Số hàng bị ảnh hưởng: ' . $affected_rows);
        }

        // Commit giao dịch
        mysqli_commit($conn);
        return ['success' => true, 'message' => 'Cập nhật nhà trọ thành công!'];
    } catch (Exception $e) {
        // Rollback giao dịch nếu có lỗi
        mysqli_rollback($conn);
        return ['success' => false, 'message' => $e->getMessage()];
    }
}

function deleteNhaTro($id_nhatro) {
    global $conn;
    $id_nhatro = mysqli_real_escape_string($conn, $id_nhatro);

    // Bắt đầu giao dịch
    mysqli_begin_transaction($conn);

    try {
        // Kiểm tra xem nhà trọ có phòng trọ liên quan không
        $check_phong_sql = "SELECT COUNT(*) FROM phong_tro WHERE ID_nhatro = ?";
        $stmt = mysqli_prepare($conn, $check_phong_sql);
        mysqli_stmt_bind_param($stmt, "s", $id_nhatro);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);
        $phong_count = mysqli_fetch_row($result)[0];
        mysqli_stmt_close($stmt);

        if ($phong_count > 0) {
            throw new Exception('Không thể xóa nhà trọ vì đã có phòng trọ liên quan!');
        }

        // Xóa nhà trọ
        $sql = "DELETE FROM nhatro WHERE ID_nhatro = ?";
        $stmt = mysqli_prepare($conn, $sql);
        if (!$stmt) {
            throw new Exception('Lỗi chuẩn bị truy vấn DELETE: ' . mysqli_error($conn));
        }
        mysqli_stmt_bind_param($stmt, "s", $id_nhatro);
        $result = mysqli_stmt_execute($stmt);
        if (!$result) {
            throw new Exception('Lỗi khi xóa nhà trọ: ' . mysqli_stmt_error($stmt));
        }

        // Commit giao dịch
        mysqli_commit($conn);
        return true;
    } catch (Exception $e) {
        // Rollback giao dịch nếu có lỗi
        mysqli_rollback($conn);
        error_log("Lỗi khi xóa nhà trọ: " . $e->getMessage());
        return false;
    }
}
?>