<?php
$required_role = 'chunha'; // hoặc 'admin', 'nguoithue'
include('lib/auth.php');
include('lib/connect.php');
include('lib/nhatrocuatoiFunction.php');



$page = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
$limit = 5;
$offset = ($page - 1) * $limit;
$total = getNhaTroCountByChuNha($conn, $_SESSION['user_id']);
$nhatroList = getNhaTroByChuNha($conn, $_SESSION['user_id'], $limit, $offset);
$totalPages = ceil($total / $limit);

// Xử lý thêm nhà trọ
if (isset($_POST['add_nhatro'])) {
    $ten_nhatro = trim($_POST['ten_nhatro']);
    $dia_chi = trim($_POST['diachi']);
    $id_xa = trim($_POST['id_xa']);
    $kinh_do = isset($_POST['kinh_do']) && $_POST['kinh_do'] !== '' ? floatval($_POST['kinh_do']) : 0.000000;
    $vi_do = isset($_POST['vi_do']) && $_POST['vi_do'] !== '' ? floatval($_POST['vi_do']) : 0.000000;

    if (!empty($ten_nhatro) && !empty($dia_chi) && !empty($id_xa)) {
        $result = addNhaTroByChuNha($conn, $_SESSION['user_id'], $ten_nhatro, $dia_chi, $id_xa, $kinh_do, $vi_do);
        if ($result === true) {
            header("Location: nhatrocuatoi.php?msg=" . urlencode("Thêm nhà trọ thành công! Vui lòng chờ admin duyệt."));
            exit();
        } else {
            $msg = "Lỗi khi thêm nhà trọ: " . $result;
        }
    } else {
        $msg = "Vui lòng điền đầy đủ thông tin bắt buộc.";
    }
}

// Xử lý sửa nhà trọ
if (isset($_POST['update_nhatro'])) {
    $id_nhatro = isset($_POST['id_nhatro']) ? trim($_POST['id_nhatro']) : '';
    $ten_nhatro = trim($_POST['ten_nhatro']);
    $dia_chi = trim($_POST['diachi']);
    $id_xa = trim($_POST['id_xa']);
    $kinh_do = isset($_POST['kinh_do']) && $_POST['kinh_do'] !== '' ? floatval($_POST['kinh_do']) : 0.000000;
    $vi_do = isset($_POST['vi_do']) && $_POST['vi_do'] !== '' ? floatval($_POST['vi_do']) : 0.000000;

    if (!empty($id_nhatro) && !empty($ten_nhatro) && !empty($dia_chi) && !empty($id_xa)) {
        if (updateNhaTroByChuNha($conn, $id_nhatro, $_SESSION['user_id'], $ten_nhatro, $dia_chi, $id_xa)) {
            header("Location: nhatrocuatoi.php?msg=" . urlencode("Cập nhật nhà trọ thành công. Vui lòng chờ admin duyệt."));
            
            exit();
            
        } else {
            $msg = "Lỗi khi cập nhật nhà trọ: " . mysqli_error($conn);
        }
    } else {
        $msg = "Vui lòng điền đầy đủ thông tin bắt buộc.";
    }
}


// Xử lý xóa nhà trọ
if (isset($_POST['delete_nhatro'])) {
    $id_nhatro = isset($_POST['id_nhatro']) ? trim($_POST['id_nhatro']) : '';
    if (deleteNhaTroByChuNha($conn, $id_nhatro, $_SESSION['user_id'])) {
        header("Location: nhatrocuatoi.php?msg=" . urlencode("Xóa nhà trọ thành công!"));
        exit();
    } else {
        $msg = "Lỗi khi xóa nhà trọ: " . mysqli_error($conn);
    }
}


// Lấy dữ liệu sửa nếu có
$edit_nhatro = null;
if (isset($_POST['edit_nhatro'])) {
    $id_nhatro = isset($_POST['id_nhatro']) ? trim($_POST['id_nhatro']) : '';
    $edit_nhatro = getNhaTroById($conn, $id_nhatro, $_SESSION['user_id']);
}
?>


<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Nhà trọ của tôi</title>
    <link rel="stylesheet" href="css/style.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>
    <?php include('lib/menuchunha.php'); ?>
    <div class="container mt-4">
    <h2>Nhà trọ của tôi</h2>
    <?php if (isset($_GET['msg'])): ?>
        <div class="alert alert-info"><?php echo htmlspecialchars($_GET['msg']); ?></div>
    <?php endif; ?>

        

        <div class="row">
            <div class="col-md-4">
                <div class="stat-card">
                    <h3><?php echo $edit_nhatro ? 'Sửa Nhà Trọ' : 'Thêm Nhà Trọ'; ?></h3>
                    <form method="POST">
                        <?php if ($edit_nhatro) { ?>
                            <input type="hidden" name="id_nhatro" value="<?php echo htmlspecialchars($edit_nhatro['ID_nhatro']); ?>">
                        <?php } ?>
                        <div class="mb-3">
                            <label for="ten_nhatro" class="form-label">Tên nhà trọ <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" id="ten_nhatro" name="ten_nhatro" value="<?php echo $edit_nhatro ? htmlspecialchars($edit_nhatro['Ten_nhatro']) : ''; ?>" required>
                        </div>
                        <div class="mb-3">
                            <label for="diachi" class="form-label">Địa chỉ <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" id="diachi" name="diachi" value="<?php echo $edit_nhatro ? htmlspecialchars($edit_nhatro['Dia_chi']) : ''; ?>" required>
                        </div>
                        <div class="mb-3">
                            <label for="id_xa" class="form-label">Xã/Phường <span class="text-danger">*</span></label>
                            <select class="form-select" id="id_xa" name="id_xa" required>
                                <option value="">Chọn xã/phường</option>
                                <?php
                                $result = mysqli_query($conn, "SELECT ID_xa, Ten_xa FROM xa_phuong");
                                if ($result && mysqli_num_rows($result) > 0) {
                                    while ($row = mysqli_fetch_assoc($result)) {
                                        $selected = ($edit_nhatro && $edit_nhatro['ID_xa'] == $row['ID_xa']) ? 'selected' : '';
                                        echo "<option value='{$row['ID_xa']}' $selected>" . htmlspecialchars($row['Ten_xa']) . "</option>";
                                    }
                                } else {
                                    echo "<option value='' disabled>Không có dữ liệu xã/phường</option>";
                                }
                                ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="kinh_do" class="form-label">Kinh độ</label>
                            <input type="number" step="0.000001" class="form-control" id="kinh_do" name="kinh_do" value="<?php echo $edit_nhatro ? htmlspecialchars($edit_nhatro['Kinh_do']) : ''; ?>" placeholder="Ví dụ: 106.660172">
                        </div>
                        <div class="mb-3">
                            <label for="vi_do" class="form-label">Vĩ độ</label>
                            <input type="number" step="0.000001" class="form-control" id="vi_do" name="vi_do" value="<?php echo $edit_nhatro ? htmlspecialchars($edit_nhatro['Vi_do']) : ''; ?>" placeholder="Ví dụ: 10.762622">
                        </div>
                        <button type="submit" name="<?php echo $edit_nhatro ? 'update_nhatro' : 'add_nhatro'; ?>" class="btn btn-primary w-100">
                            <i class="fas fa-save"></i> <?php echo $edit_nhatro ? 'Cập nhật' : 'Thêm mới'; ?>
                        </button>
                    </form>
                </div>
            </div>
            <div class="col-md-8">
                
                <div class="contracts-table">
                    <h3 class="section-title">Danh Sách Nhà Trọ</h3>
                    <!-- Thanh tìm kiếm nằm trên cùng -->
                    <form method="POST" class="mb-3">
                        <div class="input-group">
                            <input type="text" class="form-control" id="searchInput" name="search" placeholder="Tìm kiếm theo tên hoặc địa chỉ..." value="<?php echo htmlspecialchars($search ?? ''); ?>">
                            <button type="submit" class="btn btn-primary"><i class="fas fa-search"></i> Tìm kiếm</button>
                        </div>
                    </form>
                    <div class="table-responsive">
                        <table class="table table-bordered table-hover">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Tên nhà trọ</th>
                                    <th>Địa chỉ</th>
                                    <th>Xã/Phường</th>
                                    <th>Kinh độ</th>
                                    <th>Vĩ độ</th>
                                    <th>Trạng thái</th>
                                    <th>Hành động</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                if (is_array($nhatroList) && !empty($nhatroList)) {
                                    foreach ($nhatroList as $nhatro) {
                                        // Lấy tên xã/phường
                                        $ten_xa = 'Không xác định';
                                        if (!empty($nhatro['ID_xa'])) {
                                            $xa_query = mysqli_query($conn, "SELECT Ten_xa FROM xa_phuong WHERE ID_xa = '" . mysqli_real_escape_string($conn, $nhatro['ID_xa']) . "' LIMIT 1");
                                            if ($xa_query && $xa_row = mysqli_fetch_assoc($xa_query)) {
                                                $ten_xa = htmlspecialchars($xa_row['Ten_xa']);
                                            }
                                        }
                                        
                                        echo "<tr>
                                                <td>" . htmlspecialchars($nhatro['ID_nhatro']) . "</td>
                                                <td>" . htmlspecialchars($nhatro['Ten_nhatro']) . "</td>
                                                <td>" . htmlspecialchars($nhatro['Dia_chi']) . "</td>
                                                <td>$ten_xa</td>
                                                <td>" . ($nhatro['Kinh_do'] ? htmlspecialchars($nhatro['Kinh_do']) : 'Chưa có') . "</td>
                                                <td>" . ($nhatro['Vi_do'] ? htmlspecialchars($nhatro['Vi_do']) : 'Chưa có') . "</td>
                                                <td>" . htmlspecialchars($nhatro['Trang_thai']) . "</td>
                                                <td>
                                                    <form method='POST' style='display:inline;'>
                                                        <input type='hidden' name='id_nhatro' value='" . htmlspecialchars($nhatro['ID_nhatro']) . "'>
                                                        <button type='submit' name='edit_nhatro' class='btn btn-warning btn-sm'><i class='fas fa-edit'></i> Sửa</button>
                                                    </form>
                                                    <form method='POST' style='display:inline;'>
                                                        <input type='hidden' name='id_nhatro' value='" . htmlspecialchars($nhatro['ID_nhatro']) . "'>
                                                        <button type='submit' name='delete_nhatro' class='btn btn-danger btn-sm' onclick='return confirm(\"Bạn có chắc muốn xóa nhà trọ này?\");'><i class='fas fa-trash'></i> Xóa</button>
                                                    </form>
                                                </td>
                                            </tr>";
                                    }
                                } else {
                                    echo "<tr><td colspan='8' class='text-center text-muted'>Không tìm thấy nhà trọ nào.</td></tr>";
                                }
                                ?>
                            </tbody>
                        </table>
                    </div>
                    <!-- Phân trang -->
                    <nav>
                        <ul class="pagination justify-content-center">
                            <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                                <li class="page-item <?php if ($i == $page) echo 'active'; ?>">
                                    <a class="page-link" href="?page=<?php echo $i; ?>"><?php echo $i; ?></a>
                                </li>
                            <?php endfor; ?>
                        </ul>
                    </nav>
                </div>
            </div>
        </div>
        <footer class="footer mt-4">
            <p>&copy; <?php echo date('Y'); ?> Chủ Nhà - Quản lý nhà trọ</p>
        </footer>
    </div>
    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDAtlr7R1MHyvBt_jkA99G6trncz6H8s&callback=initMap" async defer></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
    document.getElementById('searchInput').addEventListener('keyup', function() {
        let keyword = this.value.toLowerCase();
        let rows = document.querySelectorAll('table tbody tr');
        rows.forEach(row => {
            let text = row.innerText.toLowerCase();
            row.style.display = text.includes(keyword) ? '' : 'none';
        });
    });
    </script>
</body>
</html>