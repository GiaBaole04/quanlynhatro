
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Đăng Nhập - Quản Lý Nhà Trọ</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-4">
                <div class="card">
                    <div class="card-header text-center">
                        <h3><i class="fas fa-sign-in-alt"></i> Đăng Nhập</h3>
                    </div>
                    <div class="card-body">
                        <?php
                        include 'lib/connect.php';

                        if (isset($_POST['login'])) {
                            $username = $_POST['username'];
                            $password = $_POST['password'];

                            if (!empty($username) && !empty($password)) {
                                $username = mysqli_real_escape_string($conn, $username);
                                $query = "SELECT * FROM nguoidung WHERE Tai_khoan = ? LIMIT 1";
                                $stmt = mysqli_prepare($conn, $query);

                                if ($stmt === false) {
                                    echo "<div class='alert alert-danger'>Lỗi chuẩn bị truy vấn: " . mysqli_error($conn) . "</div>";
                                } else {
                                    mysqli_stmt_bind_param($stmt, "s", $username);
                                    mysqli_stmt_execute($stmt);
                                    $result = mysqli_stmt_get_result($stmt);
                                    $user = mysqli_fetch_assoc($result);

                                    if ($user && password_verify($password, $user['Mat_khau'])) {
                                        session_start();
                                        $_SESSION['user_id'] = $user['ID_user'];
                                        $_SESSION['username'] = $user['Tai_khoan'];
                                        
                                        
                                    if ($user['ID_vaitro'] == 3) { // Chủ nhà
                                        $_SESSION['role'] = 'chunha';
                                        header("Location: indexchunha.php");
                                        exit();
                                    } elseif ($user['ID_vaitro'] == 2) { // Người thuê
                                        $_SESSION['role'] = 'nguoithue';
                                        header("Location: indexnguoithue.php");
                                        exit();
                                    } else { // Admin
                                        $_SESSION['role'] = 'admin';
                                        header("Location: index.php");
                                        exit();
                                    }
                                        exit();
                                    } else {
                                        echo "<div class='alert alert-danger'>Tên đăng nhập hoặc mật khẩu không đúng!</div>";
                                    }
                                }
                            } else {
                                echo "<div class='alert alert-danger'>Vui lòng điền đầy đủ thông tin!</div>";
                            }
                        }
                        ?>
                        <form method="POST">
                            <div class="mb-3">
                                <label for="username" class="form-label">Tên đăng nhập</label>
                                <div class="input-group">
                                    <span class="input-group-text"><i class="fas fa-user"></i></span>
                                    <input type="text" class="form-control" id="username" name="username" required>
                                </div>
                            </div>
                            <div class="mb-3">
                                <label for="password" class="form-label">Mật khẩu</label>
                                <div class="input-group">
                                    <span class="input-group-text"><i class="fas fa-lock"></i></span>
                                    <input type="password" class="form-control" id="password" name="password" required>
                                </div>
                            </div>
                            <button type="submit" name="login" class="btn btn-primary w-100">
                                <i class="fas fa-sign-in-alt"></i> Đăng Nhập
                            </button>
                        </form>
                        <div class="text-center mt-3">
                            <p>Chưa có tài khoản? <a href="register.php">Đăng ký</a></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>