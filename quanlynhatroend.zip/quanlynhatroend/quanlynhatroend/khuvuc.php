<?php
$required_role = 'admin'; // hoặc 'admin', 'nguoithue'
include('lib/auth.php');
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quản Lý Khu Vực</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="./css/style.css">
    <style>
        #searchResults {
            position: absolute;
            top: 100%;
            left: 0;
            width: 100%;
            background-color: white;
            border: 1px solid #ccc;
            display: none;
            z-index: 1000;
        }
        #searchResults ul {
            list-style: none;
            padding: 0;
            margin: 0;
        }
        #searchResults li {
            padding: 8px;
            border-bottom: 1px solid #eee;
            cursor: pointer;
        }
        #searchResults li:hover {
            background-color: #f0f0f0;
        }
    </style>
</head>
<body>
    <?php include('lib/menuapp.php'); ?>

    <div class="main-content">
        <h1 class="dashboard-title">Quản Lý Khu Vực</h1>

        <?php
        include 'lib/connect.php';
        include 'lib/khuvucFunction.php';

        // Xử lý thêm khu vực
        if (isset($_POST['add_area'])) {
            $ten_khuvuc = $_POST['ten_khuvuc'];
            if (!empty($ten_khuvuc)) {
                $result = addArea($ten_khuvuc);
                if ($result['success']) {
                    header("Location: khuvuc.php?msg=" . urlencode($result['message']));
                    exit();
                } else {
                    echo "<p class='alert alert-danger'>" . htmlspecialchars($result['message']) . "</p>";
                }
            } else {
                echo "<p class='alert alert-danger'>Vui lòng nhập tên khu vực.</p>";
            }
        }
        // Xử lý sửa khu vực
        elseif (isset($_POST['update_area'])) {
            $id_khuvuc = $_POST['id_khuvuc'];
            $ten_khuvuc = $_POST['ten_khuvuc'];
            if (!empty($ten_khuvuc)) {
                if (updateArea($id_khuvuc, $ten_khuvuc)) {
                    header("Location: khuvuc.php?msg=Cập nhật khu vực thành công");
                    exit();
                } else {
                    echo "<p class='alert alert-danger'>Lỗi khi cập nhật khu vực: " . mysqli_error($conn) . "</p>";
                }
            } else {
                echo "<p class='alert alert-danger'>Vui lòng nhập tên khu vực.</p>";
            }
        }
        // Xử lý xóa khu vực
        elseif (isset($_POST['delete_area'])) {
            $id_khuvuc = $_POST['id_khuvuc'];
            if (deleteArea($id_khuvuc)) {
                header("Location: khuvuc.php?msg=Xóa khu vực thành công");
                exit();
            } else {
                echo "<p class='alert alert-danger'>Lỗi khi xóa khu vực (có thể đang được sử dụng).</p>";
            }
        }

        // Hiển thị thông báo nếu có
        if (isset($_GET['msg'])) {
            echo "<p class='alert alert-success'>" . htmlspecialchars($_GET['msg']) . "</p>";
        }

        // Lấy thông tin khu vực cần sửa
        $edit_area = null;
        if (isset($_POST['edit_area'])) {
            $id_khuvuc = $_POST['id_khuvuc'];
            if (!empty($id_khuvuc)) {
                $id_khuvuc = mysqli_real_escape_string($conn, $id_khuvuc);
                $result = mysqli_query($conn, "SELECT * FROM khuvuc WHERE ID_khuvuc = '$id_khuvuc'");
                if ($result && mysqli_num_rows($result) > 0) {
                    $edit_area = mysqli_fetch_assoc($result);
                } else {
                    echo "<p class='alert alert-danger'>Không tìm thấy khu vực với ID: " . htmlspecialchars($id_khuvuc) . "</p>";
                }
            }
        }

        // Lấy trang hiện tại từ tham số URL
        $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
        if ($page < 1) $page = 1;

        // Lấy dữ liệu tìm kiếm
        $search = isset($_POST['search']) ? $_POST['search'] : '';

        // Gọi hàm getAreas với phân trang
        $result = getAreas($search, $page, 5); // 5 khu vực mỗi trang
        $areas = $result['areas'];
        $total_pages = $result['total_pages'];
        ?>

        <div class="row">
            <div class="col-md-4">
                <h3 class="section-title"><?php echo isset($edit_area) ? 'Sửa Khu Vực' : 'Thêm Khu Vực'; ?></h3>
                <form method="POST">
                    <?php if (isset($edit_area)) { ?>
                        <input type="hidden" name="id_khuvuc" value="<?php echo htmlspecialchars($edit_area['ID_khuvuc']); ?>">
                    <?php } ?>
                    <div class="mb-3 input-group">
                        <input type="text" class="form-control" id="ten_khuvuc" name="ten_khuvuc" placeholder="Tên khu vực" value="<?php echo isset($edit_area) ? htmlspecialchars($edit_area['Ten_khuvuc']) : ''; ?>" required>
                    </div>
                    <button type="submit" name="<?php echo isset($edit_area) ? 'update_area' : 'add_area'; ?>" class="btn btn-primary w-100">
                        <?php echo isset($edit_area) ? 'Cập nhật' : 'Thêm mới'; ?>
                    </button>
                </form>
            </div>

            <div class="col-md-8">
                <h3 class="section-title">Danh sách khu vực</h3>
                <form method="POST" class="mb-3">
                    <div class="input-group" style="position:relative;">
                        <input type="text" class="form-control" id="search" name="search" placeholder="Tìm kiếm khu vực..." value="<?php echo htmlspecialchars($search); ?>">
                        <button type="submit" class="btn btn-primary">Tìm kiếm</button>
                    </div>
                </form>

                <table class="contracts-table table table-striped">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Tên khu vực</th>
                            <th>Hành động</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        if (empty($areas)) {
                            echo "<tr><td colspan='3'>Không tìm thấy khu vực nào.</td></tr>";
                        } else {
                            foreach ($areas as $area) {
                                echo "<tr>
                                        <td>{$area['ID_khuvuc']}</td>
                                        <td>{$area['Ten_khuvuc']}</td>
                                        <td>
                                            <form method='POST' style='display:inline;'>
                                                <input type='hidden' name='id_khuvuc' value='{$area['ID_khuvuc']}'>
                                                <button type='submit' name='edit_area' class='btn btn-warning btn-sm'>Sửa</button>
                                            </form>
                                            <form method='POST' style='display:inline;'>
                                                <input type='hidden' name='id_khuvuc' value='{$area['ID_khuvuc']}'>
                                                <button type='submit' name='delete_area' class='btn btn-danger btn-sm' onclick='return confirm(\"Bạn có chắc muốn xóa?\");'>Xóa</button>
                                            </form>
                                        </td>
                                      </tr>";
                            }
                        }
                        ?>
                    </tbody>
                </table>

                <?php if ($total_pages > 1): ?>
                    <nav aria-label="Page navigation" class="mt-4">
                        <ul class="pagination justify-content-center">
                            <li class="page-item <?php echo $page <= 1 ? 'disabled' : ''; ?>">
                                <a class="page-link" href="khuvuc.php?page=<?php echo $page - 1; ?><?php echo !empty($search) ? '&search=' . urlencode($search) : ''; ?>">Trước</a>
                            </li>

                            <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                                <li class="page-item <?php echo $i == $page ? 'active' : ''; ?>">
                                    <a class="page-link" href="khuvuc.php?page=<?php echo $i; ?><?php echo !empty($search) ? '&search=' . urlencode($search) : ''; ?>"><?php echo $i; ?></a>
                                </li>
                            <?php endfor; ?>

                            <li class="page-item <?php echo $page >= $total_pages ? 'disabled' : ''; ?>">
                                <a class="page-link" href="khuvuc.php?page=<?php echo $page + 1; ?><?php echo !empty($search) ? '&search=' . urlencode($search) : ''; ?>">Tiếp</a>
                            </li>
                        </ul>
                    </nav>
                <?php endif; ?>
            </div>
        </div>

        <footer class="footer">
            <p>Liên hệ: 0123 456 789 - Email: info@nhatro.com</p>
        </footer>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
const searchInput = document.getElementById('search');
const tableBody = document.querySelector('table.contracts-table tbody');

searchInput.addEventListener('keyup', function() {
    const searchText = this.value.trim();
    fetch('lib/search_khuvuc.php?search=' + encodeURIComponent(searchText))
        .then(response => response.json())
        .then(data => {
            let html = '';
            if (data.length > 0) {
                data.forEach(area => {
                    html += `<tr>
                        <td>${area.ID_khuvuc}</td>
                        <td>${area.Ten_khuvuc}</td>
                        <td>
                            <form method='POST' style='display:inline;'>
                                <input type='hidden' name='id_khuvuc' value='${area.ID_khuvuc}'>
                                <button type='submit' name='edit_area' class='btn btn-warning btn-sm'>Sửa</button>
                            </form>
                            <form method='POST' style='display:inline;'>
                                <input type='hidden' name='id_khuvuc' value='${area.ID_khuvuc}'>
                                <button type='submit' name='delete_area' class='btn btn-danger btn-sm' onclick='return confirm("Bạn có chắc muốn xóa?");'>Xóa</button>
                            </form>
                        </td>
                    </tr>`;
                });
            } else {
                html = "<tr><td colspan='3'>Không tìm thấy khu vực nào.</td></tr>";
            }
            tableBody.innerHTML = html;
        });
});
</script>
</body>
</html>