<?php
$required_role = 'admin'; // hoặc 'admin', 'nguoithue'
include('lib/auth.php');
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quản Lý Nhà Trọ</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <?php include('lib/menuapp.php'); ?>

    <div class="main-content">
        <h1 class="dashboard-title">Quản Lý Nhà Trọ</h1>

        <?php
        include 'lib/nhatroFunction.php';

        
        if (isset($_POST['approve_nhatro'])) {
            $id_nhatro = $_POST['id_nhatro'];
            $stmt = mysqli_prepare($conn, "UPDATE nhatro SET Trang_thai = 'Đã duyệt' WHERE ID_nhatro = ?");
            mysqli_stmt_bind_param($stmt, "s", $id_nhatro);
            mysqli_stmt_execute($stmt);
            header("Location: nhatro.php?msg=Nhà trọ đã được duyệt!");
            exit();
        }

        if (isset($_POST['add_nhatro'])) {
            $id_user = isset($_POST['id_user']) ? trim($_POST['id_user']) : '';
            $ten_nhatro = $_POST['ten_nhatro'];
            $dia_chi = $_POST['diachi'];
            $id_xa = isset($_POST['id_xa']) ? trim($_POST['id_xa']) : '';
            $kinh_do = isset($_POST['kinh_do']) && $_POST['kinh_do'] !== '' ? floatval($_POST['kinh_do']) : 0.000000;
            $vi_do = isset($_POST['vi_do']) && $_POST['vi_do'] !== '' ? floatval($_POST['vi_do']) : 0.000000;

            // Kiểm tra ID_xa có khớp với dữ liệu trong xa_phuong không
            global $conn;
            $check_xa_sql = "SELECT ID_xa FROM xa_phuong WHERE ID_xa = ?";
            $stmt = mysqli_prepare($conn, $check_xa_sql);
            mysqli_stmt_bind_param($stmt, "s", $id_xa);
            mysqli_stmt_execute($stmt);
            $result = mysqli_stmt_get_result($stmt);
            $row = mysqli_fetch_assoc($result);

            if ($row && $row['ID_xa'] === $id_xa) {
                // ID_xa hợp lệ, tiếp tục xử lý
            } else {
                echo "<div class='alert alert-danger'>ID_xa không tồn tại trong bảng xa_phuong: " . htmlspecialchars($id_xa) . "</div>";
                exit();
            }

            if (!empty($ten_nhatro) && !empty($dia_chi) && !empty($id_xa) && !empty($id_user)) {
                $result = addNhaTro($ten_nhatro, $dia_chi, $id_xa, $kinh_do, $vi_do, 'Đã duyệt', $id_user);
                if ($result['success']) {
                    header("Location: nhatro.php?msg=" . urlencode($result['message']));
                    exit();
                } else {
                    echo "<div class='alert alert-danger'>" . htmlspecialchars($result['message']) . "</div>";
                }
            } else {
                echo "<div class='alert alert-danger'>Vui lòng điền đầy đủ thông tin bắt buộc. ID_xa: " . htmlspecialchars($id_xa) . "</div>";
            }
        }

        elseif (isset($_POST['update_nhatro'])) {
            $id_nhatro = isset($_POST['id_nhatro']) ? trim($_POST['id_nhatro']) : '';
            $ten_nhatro = isset($_POST['ten_nhatro']) ? trim($_POST['ten_nhatro']) : '';
            $dia_chi = isset($_POST['diachi']) ? trim($_POST['diachi']) : '';
            $id_xa = isset($_POST['id_xa']) ? trim($_POST['id_xa']) : '';
            $kinh_do = isset($_POST['kinh_do']) && $_POST['kinh_do'] !== '' ? floatval($_POST['kinh_do']) : 0.000000;
            $vi_do = isset($_POST['vi_do']) && $_POST['vi_do'] !== '' ? floatval($_POST['vi_do']) : 0.000000;

            // Kiểm tra các trường bắt buộc
            if (empty($id_nhatro) || empty($ten_nhatro) || empty($dia_chi) || empty($id_xa)) {
                echo "<div class='alert alert-danger'>Vui lòng điền đầy đủ thông tin bắt buộc.</div>";
            } elseif (!preg_match('/^X\d{2}$/', $id_xa)) {
                echo "<div class='alert alert-danger'>ID_xa không hợp lệ! Phải có định dạng X## (ví dụ: X01).</div>";
            } else {
                // Kiểm tra xem ID_nhatro có tồn tại trong bảng nhatro không
                global $conn;
                $check_nhatro_sql = "SELECT ID_nhatro FROM nhatro WHERE ID_nhatro = ?";
                $stmt = mysqli_prepare($conn, $check_nhatro_sql);
                mysqli_stmt_bind_param($stmt, "s", $id_nhatro);
                mysqli_stmt_execute($stmt);
                $result = mysqli_stmt_get_result($stmt);
                $row = mysqli_fetch_assoc($result);

                if (!$row || $row['ID_nhatro'] !== $id_nhatro) {
                    echo "<div class='alert alert-danger'>Nhà trọ với ID: " . htmlspecialchars($id_nhatro) . " không tồn tại!</div>";
                } else {
                    // Kiểm tra ID_xa có tồn tại trong bảng xa_phuong không
                    $check_xa_sql = "SELECT ID_xa FROM xa_phuong WHERE ID_xa = ?";
                    $stmt = mysqli_prepare($conn, $check_xa_sql);
                    mysqli_stmt_bind_param($stmt, "s", $id_xa);
                    mysqli_stmt_execute($stmt);
                    $result = mysqli_stmt_get_result($stmt);
                    $row = mysqli_fetch_assoc($result);

                    if (!$row || $row['ID_xa'] !== $id_xa) {
                        echo "<div class='alert alert-danger'>ID_xa không tồn tại trong bảng xa_phuong: " . htmlspecialchars($id_xa) . "</div>";
                    } else {
                        // Gọi hàm updateNhaTro với các tham số đã kiểm tra
                        $result = updateNhaTro($id_nhatro, $ten_nhatro, $dia_chi, $id_xa, $kinh_do, $vi_do);
                        if ($result['success']) {
                            header("Location: nhatro.php?msg=" . urlencode($result['message']));
                            exit();
                        } else {
                            echo "<div class='alert alert-danger'>" . htmlspecialchars($result['message']) . "</div>";
                        }
                    }
                }
            }
        }
        elseif (isset($_POST['delete_nhatro'])) {
            $id_nhatro = $_POST['id_nhatro'];
            if (deleteNhaTro($id_nhatro)) {
                header("Location: nhatro.php?msg=Xóa nhà trọ thành công");
                exit();
            } else {
                echo "<div class='alert alert-danger'>Lỗi khi xóa nhà trọ: " . mysqli_error($conn) . "</div>";
            }
        }

        if (isset($_GET['msg'])) {
            echo "<div class='alert alert-success alert-dismissible fade show' role='alert'>
                    <strong>Thành công!</strong> " . htmlspecialchars($_GET['msg']) . "
                    <button type='button' class='btn-close' data-bs-dismiss='alert' aria-label='Close'></button>
                  </div>";
        }

        $edit_nhatro = null;
        if (isset($_POST['edit_nhatro'])) {
            $id_nhatro = mysqli_real_escape_string($conn, $_POST['id_nhatro']);
            $result = mysqli_query($conn, "SELECT * FROM nhatro WHERE ID_nhatro = '$id_nhatro'");
            if ($result && mysqli_num_rows($result) > 0) {
                $edit_nhatro = mysqli_fetch_assoc($result);
            } else {
                echo "<div class='alert alert-danger'>Nhà trọ với ID: " . htmlspecialchars($id_nhatro) . " không tồn tại!</div>";
            }
        }

        // Lấy trang hiện tại từ tham số URL
        $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
        if ($page < 1) $page = 1;

        // Lấy dữ liệu tìm kiếm
        $search = isset($_POST['search']) ? $_POST['search'] : '';

        // Gọi hàm getNhaTro với phân trang
        $result = getNhaTro($search, $page, 5); // 5 nhà trọ mỗi trang
        $nhatro_list = $result['nhatro'] ?? [];
        $total_pages = $result['total_pages'] ?? 1;
        ?>

        <div class="row">
            <div class="col-md-4">
                <div class="stat-card">
                    <h3><?php echo $edit_nhatro ? 'Sửa Nhà Trọ' : 'Thêm Nhà Trọ'; ?></h3>
                    <?php
                        // Lấy danh sách chủ nhà (vai trò ID_vaitro = 3)
                        $chunha_result = mysqli_query($conn, "SELECT ID_user, Tai_khoan FROM nguoidung WHERE ID_vaitro = 3");
                        $chunha_list = [];
                        if ($chunha_result && mysqli_num_rows($chunha_result) > 0) {
                            while ($row = mysqli_fetch_assoc($chunha_result)) {
                                $chunha_list[] = $row;
                            }
                        }
                    ?>
                    <form method="POST">
                        <?php if ($edit_nhatro) { ?>
                            <input type="hidden" name="id_nhatro" value="<?php echo htmlspecialchars($edit_nhatro['ID_nhatro']); ?>">
                        <?php } ?>
                        <div class="mb-3">
                            <label for="ten_nhatro" class="form-label">Tên nhà trọ <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" id="ten_nhatro" name="ten_nhatro" value="<?php echo $edit_nhatro ? htmlspecialchars($edit_nhatro['Ten_nhatro']) : ''; ?>" required>
                        </div>
                        <div class="mb-3">
                            <label for="diachi" class="form-label">Địa chỉ <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" id="diachi" name="diachi" value="<?php echo $edit_nhatro ? htmlspecialchars($edit_nhatro['Dia_chi']) : ''; ?>" required>
                        </div>
                        <div class="mb-3">
                            <label for="id_xa" class="form-label">Xã/Phường <span class="text-danger">*</span></label>
                            <select class="form-select" id="id_xa" name="id_xa" required>
                                <option value="">Chọn xã/phường</option>
                                <?php
                                $result = mysqli_query($conn, "SELECT ID_xa, Ten_xa FROM xa_phuong");
                                if ($result && mysqli_num_rows($result) > 0) {
                                    while ($row = mysqli_fetch_assoc($result)) {
                                        $selected = ($edit_nhatro && $edit_nhatro['ID_xa'] == $row['ID_xa']) ? 'selected' : '';
                                        echo "<option value='{$row['ID_xa']}' $selected>" . htmlspecialchars($row['Ten_xa']) . "</option>";
                                    }
                                } else {
                                    echo "<option value='' disabled>Không có dữ liệu xã/phường</option>";
                                }
                                ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="id_user" class="form-label">Chủ nhà <span class="text-danger">*</span></label>
                            <select class="form-select" id="id_user" name="id_user" required>
                                <option value="">Chọn chủ nhà</option>
                                <?php foreach ($chunha_list as $chunha): ?>
                                    <option value="<?php echo $chunha['ID_user']; ?>">
                                        <?php echo htmlspecialchars($chunha['Tai_khoan']); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="kinh_do" class="form-label">Kinh độ</label>
                            <input type="number" step="0.000001" class="form-control" id="kinh_do" name="kinh_do" value="<?php echo $edit_nhatro ? htmlspecialchars($edit_nhatro['Kinh_do']) : ''; ?>" placeholder="Ví dụ: 106.660172">
                        </div>
                        <div class="mb-3">
                            <label for="vi_do" class="form-label">Vĩ độ</label>
                            <input type="number" step="0.000001" class="form-control" id="vi_do" name="vi_do" value="<?php echo $edit_nhatro ? htmlspecialchars($edit_nhatro['Vi_do']) : ''; ?>" placeholder="Ví dụ: 10.762622">
                        </div>
                        <?php if ($edit_nhatro && !empty($edit_nhatro['Kinh_do']) && !empty($edit_nhatro['Vi_do'])) { ?>
                            <div class="mb-3">
                                <label class="form-label">Vị trí trên bản đồ</label>
                                <div class="map-container">
                                    <div id="map-<?php echo htmlspecialchars($edit_nhatro['ID_nhatro']); ?>" class="map-preview"></div>
                                </div>
                            </div>
                        <?php } ?>
                        <button type="submit" name="<?php echo $edit_nhatro ? 'update_nhatro' : 'add_nhatro'; ?>" class="btn btn-primary w-100">
                            <i class="fas fa-save"></i> <?php echo $edit_nhatro ? 'Cập nhật' : 'Thêm mới'; ?>
                        </button>
                    </form>
                </div>
            </div>

            <div class="col-md-8">
                <div class="contracts-table">
                    <h3 class="section-title">Danh Sách Nhà Trọ</h3>
                    <form method="POST" class="mb-3">
                        <div class="input-group">
                            <input type="text" class="form-control" id="search" name="search" placeholder="Tìm kiếm theo tên hoặc địa chỉ..." value="<?php echo htmlspecialchars($search); ?>">
                            <button type="submit" class="btn btn-primary"><i class="fas fa-search"></i> Tìm kiếm</button>
                        </div>
                    </form>

                    <div class="table-responsive">
                        <table class="table table-bordered table-hover">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Tên nhà trọ</th>
                                <th>Chủ nhà</th>
                                <th>Địa chỉ</th>
                                <th>Xã/Phường</th>
                                <th>Kinh độ</th>
                                <th>Vĩ độ</th>
                                <th>Trạng thái</th>
                                <th>Hành động</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php
                        if (is_array($nhatro_list) && !empty($nhatro_list)) {
                            foreach ($nhatro_list as $nhatro) {
                                $ten_xa = isset($nhatro['Ten_xa']) ? htmlspecialchars($nhatro['Ten_xa']) : 'Không xác định';
                                $ten_user = isset($nhatro['Ten_user']) ? htmlspecialchars($nhatro['Ten_user']) : 'Không xác định';
                                $trang_thai = htmlspecialchars($nhatro['Trang_thai']);
                                echo "<tr>
                                        <td>" . htmlspecialchars($nhatro['ID_nhatro']) . "</td>
                                        <td>" . htmlspecialchars($nhatro['Ten_nhatro']) . "</td>
                                        <td>$ten_user</td>
                                        <td>" . htmlspecialchars($nhatro['Dia_chi']) . "</td>
                                        <td>$ten_xa</td>
                                        <td>" . ($nhatro['Kinh_do'] ? htmlspecialchars($nhatro['Kinh_do']) : 'Chưa có') . "</td>
                                        <td>" . ($nhatro['Vi_do'] ? htmlspecialchars($nhatro['Vi_do']) : 'Chưa có') . "</td>
                                        <td>$trang_thai</td>
                                        <td>";
                                // Nếu trạng thái là Chờ duyệt, hiện nút duyệt
                                if ($nhatro['Trang_thai'] === 'Chờ duyệt') {
                                    echo "<form method='POST' style='display:inline;'>
                                            <input type='hidden' name='id_nhatro' value='{$nhatro['ID_nhatro']}'>
                                            <button type='submit' name='approve_nhatro' class='btn btn-success btn-sm'><i class='fas fa-check'></i> Duyệt</button>
                                        </form>";
                                }
                                echo "<form method='POST' style='display:inline;'>
                                        <input type='hidden' name='id_nhatro' value='{$nhatro['ID_nhatro']}'>
                                        <button type='submit' name='edit_nhatro' class='btn btn-warning btn-sm'><i class='fas fa-edit'></i> Sửa</button>
                                    </form>
                                    <form method='POST' style='display:inline;'>
                                        <input type='hidden' name='id_nhatro' value='{$nhatro['ID_nhatro']}'>
                                        <button type='submit' name='delete_nhatro' class='btn btn-danger btn-sm' onclick='return confirm(\"Bạn có chắc muốn xóa nhà trọ này?\");'><i class='fas fa-trash'></i> Xóa</button>
                                    </form>
                                    </td>
                                </tr>";
                            }
                        } else {
                            echo "<tr><td colspan='9' class='text-center text-muted'>Không tìm thấy nhà trọ nào.</td></tr>";
                        }
                        ?>
                        </tbody>
                        </table>
                    </div>

                    <!-- Phân trang -->
                    <?php if ($total_pages > 1): ?>
                        <nav aria-label="Page navigation" class="mt-4">
                            <ul class="pagination justify-content-center">
                                <!-- Nút Trước -->
                                <li class="page-item <?php echo $page <= 1 ? 'disabled' : ''; ?>">
                                    <a class="page-link" href="nhatro.php?page=<?php echo $page - 1; ?><?php echo !empty($search) ? '&search=' . urlencode($search) : ''; ?>">Trước</a>
                                </li>

                                <!-- Các trang -->
                                <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                                    <li class="page-item <?php echo $i == $page ? 'active' : ''; ?>">
                                        <a class="page-link" href="nhatro.php?page=<?php echo $i; ?><?php echo !empty($search) ? '&search=' . urlencode($search) : ''; ?>"><?php echo $i; ?></a>
                                    </li>
                                <?php endfor; ?>

                                <!-- Nút Tiếp theo -->
                                <li class="page-item <?php echo $page >= $total_pages ? 'disabled' : ''; ?>">
                                    <a class="page-link" href="nhatro.php?page=<?php echo $page + 1; ?><?php echo !empty($search) ? '&search=' . urlencode($search) : ''; ?>">Tiếp</a>
                                </li>
                            </ul>
                        </nav>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <footer class="footer">
            <p><i class="fas fa-phone"></i> Liên hệ: 0123 456 789 - <i class="fas fa-envelope"></i> Email: info@nhatro.com</p>
        </footer>
    </div>

    <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDAtlr7R1MHyvBt_jkA99G6trncz6H8s&callback=initMap" async defer></script>
    <script>
        function initMap() {
            <?php if ($edit_nhatro && !empty($edit_nhatro['Kinh_do']) && !empty($edit_nhatro['Vi_do'])) { ?>
                try {
                    var location = {lat: <?php echo $edit_nhatro['Vi_do']; ?>, lng: <?php echo $edit_nhatro['Kinh_do']; ?>};
                    var map = new google.maps.Map(document.getElementById('map-<?php echo htmlspecialchars($edit_nhatro['ID_nhatro']); ?>'), {
                        zoom: 15,
                        center: location
                    });
                    var marker = new google.maps.Marker({
                        position: location,
                        map: map,
                        title: "<?php echo htmlspecialchars($edit_nhatro['Ten_nhatro']); ?>"
                    });
                } catch (e) {
                    console.error("Lỗi khi tải bản đồ: ", e);
                    document.getElementById('map-<?php echo htmlspecialchars($edit_nhatro['ID_nhatro']); ?>').innerHTML = "<p class='text-danger'>Không thể tải bản đồ. Vui lòng kiểm tra API Key hoặc kết nối mạng.</p>";
                }
            <?php } ?>
        }
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
const searchInput = document.getElementById('search');
const tableBody = document.querySelector('table.table-bordered.table-hover tbody');

searchInput.addEventListener('keyup', function() {
    const searchText = this.value.trim();
    fetch('lib/search_nhatro.php?search=' + encodeURIComponent(searchText))
        .then(response => response.json())
        .then(data => {
            let html = '';
            if (data.length > 0) {
                data.forEach(nt => {
                    html += `<tr>
                        <td>${nt.ID_nhatro}</td>
                        <td>${nt.Ten_nhatro}</td>
                        <td>${nt.Dia_chi}</td>
                        <td>${nt.Ten_xa ?? ''}</td>
                        <td>${nt.Kinh_do ?? ''}</td>
                        <td>${nt.Vi_do ?? ''}</td>
                        <td>
                            <form method='POST' style='display:inline;'>
                                <input type='hidden' name='id_nhatro' value='${nt.ID_nhatro}'>
                                <button type='submit' name='edit_nhatro' class='btn btn-warning btn-sm'><i class='fas fa-edit'></i> Sửa</button>
                            </form>
                            <form method='POST' style='display:inline;'>
                                <input type='hidden' name='id_nhatro' value='${nt.ID_nhatro}'>
                                <button type='submit' name='delete_nhatro' class='btn btn-danger btn-sm' onclick='return confirm("Bạn có chắc muốn xóa nhà trọ này?");'><i class='fas fa-trash'></i> Xóa</button>
                            </form>
                        </td>
                    </tr>`;
                });
            } else {
                html = "<tr><td colspan='7' class='text-center text-muted'>Không tìm thấy nhà trọ nào.</td></tr>";
            }
            tableBody.innerHTML = html;
        });
});
</script>
</body>
</html>