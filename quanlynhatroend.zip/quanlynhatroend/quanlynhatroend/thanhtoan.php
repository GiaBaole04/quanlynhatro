<?php
$required_role = 'admin'; // hoặc 'admin', 'nguoithue'
include('lib/auth.php');
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quản Lý Thanh Toán</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <?php include('lib/menuapp.php'); ?>
    
    <div class="main-content">
        <h1 class="dashboard-title">Quản Lý Thanh Toán</h1>

        <?php
        include 'lib/connect.php';
        include 'lib/thanhtoanFunction.php';
        include 'lib/hopdongFunction.php'; // Để lấy danh sách hợp đồng
        
        // Xử lý thêm thanh toán
        if (isset($_POST['add_thanhtoan'])) {
            $id_hopdong = $_POST['id_hopdong'] ?? '';
            $ngay_thanh_toan = $_POST['ngay_thanh_toan'] ?? '';
            $so_tien = $_POST['so_tien'] ?? '';
            $phuong_thuc = $_POST['phuong_thuc'] ?? '';

            if ($id_hopdong !== '' && $ngay_thanh_toan !== '' && $so_tien !== '' && $phuong_thuc !== '') {
                // Lấy thông tin hợp đồng
                $hopdong = getHopDongById($id_hopdong);

                if (!$hopdong) {
                    echo "<div class='alert alert-danger'>Hợp đồng không tồn tại!</div>";
                } else {
                    $hopdong_list = getHopDongList();
                    $hopdong_info = null;
                    foreach ($hopdong_list as $hd) {
                        if ($hd['ID_hopdong'] == $id_hopdong) {
                            $hopdong_info = $hd;
                            break;
                        }
                    }
                    
                    if (!$hopdong_info) {
                        echo "<div class='alert alert-danger'>Không tìm thấy thông tin hợp đồng!</div>";
                    } else {
                        $hinh_thuc_thanh_toan = $hopdong['Hinh_thuc_thanh_toan'];
                        $gia_thue = $hopdong_info['Gia_thue'];
                        $so_thang = getSoThangHopDong($hopdong['Ngay_bat_dau'], $hopdong['Ngay_ket_thuc']);
                        $tong_tien_phai_tra = $gia_thue * $so_thang;

                        // Kiểm tra trùng lặp
                        if (checkDuplicateThanhToan($id_hopdong, $ngay_thanh_toan, $so_tien, $phuong_thuc)) {
                            echo "<div class='alert alert-danger'>Giao dịch này đã tồn tại! Vui lòng kiểm tra lại thông tin.</div>";
                        }
                        // Kiểm tra ngày thanh toán
                        elseif (!checkValidThanhToanDate($id_hopdong, $ngay_thanh_toan)) {
                            echo "<div class='alert alert-danger'>Ngày thanh toán không hợp lệ! Ngày thanh toán phải nằm trong khoảng thời gian hợp đồng (từ ngày bắt đầu đến ngày kết thúc).</div>";
                        }
                        // Kiểm tra hình thức thanh toán
                        elseif ($hinh_thuc_thanh_toan == 'Mot_lan') {
                            // Nếu là trả một lần, chỉ cho phép một giao dịch duy nhất
                            $existing_result = getThanhToanList($id_hopdong);
                            $existing_thanhtoan = $existing_result['thanhtoan'] ?? [];
                            if (!empty($existing_thanhtoan)) {
                                echo "<div class='alert alert-danger'>Hợp đồng này yêu cầu thanh toán một lần! Đã có giao dịch thanh toán, không thể thêm giao dịch mới.</div>";
                            } elseif ($so_tien != $tong_tien_phai_tra) {
                                echo "<div class='alert alert-danger'>Hợp đồng này yêu cầu thanh toán một lần! Số tiền phải bằng tổng số tiền phải trả: " . number_format($tong_tien_phai_tra, 0) . " VNĐ.</div>";
                            } elseif (addThanhToan($id_hopdong, $ngay_thanh_toan, $so_tien, $phuong_thuc)) {
                                header("Location: thanhtoan.php?msg=Thêm giao dịch thành công");
                                exit();
                            } else {
                                echo "<div class='alert alert-danger'>Lỗi khi thêm giao dịch: " . mysqli_error($conn) . "</div>";
                            }
                        } else {
                            // Nếu là trả hàng tháng, kiểm tra xem tháng đã được thanh toán chưa
                            if (checkThangDaThanhToan($id_hopdong, $ngay_thanh_toan)) {
                                echo "<div class='alert alert-danger'>Tháng này đã được thanh toán! Vui lòng chọn tháng khác.</div>";
                            } elseif ($so_tien != $gia_thue) {
                                echo "<div class='alert alert-danger'>Hợp đồng này yêu cầu thanh toán hàng tháng! Số tiền phải bằng giá thuê phòng: " . number_format($gia_thue, 0) . " VNĐ.</div>";
                            } elseif (addThanhToan($id_hopdong, $ngay_thanh_toan, $so_tien, $phuong_thuc)) {
                                header("Location: thanhtoan.php?msg=Thêm giao dịch thành công");
                                exit();
                            } else {
                                echo "<div class='alert alert-danger'>Lỗi khi thêm giao dịch: " . mysqli_error($conn) . "</div>";
                            }
                        }
                    }
                }
            } else {
                echo "<div class='alert alert-danger'>Vui lòng điền đầy đủ thông tin bắt buộc</div>";
            }
        }

        if (isset($_GET['msg'])) {
            echo "<div class='alert alert-success alert-dismissible fade show' role='alert'>
                    <strong>Thành công!</strong> " . htmlspecialchars($_GET['msg']) . "
                    <button type='button' class='btn-close' data-bs-dismiss='alert' aria-label='Close'></button>
                  </div>";
        }

        $id_hopdong_filter = isset($_GET['hopdong']) ? $_GET['hopdong'] : '';
        // Lấy trang hiện tại từ tham số URL
        $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
        if ($page < 1) $page = 1;

        // Lấy danh sách giao dịch thanh toán với phân trang
        $result = getThanhToanList($id_hopdong_filter, $page, 6); // 6 giao dịch mỗi trang (2 hàng x 3 cột)
        $thanhtoan_list = $result['thanhtoan'] ?? [];
        $total_pages = $result['total_pages'] ?? 1;

        // Kiểm tra và lọc $thanhtoan_list để đảm bảo chỉ chứa các mảng hợp lệ
        $filtered_thanhtoan_list = [];
        foreach ($thanhtoan_list as $item) {
            if (is_array($item) && isset($item['ID_hopdong'])) {
                $filtered_thanhtoan_list[] = $item;
            } else {
                error_log("Dữ liệu không hợp lệ trong thanhtoan_list: " . var_export($item, true));
            }
        }
        $thanhtoan_list = $filtered_thanhtoan_list;
        ?>

        <div class="row">
            <div class="col-md-4">
                <div class="stat-card">
                    <h3>Thêm Giao Dịch Thanh Toán</h3>
                    <form method="POST">
                        <div class="mb-3">
                            <label for="id_hopdong" class="form-label">Hợp đồng <span class="text-danger">*</span></label>
                            <select class="form-select" id="id_hopdong" name="id_hopdong" required onchange="updateHopDongDates()">
                                <option value="">Chọn hợp đồng</option>
                                <?php
                                $hopdong_list = getHopDongList();
                                if (is_array($hopdong_list)) {
                                    foreach ($hopdong_list['hopdong'] as $hopdong) {
                                        if (!is_array($hopdong) || !isset($hopdong['ID_hopdong'])) {
                                            continue; // Bỏ qua nếu $hopdong không phải là mảng hợp lệ
                                        }
                                        $selected = ($id_hopdong_filter == $hopdong['ID_hopdong']) ? 'selected' : '';
                                        $so_thang = getSoThangHopDong($hopdong['Ngay_bat_dau'], $hopdong['Ngay_ket_thuc']);
                                        $tong_tien = $hopdong['Gia_thue'] * $so_thang;
                                        echo "<option value='{$hopdong['ID_hopdong']}' $selected 
                                              data-ngaybatdau='{$hopdong['Ngay_bat_dau']}' 
                                              data-ngayketthuc='{$hopdong['Ngay_ket_thuc']}' 
                                              data-hinhthucthanhtoan='{$hopdong['Hinh_thuc_thanh_toan']}' 
                                              data-tongtien='$tong_tien' 
                                              data-giathue='{$hopdong['Gia_thue']}'>{$hopdong['Ho_ten']} - {$hopdong['Ten_phong']}</option>";
                                    }
                                } else {
                                    echo "<option value='' disabled>Không có hợp đồng nào</option>";
                                }
                                ?>
                            </select>
                        </div>
                        <!-- Hiển thị khoảng thời gian hợp đồng và thông tin thanh toán -->
                        <div class="mb-3" id="hopdong_dates" style="display: none;">
                            <p><strong>Ngày bắt đầu:</strong> <span id="ngay_bat_dau"></span></p>
                            <p><strong>Ngày kết thúc:</strong> <span id="ngay_ket_thuc"></span></p>
                            <p><strong>Hình thức thanh toán:</strong> <span id="hinh_thuc_thanh_toan"></span></p>
                            <p><strong>Giá thuê phòng:</strong> <span id="gia_thue"></span> VNĐ/tháng</p>
                            <p><strong>Số tháng:</strong> <span id="so_thang"></span></p>
                            <p><strong>Tổng tiền phải trả:</strong> <span id="tong_tien"></span> VNĐ</p>
                        </div>
                        <div class="mb-3">
                            <label for="ngay_thanh_toan" class="form-label">Ngày thanh toán <span class="text-danger">*</span></label>
                            <input type="date" class="form-control" id="ngay_thanh_toan" name="ngay_thanh_toan" required>
                        </div>
                        <div class="mb-3">
                            <label for="so_tien" class="form-label">Số tiền (VNĐ) <span class="text-danger">*</span></label>
                            <input type="number" class="form-control" id="so_tien" name="so_tien" step="0.01" required readonly>
                        </div>
                        <div class="mb-3">
                            <label for="phuong_thuc" class="form-label">Phương thức thanh toán <span class="text-danger">*</span></label>
                            <select class="form-select" id="phuong_thuc" name="phuong_thuc" required>
                                <option value="Tiền mặt">Tiền mặt</option>
                                <option value="Thẻ ngân hàng">Thẻ ngân hàng</option>
                                <option value="Chuyển khoản">Chuyển khoản</option>
                            </select>
                        </div>
                        <button type="submit" name="add_thanhtoan" class="btn btn-primary w-100">
                            <i class="fas fa-save"></i> Thêm mới
                        </button>
                    </form>
                </div>
            </div>

            <div class="col-md-8">
                <div class="contracts-table">
                    <h3 class="section-title">Danh Sách Giao Dịch Thanh Toán</h3>
                    <?php
                    $hopdong = null;
                    // Chỉ tìm kiếm hợp đồng nếu $id_hopdong_filter không rỗng
                    if (!empty($id_hopdong_filter)) {
                        $hopdong = getHopDongById($id_hopdong_filter);
                        
                    }

                    // Chỉ hiển thị thông tin hợp đồng nếu $hopdong tồn tại
                    if ($hopdong && !empty($id_hopdong_filter)) { // <--- Sửa điều kiện
                        $so_thang = getSoThangHopDong($hopdong['Ngay_bat_dau'], $hopdong['Ngay_ket_thuc']);
                        $tong_tien_phai_tra = $hopdong['Gia_thue'] * $so_thang; // <--- Sử dụng $hopdong['Gia_thue']
                        echo "<div class='col-12 mb-3'>
                        <p><strong>Hợp đồng:</strong> " . htmlspecialchars($hopdong['ID_hopdong']) . "</p>
                        <p><strong>Hình thức thanh toán:</strong> " . ($hopdong['Hinh_thuc_thanh_toan'] == 'Mot_lan' ? 'Trả một lần' : 'Trả hàng tháng') . "</p>
                        <p><strong>Giá thuê phòng:</strong> " . number_format($hopdong['Gia_thue'], 0) . " VNĐ/tháng</p>
                         <p><strong>Số tháng:</strong> $so_thang</p>
                         <p><strong>Tổng tiền phải trả:</strong> " . number_format($tong_tien_phai_tra, 0) . " VNĐ</p>
                         </div>";
                         } elseif (!empty($id_hopdong_filter)) {
                                                    // <--- Đoạn này sẽ chạy nếu getHopDongById trả về null
                          echo "<div class='col-12 mb-3'>
                          <div class='alert alert-warning'>Không tìm thấy hợp đồng với ID: " . htmlspecialchars($id_hopdong_filter) . "</div>
                          </div>";
                         }
                    ?>

                    <?php
                    if (is_array($thanhtoan_list) && !empty($thanhtoan_list)) {
                        $total_thanh_toan = 0;
                        // Tính tổng số tiền đã thanh toán
                        foreach ($thanhtoan_list as $thanhtoan) {
                            if (is_array($thanhtoan) && isset($thanhtoan['So_tien'])) {
                                $total_thanh_toan += (float)$thanhtoan['So_tien'];
                            }
                        }

                        $chunked_thanhtoan = array_chunk($thanhtoan_list, 3); // Chia danh sách thành các hàng, mỗi hàng 3 cột
                        $rows_to_display = array_slice($chunked_thanhtoan, 0, 2); // Chỉ lấy tối đa 2 hàng

                        foreach ($rows_to_display as $row) {
                            echo '<div class="row row-cols-1 row-cols-md-3 g-4 mb-4">';
                            foreach ($row as $thanhtoan) {
                                if (!is_array($thanhtoan) || !isset($thanhtoan['ID_hopdong'])) {
                                    error_log("Dữ liệu không hợp lệ trong row: " . var_export($thanhtoan, true));
                                    continue; // Bỏ qua nếu $thanhtoan không phải là mảng hợp lệ
                                }
                                ?>
                                <div class="col">
                                    <div class="card h-100 shadow-sm room-card">
                                        <div class="card-body">
                                            <h5 class="card-title"><?php echo htmlspecialchars($thanhtoan['Ho_ten'] ?? 'N/A'); ?></h5>
                                            <p class="card-text">
                                                <strong>Hợp đồng:</strong> <?php echo htmlspecialchars($thanhtoan['ID_hopdong'] ?? 'N/A'); ?><br>
                                                <strong>Phòng trọ:</strong> <?php echo htmlspecialchars($thanhtoan['Ten_phong'] ?? 'N/A'); ?><br>
                                                <strong>Ngày thanh toán:</strong> <?php echo htmlspecialchars($thanhtoan['Ngay_thanhtoan'] ?? 'N/A'); ?><br>
                                                <strong>Số tiền:</strong> <?php echo number_format($thanhtoan['So_tien'] ?? 0, 0); ?> VNĐ<br>
                                                <strong>Phương thức:</strong> <?php echo htmlspecialchars($thanhtoan['Phuong_thuc'] ?? 'N/A'); ?>
                                            </p>
                                        </div>
                                    </div>
                                </div>
                                <?php
                            }
                            echo '</div>';
                        }

                        // Hiển thị tổng số tiền đã thanh toán
                        if ($id_hopdong_filter) {
                            echo "<div class='col-12 mt-3'>
                                    <p><strong>Tổng số tiền đã thanh toán:</strong> " . number_format($total_thanh_toan, 0) . " VNĐ</p>
                                  </div>";
                        }
                    } else {
                        echo '<div class="col-12">
                                <div class="empty-state">
                                    <i class="fas fa-money-bill" style="font-size: 3rem;"></i>
                                    <h4 class="mt-3">Không tìm thấy giao dịch nào</h4>
                                    <p>Vui lòng chọn hợp đồng hoặc thêm giao dịch mới</p>
                                </div>
                              </div>';
                    }
                    ?>

                    <!-- Phân trang -->
                    <?php if ($total_pages > 1): ?>
                        <nav aria-label="Page navigation" class="mt-4">
                            <ul class="pagination justify-content-center">
                                <!-- Nút Trước -->
                                <li class="page-item <?php echo $page <= 1 ? 'disabled' : ''; ?>">
                                    <a class="page-link" href="thanhtoan.php?page=<?php echo $page - 1; ?>&hopdong=<?php echo urlencode($id_hopdong_filter); ?>">Trước</a>
                                </li>

                                <!-- Các trang -->
                                <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                                    <li class="page-item <?php echo $i == $page ? 'active' : ''; ?>">
                                        <a class="page-link" href="thanhtoan.php?page=<?php echo $i; ?>&hopdong=<?php echo urlencode($id_hopdong_filter); ?>"><?php echo $i; ?></a>
                                    </li>
                                <?php endfor; ?>

                                <!-- Nút Tiếp theo -->
                                <li class="page-item <?php echo $page >= $total_pages ? 'disabled' : ''; ?>">
                                    <a class="page-link" href="thanhtoan.php?page=<?php echo $page + 1; ?>&hopdong=<?php echo urlencode($id_hopdong_filter); ?>">Tiếp</a>
                                </li>
                            </ul>
                        </nav>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <footer class="footer">
            <p><i class="fas fa-phone"></i> Liên hệ: 0123 456 789 - <i class="fas fa-envelope"></i> Email: info@nhatro.com</p>
        </footer>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Hiển thị khoảng thời gian hợp đồng và thông tin thanh toán
        function updateHopDongDates() {
            const select = document.getElementById('id_hopdong');
            const hopdongDates = document.getElementById('hopdong_dates');
            const ngayBatDau = document.getElementById('ngay_bat_dau');
            const ngayKetThuc = document.getElementById('ngay_ket_thuc');
            const hinhThucThanhToan = document.getElementById('hinh_thuc_thanh_toan');
            const giaThue = document.getElementById('gia_thue');
            const soThang = document.getElementById('so_thang');
            const tongTien = document.getElementById('tong_tien');
            const soTienInput = document.getElementById('so_tien');

            if (select.value) {
                const selectedOption = select.options[select.selectedIndex];
                ngayBatDau.textContent = selectedOption.getAttribute('data-ngaybatdau');
                ngayKetThuc.textContent = selectedOption.getAttribute('data-ngayketthuc');
                hinhThucThanhToan.textContent = selectedOption.getAttribute('data-hinhthucthanhtoan') === 'Mot_lan' ? 'Trả một lần' : 'Trả hàng tháng';
                giaThue.textContent = new Intl.NumberFormat('vi-VN').format(selectedOption.getAttribute('data-giathue'));
                const months = Math.ceil((new Date(selectedOption.getAttribute('data-ngayketthuc')) - new Date(selectedOption.getAttribute('data-ngaybatdau'))) / (1000 * 60 * 60 * 24 * 30));
                soThang.textContent = months;
                tongTien.textContent = new Intl.NumberFormat('vi-VN').format(selectedOption.getAttribute('data-tongtien'));
                hopdongDates.style.display = 'block';

                // Tự động điền số tiền dựa trên hình thức thanh toán
                if (selectedOption.getAttribute('data-hinhthucthanhtoan') === 'Mot_lan') {
                    soTienInput.value = selectedOption.getAttribute('data-tongtien');
                } else {
                    soTienInput.value = selectedOption.getAttribute('data-giathue');
                }
            } else {
                hopdongDates.style.display = 'none';
                soTienInput.value = '';
            }
        }

        // Kiểm tra ngày thanh toán phía client
        document.getElementById('ngay_thanh_toan').addEventListener('change', function() {
            const select = document.getElementById('id_hopdong');
            const ngayThanhToan = new Date(this.value);
            if (select.value) {
                const selectedOption = select.options[select.selectedIndex];
                const ngayBatDau = new Date(selectedOption.getAttribute('data-ngaybatdau'));
                const ngayKetThuc = new Date(selectedOption.getAttribute('data-ngayketthuc'));

                if (ngayThanhToan < ngayBatDau || ngayThanhToan > ngayKetThuc) {
                    alert('Ngày thanh toán không hợp lệ! Ngày thanh toán phải nằm trong khoảng từ ' + ngayBatDau.toLocaleDateString('vi-VN') + ' đến ' + ngayKetThuc.toLocaleDateString('vi-VN') + '.');
                    this.value = ''; // Xóa giá trị ngày không hợp lệ
                }
            }
        });

        // Gọi hàm khi trang tải để hiển thị ngày nếu đã chọn hợp đồng
        window.addEventListener('DOMContentLoaded', updateHopDongDates);
    </script>
</body>
</html>