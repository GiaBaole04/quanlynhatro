<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Đăng Ký - Quản Lý Nhà Trọ</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-4">
                <div class="card">
                    <div class="card-header text-center">
                        <h3><i class="fas fa-user-plus"></i> Đăng Ký Tài Khoản</h3>
                    </div>
                    <div class="card-body">
                        <?php
                        include 'lib/connect.php';

                        // Hàm tạo ID_user tự động tăng
                        function getNextUserId($conn) {
                            $result = mysqli_query($conn, "SELECT ID_user FROM nguoidung ORDER BY ID_user ASC");
                            $used_ids = [];
                            while ($row = mysqli_fetch_assoc($result)) {
                                $used_ids[] = (int)$row['ID_user'];
                            }

                            $next_id = 1; // Bắt đầu từ 1
                            while (in_array($next_id, $used_ids)) {
                                $next_id++;
                            }
                            return $next_id;
                        }

                        if (isset($_POST['register'])) {
                            $username = $_POST['username'];
                            $password = $_POST['password'];
                            $id_vaitro = $_POST['id_vaitro'];

                            if (!empty($username) && !empty($password) && !empty($id_vaitro)) {
                                // Kiểm tra tài khoản đã tồn tại chưa
                                $check_query = "SELECT * FROM nguoidung WHERE Tai_khoan = ?";
                                $check_stmt = mysqli_prepare($conn, $check_query);
                                mysqli_stmt_bind_param($check_stmt, "s", $username);
                                mysqli_stmt_execute($check_stmt);
                                $check_result = mysqli_stmt_get_result($check_stmt);

                                if (mysqli_num_rows($check_result) > 0) {
                                    echo "<div class='alert alert-danger'>Tài khoản đã tồn tại!</div>";
                                } else {
                                    // Mã hóa mật khẩu bằng password_hash()
                                    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

                                    // Lấy ID_user mới
                                    $id_user = getNextUserId($conn);

                                    // Thêm tài khoản mới vào database
                                    $insert_query = "INSERT INTO nguoidung (ID_user, Tai_khoan, Mat_khau, ID_vaitro) VALUES (?, ?, ?, ?)";
                                    $insert_stmt = mysqli_prepare($conn, $insert_query);
                                    mysqli_stmt_bind_param($insert_stmt, "issi", $id_user, $username, $hashed_password, $id_vaitro);

                                    if (mysqli_stmt_execute($insert_stmt)) {
                                        echo "<div class='alert alert-success'>Đăng ký thành công! <a href='login.php'>Đăng nhập ngay</a></div>";
                                    } else {
                                        echo "<div class='alert alert-danger'>Lỗi khi đăng ký: " . mysqli_error($conn) . "</div>";
                                    }
                                }
                            } else {
                                echo "<div class='alert alert-danger'>Vui lòng điền đầy đủ thông tin!</div>";
                            }
                        }
                        ?>
                        <form method="POST">
                            <div class="mb-3">
                                <label for="username" class="form-label">Tên đăng nhập</label>
                                <div class="input-group">
                                    <span class="input-group-text"><i class="fas fa-user"></i></span>
                                    <input type="text" class="form-control" id="username" name="username" required>
                                </div>
                            </div>
                            <div class="mb-3">
                                <label for="password" class="form-label">Mật khẩu</label>
                                <div class="input-group">
                                    <span class="input-group-text"><i class="fas fa-lock"></i></span>
                                    <input type="password" class="form-control" id="password" name="password" required>
                                </div>
                            </div>
                            <div class="mb-3">
                                <label for="id_vaitro" class="form-label">Vai trò</label>
                                <select class="form-select" id="id_vaitro" name="id_vaitro" required>
                                    <option value="">Chọn vai trò</option>
                                    <option value="1">Admin</option>
                                    <option value="2">Người thuê</option>
                                    <option value="3">Chủ nhà</option>
                                </select>
                            </div>
                            <button type="submit" name="register" class="btn btn-primary w-100">
                                <i class="fas fa-user-plus"></i> Đăng Ký
                            </button>
                        </form>
                        <div class="text-center mt-3">
                            <p>Đã có tài khoản? <a href="login.php">Đăng nhập</a></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>