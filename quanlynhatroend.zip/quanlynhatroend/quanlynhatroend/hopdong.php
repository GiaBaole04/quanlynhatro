<?php
$required_role = 'admin'; // hoặc 'admin', 'nguoithue'
include('lib/auth.php');
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quản Lý Hợp Đồng</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <?php include('lib/menuapp.php'); ?>
    
    <div class="main-content">
        <h1 class="dashboard-title">Quản Lý Hợp Đồng</h1>

        <?php
        include 'lib/connect.php';
        include 'lib/hopdongFunction.php';
        
        // Xử lý thêm/sửa/xóa hợp đồng
        
        if (isset($_POST['add_hopdong'])) {
            // ...lấy dữ liệu...
            $id_phong = $_POST['id_phong'];
            $id_nguoithue = $_POST['id_nguoithue'];

            // Lấy giới tính người thuê mới
            $sql = "SELECT gioitinh FROM nguoithue WHERE ID_nguoithue = ?";
            $stmt = mysqli_prepare($conn, $sql);
            mysqli_stmt_bind_param($stmt, "s", $id_nguoithue);
            mysqli_stmt_execute($stmt);
            $result = mysqli_stmt_get_result($stmt);
            $row = mysqli_fetch_assoc($result);
            $gioitinh_moi = $row['gioitinh'];

            // Đếm số người đang thuê phòng và kiểm tra giới tính
            $sql = "SELECT nt.gioitinh FROM hopdong hd 
                    JOIN nguoithue nt ON hd.ID_nguoithue = nt.ID_nguoithue
                    WHERE hd.ID_phong = ? AND hd.Ngay_ket_thuc >= CURDATE()";
            $stmt = mysqli_prepare($conn, $sql);
            mysqli_stmt_bind_param($stmt, "s", $id_phong);
            mysqli_stmt_execute($stmt);
            $result = mysqli_stmt_get_result($stmt);

            $so_nguoi = 0;
            $gioitinh_phong = null;
            while ($row = mysqli_fetch_assoc($result)) {
                $so_nguoi++;
                if ($gioitinh_phong === null) {
                    $gioitinh_phong = $row['gioitinh'];
                }
                if ($row['gioitinh'] !== $gioitinh_moi) {
                    echo "<div class='alert alert-danger'>Phòng này chỉ nhận người cùng giới tính!</div>";
                    exit();
                }
            }
            if ($so_nguoi >= 2) {
                echo "<div class='alert alert-danger'>Phòng này đã đủ 2 người!</div>";
                exit();
            }

            // Nếu qua được kiểm tra, tiếp tục thêm hợp đồng như bình thường
            
        }
        elseif (isset($_POST['update_hopdong'])) {
            $id_hopdong = $_POST['id_hopdong'];
            $ngay_bat_dau = $_POST['ngay_bat_dau'] ?? '';
            $ngay_ket_thuc = $_POST['ngay_ket_thuc'] ?? '';
            $tien_coc = $_POST['tien_coc'] ?? '';
            $id_phong = $_POST['id_phong'] ?? '';
            $id_nguoithue = $_POST['id_nguoithue'] ?? '';
            $hinh_thuc_thanh_toan = $_POST['hinh_thuc_thanh_toan'] ?? 'Hang_thang';
            
            if ($ngay_bat_dau !== '' && $ngay_ket_thuc !== '' && $tien_coc !== '' && $id_phong !== '' && $id_nguoithue !== '') {
                // Kiểm tra ngày hợp lệ
                if (strtotime($ngay_ket_thuc) <= strtotime($ngay_bat_dau)) {
                    echo "<div class='alert alert-danger'>Ngày kết thúc phải lớn hơn ngày bắt đầu!</div>";
                } else {
                    if (updateHopDong($id_hopdong, $ngay_bat_dau, $ngay_ket_thuc, $tien_coc, $id_phong, $id_nguoithue, $hinh_thuc_thanh_toan)) {
                        $update_phong_query = "UPDATE phong_tro SET Trang_thai = 'Đã thuê' WHERE ID_phong = '$id_phong'";
                        mysqli_query($conn, $update_phong_query);
                        
                        header("Location: hopdong.php?msg=Cập nhật hợp đồng thành công");
                        exit();
                    } else {
                        echo "<div class='alert alert-danger'>Lỗi khi cập nhật hợp đồng: " . mysqli_error($conn) . "</div>";
                    }
                }
            } else {
                echo "<div class='alert alert-danger'>Vui lòng điền đầy đủ thông tin bắt buộc</div>";
            }
        }
        elseif (isset($_GET['delete'])) {
            $id_hopdong = $_GET['delete'];
            $hopdong = getHopDongById($id_hopdong);
            if ($hopdong) {
                $id_phong = $hopdong['ID_phong'];
                if (deleteHopDong($id_hopdong)) {
                    $update_phong_query = "UPDATE phong_tro SET Trang_thai = 'Trống' WHERE ID_phong = '$id_phong'";
                    mysqli_query($conn, $update_phong_query);
                    
                    header("Location: hopdong.php?msg=Xóa hợp đồng thành công");
                    exit();
                } else {
                    echo "<div class='alert alert-danger'>Không thể xóa hợp đồng vì đã có giao dịch thanh toán liên quan.</div>";
                }
            } else {
                echo "<div class='alert alert-danger'>Hợp đồng không tồn tại</div>";
            }
        }

        if (isset($_GET['msg'])) {
            echo "<div class='alert alert-success alert-dismissible fade show' role='alert'>
                    <strong>Thành công!</strong> " . htmlspecialchars($_GET['msg']) . "
                    <button type='button' class='btn-close' data-bs-dismiss='alert' aria-label='Close'></button>
                  </div>";
        }

        $edit_hopdong = null;
        if (isset($_GET['edit'])) {
            $id_hopdong = mysqli_real_escape_string($conn, $_GET['edit']);
            $edit_hopdong = getHopDongById($id_hopdong);
            if (!$edit_hopdong) {
                echo "<div class='alert alert-danger'>Lỗi khi lấy thông tin hợp đồng: Hợp đồng không tồn tại</div>";
            }
        }

        // Lấy trang hiện tại từ tham số URL
        $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
        if ($page < 1) $page = 1;

        // Lấy dữ liệu tìm kiếm
        $search = isset($_GET['search']) ? $_GET['search'] : '';

        // Gọi hàm getHopDongList với phân trang
        $result = getHopDongList($search, $page, 6); // 6 hợp đồng mỗi trang (2 hàng x 3 cột)
        $hopdong_list = $result['hopdong'] ?? [];
        $total_pages = $result['total_pages'] ?? 1;
        ?>

        <div class="row">
            <div class="col-md-4">
                <div class="stat-card">
                    <h3><?php echo $edit_hopdong ? 'Sửa Hợp Đồng' : 'Thêm Hợp Đồng'; ?></h3>
                    <form method="POST">
                        <?php if ($edit_hopdong) { ?>
                            <input type="hidden" name="id_hopdong" value="<?php echo htmlspecialchars($edit_hopdong['ID_hopdong']); ?>">
                        <?php } ?>
                        <div class="mb-3">
                            <label for="ngay_bat_dau" class="form-label">Ngày bắt đầu <span class="text-danger">*</span></label>
                            <input type="date" class="form-control" id="ngay_bat_dau" name="ngay_bat_dau" 
                                   value="<?php echo $edit_hopdong ? htmlspecialchars($edit_hopdong['Ngay_bat_dau']) : ''; ?>" required>
                        </div>
                        <div class="mb-3">
                            <label for="ngay_ket_thuc" class="form-label">Ngày kết thúc <span class="text-danger">*</span></label>
                            <input type="date" class="form-control" id="ngay_ket_thuc" name="ngay_ket_thuc" 
                                   value="<?php echo $edit_hopdong ? htmlspecialchars($edit_hopdong['Ngay_ket_thuc']) : ''; ?>" required>
                        </div>
                        <div class="mb-3">
                            <label for="tien_coc" class="form-label">Tiền cọc (VNĐ) <span class="text-danger">*</span></label>
                            <input type="number" class="form-control" id="tien_coc" name="tien_coc" step="0.01" 
                                   value="<?php echo $edit_hopdong ? htmlspecialchars($edit_hopdong['Tien_coc']) : ''; ?>" required>
                        </div>
                        <div class="mb-3">
                            <label for="id_nhatro" class="form-label">Nhà trọ <span class="text-danger">*</span></label>
                            <select class="form-select" id="id_nhatro" name="id_nhatro" required>
                                <option value="">Chọn nhà trọ</option>
                                <?php
                                $nhatro_list = getNhaTroList();
                                if (is_array($nhatro_list)) {
                                    foreach ($nhatro_list as $nhatro) {
                                        $selected = ($edit_hopdong && $edit_hopdong['ID_nhatro'] == $nhatro['ID_nhatro']) ? 'selected' : '';
                                        echo "<option value='{$nhatro['ID_nhatro']}' $selected>" . htmlspecialchars($nhatro['Ten_nhatro']) . "</option>";
                                    }
                                } else {
                                    echo "<option value='' disabled>Không có nhà trọ nào</option>";
                                }
                                ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="id_phong" class="form-label">Phòng trọ <span class="text-danger">*</span></label>
                            <select class="form-select" id="id_phong" name="id_phong" required>
                                <option value="">Chọn phòng trọ</option>
                                <?php
                                $phongtro_list = getPhongTroList($edit_hopdong ? $edit_hopdong['ID_nhatro'] : '');
                                if (is_array($phongtro_list)) {
                                    foreach ($phongtro_list as $phong) {
                                        $selected = ($edit_hopdong && $edit_hopdong['ID_phong'] == $phong['ID_phong']) ? 'selected' : '';
                                        $disabled = ($phong['ID_phong'] != ($edit_hopdong ? $edit_hopdong['ID_phong'] : '') && $phong['Trang_thai'] == 'Đã thuê') ? 'disabled' : '';
                                        echo "<option value='{$phong['ID_phong']}' $selected $disabled data-nhatro='{$phong['ID_nhatro']}'>" . htmlspecialchars($phong['Ten_phong']) . "</option>";
                                    }
                                } else {
                                    echo "<option value='' disabled>Không có phòng trọ nào</option>";
                                }
                                ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="id_nguoithue" class="form-label">Người thuê <span class="text-danger">*</span></label>
                            <select class="form-select" id="id_nguoithue" name="id_nguoithue" required>
                                <option value="">Chọn người thuê</option>
                                <?php
                                $result = mysqli_query($conn, "SELECT ID_nguoithue, Ho_ten FROM nguoithue");
                                if ($result && mysqli_num_rows($result) > 0) {
                                    while ($row = mysqli_fetch_assoc($result)) {
                                        $selected = ($edit_hopdong && $edit_hopdong['ID_nguoithue'] == $row['ID_nguoithue']) ? 'selected' : '';
                                        echo "<option value='{$row['ID_nguoithue']}' $selected>" . htmlspecialchars($row['Ho_ten']) . "</option>";
                                    }
                                } else {
                                    echo "<option value='' disabled>Không có người thuê nào</option>";
                                }
                                ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="hinh_thuc_thanh_toan" class="form-label">Hình thức thanh toán <span class="text-danger">*</span></label>
                            <select class="form-select" id="hinh_thuc_thanh_toan" name="hinh_thuc_thanh_toan" required>
                                <option value="Mot_lan" <?php echo ($edit_hopdong && $edit_hopdong['Hinh_thuc_thanh_toan'] == 'Mot_lan') ? 'selected' : ''; ?>>Trả một lần</option>
                                <option value="Hang_thang" <?php echo ($edit_hopdong && $edit_hopdong['Hinh_thuc_thanh_toan'] == 'Hang_thang') ? 'selected' : ''; ?>>Trả hàng tháng</option>
                            </select>
                        </div>
                        <button type="submit" name="<?php echo $edit_hopdong ? 'update_hopdong' : 'add_hopdong'; ?>" class="btn btn-primary w-100">
                            <i class="fas fa-save"></i> <?php echo $edit_hopdong ? 'Cập nhật' : 'Thêm mới'; ?>
                        </button>
                    </form>
                </div>
            </div>

            <div class="col-md-8">
                <div class="contracts-table">
                    <h3 class="section-title">Danh Sách Hợp Đồng</h3>
                    <form method="GET" class="mb-3">
                        <div class="input-group">
                            <input type="text" class="form-control" id="search" name="search" placeholder="Tìm kiếm theo tên người thuê..." 
                                   value="<?php echo htmlspecialchars($search); ?>">
                            <button type="submit" class="btn btn-primary"><i class="fas fa-search"></i> Tìm kiếm</button>
                        </div>
                    </form>
                    
                <div id="hopdong-list">
                    <?php
                    if (is_array($hopdong_list) && !empty($hopdong_list)) {
                        $chunked_hopdong = array_chunk($hopdong_list, 3); // Chia danh sách thành các hàng, mỗi hàng 3 cột
                        $rows_to_display = array_slice($chunked_hopdong, 0, 2); // Chỉ lấy tối đa 2 hàng

                        foreach ($rows_to_display as $row) {
                            echo '<div class="row row-cols-1 row-cols-md-3 g-4 mb-4">';
                            foreach ($row as $hopdong) {
                                if (!is_array($hopdong) || !isset($hopdong['ID_hopdong'])) {
                                    error_log("Debug: Hợp đồng không hợp lệ: " . print_r($hopdong, true), 3, "debug.log");
                                    continue; // Bỏ qua nếu $hopdong không phải là mảng hợp lệ
                                }
                                // Debug: Ghi log hợp đồng hiển thị
                                error_log("Debug: Hiển thị hợp đồng ID: " . $hopdong['ID_hopdong'], 3, "debug.log");
                                $so_thang = getSoThangHopDong($hopdong['Ngay_bat_dau'], $hopdong['Ngay_ket_thuc']);
                                $tong_tien = $hopdong['Gia_thue'] * $so_thang;
                                ?>
                                <div class="col">
                                    <div class="card h-100 shadow-sm room-card">
                                        <div class="card-body">
                                            <h5 class="card-title"><?php echo htmlspecialchars($hopdong['Ho_ten'] ?? 'N/A'); ?></h5>
                                            <p class="card-text">
                                                <strong>Hợp đồng:</strong> <?php echo htmlspecialchars($hopdong['ID_hopdong'] ?? 'N/A'); ?><br>
                                                <strong>Nhà trọ:</strong> <?php echo htmlspecialchars($hopdong['Ten_nhatro'] ?? 'N/A'); ?><br>
                                                <strong>Phòng trọ:</strong> <?php echo htmlspecialchars($hopdong['Ten_phong'] ?? 'N/A'); ?><br>
                                                <strong>Ngày bắt đầu:</strong> <?php echo htmlspecialchars($hopdong['Ngay_bat_dau'] ?? 'N/A'); ?><br>
                                                <strong>Ngày kết thúc:</strong> <?php echo htmlspecialchars($hopdong['Ngay_ket_thuc'] ?? 'N/A'); ?><br>
                                                <strong>Số tháng:</strong> <?php echo $so_thang; ?><br>
                                                <strong>Giá thuê:</strong> <?php echo number_format($hopdong['Gia_thue'] ?? 0, 0); ?> VNĐ/tháng<br>
                                                <strong>Tổng tiền:</strong> <?php echo number_format($tong_tien, 0); ?> VNĐ<br>
                                                <strong>Hình thức thanh toán:</strong> <?php echo ($hopdong['Hinh_thuc_thanh_toan'] ?? 'Hang_thang') == 'Mot_lan' ? 'Trả một lần' : 'Trả hàng tháng'; ?><br>
                                                <strong>Tiền cọc:</strong> <?php echo number_format($hopdong['Tien_coc'] ?? 0, 0); ?> VNĐ
                                            </p>
                                        </div>
                                        <div class="card-footer bg-white d-flex justify-content-end align-items-center">
                                            <div class="action-buttons d-flex gap-2">
                                                <a href="thanhtoan.php?hopdong=<?php echo urlencode($hopdong['ID_hopdong']); ?>" class="btn btn-info" style="background-color: #17a2b8; border-color: #17a2b8; color: #fff;">
                                                    <i class="fas fa-money-bill"></i> Xem thanh toán
                                                </a>
                                                <a href="hopdong.php?edit=<?php echo urlencode($hopdong['ID_hopdong']); ?>" class="btn btn-warning" style="background-color: #ffca28; border-color: #ffca28; color: #fff;">
                                                    <i class="fas fa-edit"></i> Sửa
                                                </a>
                                                <a href="hopdong.php?delete=<?php echo urlencode($hopdong['ID_hopdong']); ?>" class="btn btn-danger" style="background-color: #ff4d4f; border-color: #ff4d4f; color: #fff;" onclick="return confirm('Bạn có chắc muốn xóa hợp đồng này?');">
                                                    <i class="fas fa-trash"></i> Xóa
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <?php
                            }
                            echo '</div>';
                        }
                    } else {
                        echo '<div class="col-12">
                                <div class="empty-state">
                                    <i class="fas fa-file-contract" style="font-size: 3rem;"></i>
                                    <h4 class="mt-3">Không tìm thấy hợp đồng nào</h4>
                                    <p>Vui lòng thử lại với từ khóa khác hoặc thêm hợp đồng mới</p>
                                </div>
                              </div>';
                    }
                    ?>
                </div>
                    <!-- Phân trang -->
                    <?php if ($total_pages > 1): ?>
                        <nav aria-label="Page navigation" class="mt-4">
                            <ul class="pagination justify-content-center">
                                <!-- Nút Trước -->
                                <li class="page-item <?php echo $page <= 1 ? 'disabled' : ''; ?>">
                                    <a class="page-link" href="hopdong.php?page=<?php echo $page - 1; ?><?php echo !empty($search) ? '&search=' . urlencode($search) : ''; ?>">Trước</a>
                                </li>

                                <!-- Các trang -->
                                <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                                    <li class="page-item <?php echo $i == $page ? 'active' : ''; ?>">
                                        <a class="page-link" href="hopdong.php?page=<?php echo $i; ?><?php echo !empty($search) ? '&search=' . urlencode($search) : ''; ?>"><?php echo $i; ?></a>
                                    </li>
                                <?php endfor; ?>

                                <!-- Nút Tiếp theo -->
                                <li class="page-item <?php echo $page >= $total_pages ? 'disabled' : ''; ?>">
                                    <a class="page-link" href="hopdong.php?page=<?php echo $page + 1; ?><?php echo !empty($search) ? '&search=' . urlencode($search) : ''; ?>">Tiếp</a>
                                </li>
                            </ul>
                        </nav>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <footer class="footer">
            <p><i class="fas fa-phone"></i> Liên hệ: 0123 456 789 - <i class="fas fa-envelope"></i> Email: info@nhatro.com</p>
        </footer>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Lọc danh sách phòng trọ dựa trên nhà trọ được chọn
        document.getElementById('id_nhatro').addEventListener('change', function() {
            const idNhaTro = this.value;
            const phongSelect = document.getElementById('id_phong');
            const options = phongSelect.querySelectorAll('option');
            
            options.forEach(option => {
                if (option.value === '') {
                    return; // Bỏ qua option "Chọn phòng trọ"
                }
                const idNhaTroOfPhong = option.getAttribute('data-nhatro');
                if (idNhaTro === '' || idNhaTroOfPhong === idNhaTro) {
                    option.style.display = 'block';
                } else {
                    option.style.display = 'none';
                }
            });

            // Reset lựa chọn phòng trọ khi thay đổi nhà trọ
            phongSelect.value = '';
        });

        // Đảm bảo hiển thị đúng danh sách phòng khi chỉnh sửa hợp đồng
        window.addEventListener('DOMContentLoaded', function() {
            const idNhaTro = document.getElementById('id_nhatro').value;
            const phongSelect = document.getElementById('id_phong');
            const options = phongSelect.querySelectorAll('option');
            
            options.forEach(option => {
                if (option.value === '') {
                    return;
                }
                const idNhaTroOfPhong = option.getAttribute('data-nhatro');
                if (idNhaTro === '' || idNhaTroOfPhong === idNhaTro) {
                    option.style.display = 'block';
                } else {
                    option.style.display = 'none';
                }
            });
        });

        // Kiểm tra ngày hợp lệ phía client
        document.getElementById('ngay_ket_thuc').addEventListener('change', function() {
            const ngayBatDau = new Date(document.getElementById('ngay_bat_dau').value);
            const ngayKetThuc = new Date(this.value);

            if (ngayBatDau && ngayKetThuc && ngayKetThuc <= ngayBatDau) {
                alert('Ngày kết thúc phải lớn hơn ngày bắt đầu!');
                this.value = '';
            }
        });
    </script>
    <script>
const searchInput = document.getElementById('search');
const hopdongList = document.getElementById('hopdong-list');

searchInput.addEventListener('keyup', function() {
    const searchText = this.value.trim();
    fetch('lib/search_hopdong.php?search=' + encodeURIComponent(searchText))
        .then(response => response.json())
        .then(data => {
            let html = '';
            if (data.length > 0) {
                for (let i = 0; i < data.length; i += 3) {
                    html += `<div class="row row-cols-1 row-cols-md-3 g-4 mb-4">`;
                    let row = data.slice(i, i + 3);
                    row.forEach(hd => {
                        // Tính số tháng và tổng tiền (nếu cần)
                        const date1 = new Date(hd.Ngay_bat_dau);
                        const date2 = new Date(hd.Ngay_ket_thuc);
                        let so_thang = (date2.getFullYear() - date1.getFullYear()) * 12 + (date2.getMonth() - date1.getMonth());
                        if (date2.getDate() >= date1.getDate()) so_thang++;
                        if (so_thang < 1) so_thang = 1;
                        const gia_thue = Number(hd.Gia_thue) || 0;
                        const tong_tien = gia_thue * so_thang;

                        html += `
                        <div class="col">
                            <div class="card h-100 shadow-sm room-card">
                                <div class="card-body">
                                    <h5 class="card-title">${hd.Ho_ten ?? 'N/A'}</h5>
                                    <p class="card-text">
                                        <strong>Hợp đồng:</strong> ${hd.ID_hopdong ?? 'N/A'}<br>
                                        <strong>Nhà trọ:</strong> ${hd.Ten_nhatro ?? 'N/A'}<br>
                                        <strong>Phòng trọ:</strong> ${hd.Ten_phong ?? 'N/A'}<br>
                                        <strong>Ngày bắt đầu:</strong> ${hd.Ngay_bat_dau ?? 'N/A'}<br>
                                        <strong>Ngày kết thúc:</strong> ${hd.Ngay_ket_thuc ?? 'N/A'}<br>
                                        <strong>Số tháng:</strong> ${so_thang}<br>
                                        <strong>Giá thuê:</strong> ${gia_thue.toLocaleString()} VNĐ/tháng<br>
                                        <strong>Tổng tiền:</strong> ${tong_tien.toLocaleString()} VNĐ<br>
                                        <strong>Hình thức thanh toán:</strong> ${(hd.Hinh_thuc_thanh_toan ?? 'Hang_thang') === 'Mot_lan' ? 'Trả một lần' : 'Trả hàng tháng'}<br>
                                        <strong>Tiền cọc:</strong> ${(Number(hd.Tien_coc) || 0).toLocaleString()} VNĐ
                                    </p>
                                </div>
                                <div class="card-footer bg-white d-flex justify-content-end align-items-center">
                                    <div class="action-buttons d-flex gap-2">
                                        <a href="thanhtoan.php?hopdong=${encodeURIComponent(hd.ID_hopdong)}" class="btn btn-info" style="background-color: #17a2b8; border-color: #17a2b8; color: #fff;">
                                            <i class="fas fa-money-bill"></i> Xem thanh toán
                                        </a>
                                        <a href="hopdong.php?edit=${encodeURIComponent(hd.ID_hopdong)}" class="btn btn-warning" style="background-color: #ffca28; border-color: #ffca28; color: #fff;">
                                            <i class="fas fa-edit"></i> Sửa
                                        </a>
                                        <a href="hopdong.php?delete=${encodeURIComponent(hd.ID_hopdong)}" class="btn btn-danger" style="background-color: #ff4d4f; border-color: #ff4d4f; color: #fff;" onclick="return confirm('Bạn có chắc muốn xóa hợp đồng này?');">
                                            <i class="fas fa-trash"></i> Xóa
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        `;
                    });
                    html += `</div>`;
                }
            } else {
                html = `<div class="col-12">
                            <div class="empty-state">
                                <i class="fas fa-file-contract" style="font-size: 3rem;"></i>
                                <h4 class="mt-3">Không tìm thấy hợp đồng nào</h4>
                                <p>Vui lòng thử lại với từ khóa khác hoặc thêm hợp đồng mới</p>
                            </div>
                        </div>`;
            }
            hopdongList.innerHTML = html;
        });
});
</script>
</body>
</html>