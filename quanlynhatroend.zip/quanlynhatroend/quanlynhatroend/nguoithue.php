<?php
$required_role = 'admin'; // hoặc 'admin', 'nguoithue'
include('lib/auth.php');
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quản Lý Người Thuê</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <?php include('lib/menuapp.php'); ?>
    
    <div class="main-content">
        <h1 class="dashboard-title">Quản Lý Người Thuê</h1>

        <?php
        include 'lib/connect.php';
        include 'lib/nguoithueFunction.php';
        
        // Xử lý thêm/sửa/xóa người thuê
        if (isset($_POST['add_nguoithue'])) {
            $ho_ten = $_POST['ho_ten'];
            $so_dien_thoai = $_POST['so_dien_thoai'];
            $cccd = $_POST['cccd'];
            $gioi_tinh = $_POST['gioi_tinh'] ?? '';
            
            if (!empty($ho_ten) && !empty($so_dien_thoai) && !empty($cccd)) {
                // Kiểm tra trùng lặp CCCD khi thêm mới
                if (checkDuplicateCCCD($cccd)) {
                    echo "<div class='alert alert-danger'>Số CCCD '$cccd' đã tồn tại. Vui lòng sử dụng số CCCD khác.</div>";
                } elseif (addNguoiThue($ho_ten, $so_dien_thoai, $cccd, $gioi_tinh)) {
                    header("Location: nguoithue.php?msg=Thêm người thuê thành công");
                    exit();
                } else {
                    echo "<div class='alert alert-danger'>Lỗi khi thêm người thuê: " . mysqli_error($conn) . "</div>";
                }
            } else {
                echo "<div class='alert alert-danger'>Vui lòng điền đầy đủ thông tin bắt buộc</div>";
            }
        }
        elseif (isset($_POST['update_nguoithue'])) {
            $id_nguoithue = $_POST['id_nguoithue'];
            $ho_ten = $_POST['ho_ten'];
            $so_dien_thoai = $_POST['so_dien_thoai'];
            $cccd = $_POST['cccd'];
            $gioi_tinh = $_POST['gioi_tinh'] ?? '';
            
            if (!empty($ho_ten) && !empty($so_dien_thoai) && !empty($cccd)) {
                // Kiểm tra trùng lặp CCCD
                if (checkDuplicateCCCD($cccd, $id_nguoithue)) {
                    echo "<div class='alert alert-danger'>Số CCCD '$cccd' đã tồn tại. Vui lòng sử dụng số CCCD khác.</div>";
                } elseif (updateNguoiThue($id_nguoithue, $ho_ten, $so_dien_thoai, $cccd, $gioi_tinh)) {
                    header("Location: nguoithue.php?msg=Cập nhật người thuê thành công");
                    exit();
                } else {
                    echo "<div class='alert alert-danger'>Lỗi khi cập nhật người thuê: " . mysqli_error($conn) . "</div>";
                }
            } else {
                echo "<div class='alert alert-danger'>Vui lòng điền đầy đủ thông tin bắt buộc</div>";
            }
        }
        elseif (isset($_GET['delete'])) {
            $id_nguoithue = $_GET['delete'];
            if (deleteNguoiThue($id_nguoithue)) {
                header("Location: nguoithue.php?msg=Xóa người thuê thành công");
                exit();
            } else {
                echo "<div class='alert alert-danger'>Lỗi khi xóa người thuê: Người thuê này đang có hợp đồng, không thể xóa.</div>";
            }
        }

        if (isset($_GET['msg'])) {
            echo "<div class='alert alert-success alert-dismissible fade show' role='alert'>
                    <strong>Thành công!</strong> " . htmlspecialchars($_GET['msg']) . "
                    <button type='button' class='btn-close' data-bs-dismiss='alert' aria-label='Close'></button>
                  </div>";
        }

        $edit_nguoithue = null;
        if (isset($_GET['edit'])) {
            $id_nguoithue = $_GET['edit'];
            // Kiểm tra giá trị $id_nguoithue
            if (!empty($id_nguoithue)) {
                // Xử lý giá trị để tránh SQL Injection
                $id_nguoithue = mysqli_real_escape_string($conn, $id_nguoithue);
                // Thêm dấu nháy đơn quanh giá trị $id_nguoithue trong truy vấn
                $result = mysqli_query($conn, "SELECT * FROM nguoithue WHERE ID_nguoithue = '$id_nguoithue'");
                if ($result && mysqli_num_rows($result) > 0) {
                    $edit_nguoithue = mysqli_fetch_assoc($result);
                } else {
                    echo "<div class='alert alert-danger'>Lỗi khi lấy thông tin người thuê: " . mysqli_error($conn) . "</div>";
                }
            } else {
                echo "<div class='alert alert-danger'>ID người thuê không hợp lệ.</div>";
            }
        }

        // Lấy trang hiện tại từ tham số URL
        $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
        if ($page < 1) $page = 1;

        // Lấy dữ liệu tìm kiếm
        $search = isset($_GET['search']) ? $_GET['search'] : '';

        // Gọi hàm getNguoiThueList với phân trang
        $result = getNguoiThueList($search, $page, 6); // 6 người thuê mỗi trang (2 hàng x 3 cột)
        $nguoithue_list = $result['nguoithue'];
        $total_pages = $result['total_pages'];
        ?>

        <div class="row">
            <div class="col-md-4">
                <div class="stat-card">
                    <h3><?php echo $edit_nguoithue ? 'Sửa Người Thuê' : 'Thêm Người Thuê'; ?></h3>
                    <form method="POST">
                        <?php if ($edit_nguoithue) { ?>
                            <input type="hidden" name="id_nguoithue" value="<?php echo htmlspecialchars($edit_nguoithue['ID_nguoithue']); ?>">
                        <?php } ?>
                        <div class="mb-3">
                            <label for="ho_ten" class="form-label">Họ tên <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" id="ho_ten" name="ho_ten" 
                                   value="<?php echo $edit_nguoithue ? htmlspecialchars($edit_nguoithue['Ho_ten']) : ''; ?>" required>
                        </div>
                        <div class="mb-3">
                            <label for="so_dien_thoai" class="form-label">Số điện thoại <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" id="so_dien_thoai" name="so_dien_thoai" 
                                   value="<?php echo $edit_nguoithue ? htmlspecialchars($edit_nguoithue['So_dien_thoai']) : ''; ?>" required>
                        </div>
                        <div class="mb-3">
                            <label for="cccd" class="form-label">CCCD <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" id="cccd" name="cccd" 
                                   value="<?php echo $edit_nguoithue ? htmlspecialchars($edit_nguoithue['CCCD']) : ''; ?>" required>
                        </div>
                        <div class="mb-3">
                            <label for="gioi_tinh" class="form-label">Giới tính <span class="text-danger">*</span></label>
                            <select class="form-control" id="gioi_tinh" name="gioi_tinh" required>
                                <option value="">Chọn giới tính</option>
                                <option value="Nam" <?php echo ($edit_nguoithue && $edit_nguoithue['gioitinh'] == 'Nam') ? 'selected' : ''; ?>>Nam</option>
                                <option value="Nữ" <?php echo ($edit_nguoithue && $edit_nguoithue['gioitinh'] == 'Nữ') ? 'selected' : ''; ?>>Nữ</option>
                                
                            </select>
                        </div>
                        <button type="submit" name="<?php echo $edit_nguoithue ? 'update_nguoithue' : 'add_nguoithue'; ?>" class="btn btn-primary w-100">
                            <i class="fas fa-save"></i> <?php echo $edit_nguoithue ? 'Cập nhật' : 'Thêm mới'; ?>
                        </button>
                    </form>
                </div>
            </div>

            <div class="col-md-8">
                <div class="contracts-table">
                    <h3 class="section-title">Danh Sách Người Thuê</h3>
                    <form method="GET" class="mb-3">
                        <div class="input-group">
                            <input type="text" class="form-control" id="search" name="search" placeholder="Tìm kiếm theo họ tên" 
                                   value="<?php echo isset($_GET['search']) ? htmlspecialchars($_GET['search']) : ''; ?>">
                            <button type="submit" class="btn btn-primary"><i class="fas fa-search"></i> Tìm kiếm</button>
                        </div>
                    </form>
                <div id="nguoithue-list">
                    <?php
                    if ($nguoithue_list && !empty($nguoithue_list)) {
                        $chunked_nguoithue = array_chunk($nguoithue_list, 3); // Chia danh sách thành các hàng, mỗi hàng 3 cột
                        $rows_to_display = array_slice($chunked_nguoithue, 0, 2); // Chỉ lấy tối đa 2 hàng

                        foreach ($rows_to_display as $row) {
                            echo '<div class="row row-cols-1 row-cols-md-3 g-4 mb-4">';
                            foreach ($row as $nguoithue) {
                                ?>
                                <div class="  col">
                                    <div class="card h-100 shadow-sm room-card">
                                    <div class="card-body">
                                    <div class="mb-2">
                                        <span class="badge bg-info text-dark" style="font-size: 1rem;">
                                            <?php
                                                echo htmlspecialchars(
                                                    (isset($nguoithue['Ten_nhatro']) && $nguoithue['Ten_nhatro'] ? $nguoithue['Ten_nhatro'] : 'Chưa có hợp đồng')
                                                );
                                            ?>
                                        </span>
                                    </div>
                                    <h5 class="card-title"><?php echo htmlspecialchars($nguoithue['Ho_ten']); ?></h5>
                                    <p class="card-text">
                                    <strong>Giới tính:</strong> <?php echo htmlspecialchars($nguoithue['gioitinh'] ?? ''); ?><br>
                                        <strong>Số điện thoại:</strong> <?php echo htmlspecialchars($nguoithue['So_dien_thoai']); ?><br>
                                        <strong>CCCD:</strong> <?php echo htmlspecialchars($nguoithue['CCCD']); ?><br>
                                        <strong>Phòng trọ:</strong> <?php echo isset($nguoithue['Ten_phong']) && $nguoithue['Ten_phong'] ? htmlspecialchars($nguoithue['Ten_phong']) : 'Chưa có hợp đồng'; ?><br>
                                        <strong>Ngày bắt đầu thuê:</strong> <?php echo htmlspecialchars($nguoithue['Ngay_bat_dau'] ?: 'Chưa có hợp đồng'); ?>
                                    </p>
                                    </div>
                                        <div class="card-footer bg-white d-flex justify-content-end align-items-center">
                                            <div class="action-buttons d-flex gap-2">
                                                <a href="nguoithue.php?edit=<?php echo urlencode($nguoithue['ID_nguoithue']); ?>" class="btn btn-warning" style="background-color: #ffca28; border-color: #ffca28; color: #fff;">
                                                    <i class="fas fa-edit"></i> Sửa
                                                </a>
                                                <a href="nguoithue.php?delete=<?php echo urlencode($nguoithue['ID_nguoithue']); ?>" class="btn btn-danger" style="background-color: #ff4d4f; border-color: #ff4d4f; color: #fff;" onclick="return confirm('Bạn có chắc muốn xóa người thuê này?');">
                                                    <i class="fas fa-trash"></i> Xóa
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <?php
                            }
                            echo '</div>';
                        }
                    } else {
                        echo '<div class="col-12">
                                <div class="empty-state">
                                    <i class="fas fa-users" style="font-size: 3rem;"></i>
                                    <h4 class="mt-3">Không tìm thấy người thuê nào</h4>
                                    <p>Vui lòng thử lại với từ khóa khác hoặc thêm người thuê mới</p>
                                </div>
                              </div>';
                    }
                    ?>
                </div>
                    <!-- Phân trang -->
                    <?php if ($total_pages > 1): ?>
                        <nav aria-label="Page navigation" class="mt-4">
                            <ul class="pagination justify-content-center">
                                <!-- Nút Trước -->
                                <li class="page-item <?php echo $page <= 1 ? 'disabled' : ''; ?>">
                                    <a class="page-link" href="nguoithue.php?page=<?php echo $page - 1; ?><?php echo !empty($search) ? '&search=' . urlencode($search) : ''; ?>">Trước</a>
                                </li>

                                <!-- Các trang -->
                                <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                                    <li class="page-item <?php echo $i == $page ? 'active' : ''; ?>">
                                        <a class="page-link" href="nguoithue.php?page=<?php echo $i; ?><?php echo !empty($search) ? '&search=' . urlencode($search) : ''; ?>"><?php echo $i; ?></a>
                                    </li>
                                <?php endfor; ?>

                                <!-- Nút Tiếp theo -->
                                <li class="page-item <?php echo $page >= $total_pages ? 'disabled' : ''; ?>">
                                    <a class="page-link" href="nguoithue.php?page=<?php echo $page + 1; ?><?php echo !empty($search) ? '&search=' . urlencode($search) : ''; ?>">Tiếp</a>
                                </li>
                            </ul>
                        </nav>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <footer class="footer">
            <p><i class="fas fa-phone"></i> Liên hệ: 0123 456 789 - <i class="fas fa-envelope"></i> Email: info@nhatro.com</p>
        </footer>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
const searchInput = document.getElementById('search');
const nguoithueList = document.getElementById('nguoithue-list');

searchInput.addEventListener('keyup', function() {
    const searchText = this.value.trim();
    fetch('lib/search_nguoithue.php?search=' + encodeURIComponent(searchText))
        .then(response => response.json())
        .then(data => {
            let html = '';
            if (data.length > 0) {
                // Chia thành từng hàng 3 người thuê
                for (let i = 0; i < data.length; i += 3) {
                    html += `<div class="row row-cols-1 row-cols-md-3 g-4 mb-4">`;
                    let row = data.slice(i, i + 3);
                    row.forEach(nt => {
                        html += `
                        <div class="col">
                            <div class="card h-100 shadow-sm room-card">
                                <div class="card-body">
                                    <div class="mb-2">
                                        <span class="badge bg-info text-dark" style="font-size: 1rem;">
                                            ${nt.Ten_nhatro ?? 'Chưa có hợp đồng'}
                                        </span>
                                    </div>
                                    <h5 class="card-title">${nt.Ho_ten}</h5>
                                    <p class="card-text">
                                        <strong>Giới tính:</strong> ${nt.gioitinh ?? ''}<br>
                                        <strong>Số điện thoại:</strong> ${nt.So_dien_thoai}<br>
                                        <strong>CCCD:</strong> ${nt.CCCD}<br>
                                        <strong>Phòng trọ:</strong> ${nt.Ten_phong ?? 'Chưa có hợp đồng'}<br>
                                        <strong>Ngày bắt đầu thuê:</strong> ${nt.Ngay_bat_dau ?? 'Chưa có hợp đồng'}
                                    </p>
                                </div>
                                <div class="card-footer bg-white d-flex justify-content-end align-items-center">
                                    <div class="action-buttons d-flex gap-2">
                                        <a href="nguoithue.php?edit=${encodeURIComponent(nt.ID_nguoithue)}" class="btn btn-warning" style="background-color: #ffca28; border-color: #ffca28; color: #fff;">
                                            <i class="fas fa-edit"></i> Sửa
                                        </a>
                                        <a href="nguoithue.php?delete=${encodeURIComponent(nt.ID_nguoithue)}" class="btn btn-danger" style="background-color: #ff4d4f; border-color: #ff4d4f; color: #fff;" onclick="return confirm('Bạn có chắc muốn xóa người thuê này?');">
                                            <i class="fas fa-trash"></i> Xóa
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        `;
                    });
                    html += `</div>`;
                }
            } else {
                html = `<div class="col-12">
                            <div class="empty-state">
                                <i class="fas fa-users" style="font-size: 3rem;"></i>
                                <h4 class="mt-3">Không tìm thấy người thuê nào</h4>
                                <p>Vui lòng thử lại với từ khóa khác hoặc thêm người thuê mới</p>
                            </div>
                        </div>`;
            }
            nguoithueList.innerHTML = html;
        });
});
</script>
</body>
</html>