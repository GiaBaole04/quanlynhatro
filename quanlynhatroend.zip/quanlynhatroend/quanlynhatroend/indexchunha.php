<?php
$required_role = 'chunha'; // hoặc 'admin', 'nguoithue'
include('lib/auth.php');
include('lib/connect.php');

?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Chủ Nhà - Quản Lý Nhà Trọ</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/style.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>
    <?php include('lib/menuchunha.php'); ?>
    <div class="main-content">
        <h1 class="dashboard-title">Chào mừng, Chủ Nhà!</h1>
        <div class="row g-4">
            <div class="col-md-4">
            <div class="stat-card text-center">
                <i class="fas fa-building fa-3x mb-3 text-primary"></i>
                <h3>Tổng số nhà trọ</h3>
                <?php
                $sql = "SELECT COUNT(*) as total FROM nhatro WHERE ID_user = ?";
                $stmt = mysqli_prepare($conn, $sql);
                mysqli_stmt_bind_param($stmt, "i", $_SESSION['user_id']);
                mysqli_stmt_execute($stmt);
                $result = mysqli_stmt_get_result($stmt);
                $row = mysqli_fetch_assoc($result);
                ?>
                <h4 class="counter"><?php echo $row['total']; ?></h4>
                <p>Nhà trọ đang quản lý</p>
            </div>
            </div>
            <div class="stat-card text-center">
                <i class="fas fa-door-closed fa-3x mb-3 text-success"></i>
                <h3>Phòng trống</h3>
                <?php
                $sql = "SELECT COUNT(*) as total FROM phong_tro WHERE Trang_thai = 'Trống' AND ID_nhatro IN (SELECT ID_nhatro FROM nhatro WHERE ID_user = ?)";
                $stmt = mysqli_prepare($conn, $sql);
                mysqli_stmt_bind_param($stmt, "i", $_SESSION['user_id']);
                mysqli_stmt_execute($stmt);
                $result = mysqli_stmt_get_result($stmt);
                $row = mysqli_fetch_assoc($result);
                ?>
                <h4 class="counter"><?php echo $row['total']; ?></h4>
                <p>Phòng sẵn sàng cho thuê</p>
            </div>
            <div class="col-md-4">
            <div class="stat-card text-center">
                <i class="fas fa-file-signature fa-3x mb-3 text-warning"></i>
                <h3>Hợp đồng hiệu lực</h3>
                <?php
                $sql = "SELECT COUNT(*) as total 
                        FROM hopdong h
                        INNER JOIN phong_tro p ON h.ID_phong = p.ID_phong
                        WHERE h.Ngay_ket_thuc >= CURDATE() 
                        AND p.ID_nhatro IN (SELECT ID_nhatro FROM nhatro WHERE ID_user = ?)";
                $stmt = mysqli_prepare($conn, $sql);
                if (!$stmt) {
                    die("Lỗi prepare: " . mysqli_error($conn));
                }
                mysqli_stmt_bind_param($stmt, "i", $_SESSION['user_id']);
                mysqli_stmt_execute($stmt);
                $result = mysqli_stmt_get_result($stmt);
                $row = mysqli_fetch_assoc($result);
                ?>
                <h4 class="counter"><?php echo $row['total']; ?></h4>
                <p>Hợp đồng đang có hiệu lực</p>
            </div>
            </div>
        </div>
    </div>
    <footer class="footer mt-5">
        <p>&copy; <?php echo date('Y'); ?> Chủ Nhà - Quản lý nhà trọ</p>
    </footer>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>